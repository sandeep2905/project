<?php session_start(); 
include('UserHeader.php');

$val = !empty($_SESSION["uid_session"])?$_SESSION:" ";

if($val == " ")
{
	echo"<script>window.location.href='Login.php?logintype=user'</script>";
}
$uid_session = $_SESSION["uid_session"];

?>

<div class="container-fluid" style="margin-top:70px;">

<h5>Select Month:</h5>

	<div class="row">
		
      <div class="col-sm-2 text-center">
        <div class="circle circle1 btn_months">
          <h4 style="font-size:30px;" class="btn_months" id="01">JAN</h4>
        </div>
      </div>
      <div class="col-sm-2 text-center">
        <div class="circle circle1 btn_months">
          <h4 style="font-size:30px;" class="btn_months" id="02">FEB</h4>
        </div>
      </div>
     <div class="col-sm-2 text-center">
        <div class="circle circle1 btn_months">
          <h4 style="font-size:30px;" class="btn_months" id="03">MAR</h4>
        </div>
      </div>
      <div class="col-sm-2 text-center">
        <div class="circle circle1 btn_months">
          <h4 style="font-size:30px;" class="btn_months" id="04">APR</h4>
        </div>
      </div>
	  <div class="col-sm-2 text-center">
        <div class="circle circle1 btn_months">
          <h4 style="font-size:30px;" class="btn_months" id="05">MAY</h4>
        </div>
      </div>
	  <div class="col-sm-2 text-center">
        <div class="circle circle1 btn_months">
          <h4 style="font-size:30px;" class="btn_months" id="06">JUN</h4>
        </div>
      </div>
	  <div class="col-sm-2 text-center mt-2">
        <div class="circle circle1 btn_months">
          <h4 style="font-size:30px;" class="btn_months" id="07">JUL</h4>
        </div>
      </div>
	  <div class="col-sm-2 text-center mt-2">
        <div class="circle circle1 btn_months">
          <h4 style="font-size:30px;" class="btn_months" id="08">AUG</h2>
        </div>
      </div>
	   <div class="col-sm-2 text-center mt-2">
        <div class="circle circle1 btn_months">
          <h4 style="font-size:30px;" class="btn_months" id="09">SEPT</h4>
        </div>
      </div>
	   <div class="col-sm-2 text-center mt-2">
        <div class="circle circle1 btn_months">
          <h4 style="font-size:30px;" class="btn_months" id="10">OCT</h4>
        </div>
      </div>
	  <div class="col-sm-2 text-center mt-2">
        <div class="circle circle1 btn_months">
          <h4 style="font-size:30px;" class="btn_months" id="11">NOV</h4>
        </div>
      </div>
	  <div class="col-sm-2 text-center mt-2">
        <div class="circle circle1 btn_months">
          <h4 style="font-size:30px;" class="btn_months" id="12">DEC</h4>
        </div>
      </div>
    
	</div>
	
	
	<div class="col-md-6 mx-auto card shadow-lg p-3 bg-white rounded mt-3" id="table_months" style="display:none;">

		<h5>Vidhi Details: </h5><br/>
		
		   <table id="ViewTable" class="table table-striped table-bordered table-hover text-center" width="100%">
			<thead>
				<tr>	
					<th>Name</th>
					<th>Type</th>
					<th>Date</th>
					<th>Action</th>
				</tr>
			</thead>

			<tbody id="tbody_vidhis">
			
			
			</tbody>
			
			</table> 
			
	</div>
	
	
	
	</div>
	
	
	

</div>

<?php

include('Footer.php') 

?>	

<script type="text/javascript">

$('.btn_months').click(function(){
	
	var id = $(this).attr('id');
	
	$.ajax({
	  type: "POST",
	  url: "viewvidhis.php",
	  dataType: "json",
	  data:{id:id},
	  success: function(data){
		
		console.log(data);
		
		$("#tbody_vidhis").empty();
		
		var html = "";
		
		if(data!= "")
		{			
			$.each(data,function(key, val){
				
				html += "<tr><td>"+val.name+"</td><td>"+val.type+"</td><td>"+val.date+"</td><td><a href='ViewVidhisDetails.php?vid="+val.vid+"' class='btn btn-info'>View</a></td></tr>";
									
			});
						
		}
		else{
			
			html += "<tr><td colspan='4'>No records to display</td></tr>";
		}	
		
		$("#tbody_vidhis").append(html);
		$("#table_months").show();		
				
	  }
	  
	});
	
	
});






</script>
