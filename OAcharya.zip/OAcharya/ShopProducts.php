<?php session_start(); 
include('UserHeader.php');

$val = !empty($_SESSION["uid_session"])?$_SESSION:" ";

if($val == " ")
{
	echo"<script>window.location.href='Login.php?logintype=user'</script>";
}
$uid_session = $_SESSION["uid_session"];

?>


<div class="container-fluid" style="margin-top:70px;">

	<div class="row" id="searchbox">
        <div class="col-md-6 col-lg-6"> 
			<form method="POST">
				<div class="input-group" style="width: 60%;">
					<input name="search_name" type="text" class="form-control" placeholder="Search Product Name">
					<div class="input-group-btn">
						<button class="btn btn-primary" name="btn_search" type="submit">
							<i class="fa fa-search" aria-hidden="true" style="font-size: 17px;"></i>
						</button>
					</div>
				</div>
			</form>
		</div>          
    </div>


<div class="row ml-3 mr-3 mt-2">	

	<?php
	
	if(isset($_POST['btn_search']))
	{
		$select = "Select pid,pname,image,link from products where pname like '%".$_POST['search_name']."%'";
	}
	else
	{
	   $select = "Select pid,pname,image,link from products";
	}

		$rel=$con->query($select);
		if(mysqli_num_rows($rel)==0)
		{
			echo "<div class='col-md-12 col-lg-12 text-center'><h4>No records to display</h4></div>";
			echo "<script>document.getElementById('searchbox').style.display='none'</script>";
		}
		else
		{
			echo "<script>document.getElementById('searchbox').style.display='block'</script>";
			
			while($data=mysqli_fetch_array($rel))
			{
				$pid=$data['pid'];				
				$pname=$data['pname'];
				$image=$data['image'];
				$link=$data['link'];		

		?>


		<div class="card col-md-2 col-lg-2 mr-2 mt-2 feature-box">      
			<div class="" style="height:250px;">
				<center>
				
					<a href="<?php echo $link ?>" target="_blank"><img src="images/<?php echo $image ?>" class="img-responsive" alt="Product Images" style="height: 150px;">
					
					<h4 class="pt-2 text-center" style="font-size:15px;"><?php echo $pname ?></h4></a>
						<a href="<?php echo $link ?>" target="_blank"><input type="button" class="btn-buy" value="Buy"></a>
				
				</center>
			 
			</div>
		</div>
			
	 <?php
		
			}
			
		}
		
	 ?>	
	
</div>

</div>

<?php

include('Footer.php') 

?>	