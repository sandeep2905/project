<?php session_start();
include("connection.php");
?>

<!DOCTYPE html>
<html>
<head>
<title>OAcharya</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/style.css" />


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<script src="js/jquery.validate.min.js"></script>

</head>

<body style="background-image: url(images/Register-Banner.jpg); background-repeat: no-repeat; background-size: cover;">

 <div class="container-fluid mt-4">
	<div class="row">
	    <div class="col-md-7 mt-4 mx-auto shadow-lg p-3 mb-5 bg-white rounded">
		    <div class="col-md-12 text-center">
			    <h4 class="text-dark">User Registration</h4><br/>
		    </div>

		<form id="myform" method="POST">		
            <div class="row">
                <div class="col-md-6 col-lg-6">
                    <div class="form-group">
						<label style="font-size:15px;">First Name: </label>
						<input type="text" name="fname" class="form-control txtOnly" id="f_name" >
						
					</div>
                </div>

                <div class="col-md-6 col-lg-6">
                    <div class="form-group">
						<label style="font-size:15px;">Last Name: </label>
						<input type="text" name="lname" class="form-control txtOnly" id="l_name" >
						
					</div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 col-lg-6">
                     <div class="form-group">
					 <label style="font-size:15px;">Mobile No.: </label>
						<input type="number" name="mobno" class="form-control number" id="u_mob" >
						
					</div>
                </div>

                <div class="col-md-6 col-lg-6">
                     <div class="form-group">
					 <label style="font-size:15px;">Email ID: </label>
						<input type="email" name="emailid" class="form-control" id="u_emailid" >
						
					</div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 col-lg-6">
                     <div class="form-group">
					 <label style="font-size:15px;">Password: </label>
						<input type="password" name="pswd" class="form-control" id="u_pswd"  >
						
					</div>
                </div>

                <div class="col-md-6 col-lg-6">
                    <div class="form-group"> 
						<label style="font-size:15px;">Address:</label>					
						<textarea class="form-control" rows="3" name="addr" ></textarea>

                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 col-lg-6">
                    <div class="form-group">
						<label style="font-size:15px;" for="city">City: </label>
						<input type="text" name="city" class="form-control" id="u_city" >
						
					</div>
                </div>             
            </div>
			
			
			<div class="row text-center">
                <div class="col-md-12 col-lg-12">
					<button type="submit" class="btn btn-success" name="btn_submit">Submit</button>
				</div>
			</div>
			
		</form>
		
            <br />

            <center style="color: blue; font-weight: bold;"><a href="Login.php?logintype=user"> <i class="fa fa-arrow-left"></i> Sign In</a></center>

			<br/>

	    </div>
	</div>
	
</div>
	

<?php

if(isset($_POST['btn_submit'])){

$fname = $_POST['fname'];
$lname = $_POST['lname'];
$mobno = $_POST['mobno'];
$emailid = $_POST['emailid'];
$pswd = $_POST['pswd'];
$addr = $_POST['addr'];
$city = $_POST['city'];


	$var="select max(uid) as uid from user";
	$res_var=$con->query($var);
	$row = mysqli_fetch_assoc($res_var);
	$uid_row = $row['uid'];	
	if(!empty($uid_row))
	{
		$uid_arr = explode('-',$uid_row);
		$uid_val = $uid_arr[1] + 1;	
		$uid = 'U-'.$uid_val;
	}
	else
	{		
		$uid = 'U-101';						
	}
	

	$sel = "select emailid from user where emailid='$emailid'";
	$rel=$con->query($sel);	
	$data=mysqli_fetch_assoc($rel);	
	$emailid_data = $data['emailid'];
							
	if($emailid==$emailid_data)
	{
		echo "<script>alert('This Email ID is already registered');</script>";
	}	
	else
	{
		$insert = "Insert into user(uid,fname,lname,mobno,emailid,password,address,city,status) values('$uid','$fname','$lname','$mobno','$emailid','$pswd','$addr','$city','No')";

		if(mysqli_query($con,$insert)){
			
			echo "<script>alert('Registration successfull');</script>";
			echo "<script>window.location.href='Login.php?logintype=user'</script>";
		}
		else
		{
			echo "<script>alert('Invalid');</script>";
		}
	}	

}

?>	
	
	
<script type="text/javascript">

$(document).ready(function () {

   
 $( ".txtOnly" ).keypress(function(e) {
    var key = e.keyCode;
    if (key >= 48 && key <= 57) {
        e.preventDefault();
    }
 });
 
      
});
 

$(function()
    {
		
		$.validator.addMethod("atLeastOneLowercaseLetter", function (value, element) {
			return this.optional(element) || /[a-z]+/.test(value);
		}, "<h5 style='font-size:15px;'>Must have at least one lowercase letter</h5>");
		 		 
		$.validator.addMethod("atLeastOneUppercaseLetter", function (value, element) {
			return this.optional(element) || /[A-Z]+/.test(value);
		}, "<h5 style='font-size:15px;'>Must have at least one uppercase letter</h5>");
		 

		$.validator.addMethod("atLeastOneNumber", function (value, element) {
			return this.optional(element) || /[0-9]+/.test(value);
		}, "<h5 style='font-size:15px;'>Must have at least one number</h5>");
		 

	$("#myform").validate({ 
		rules: { 
		fname : "required",
		lname : "required",
		mobno : {
		  required:true,
		  number:true,
		  maxlength:10,
		  minlength:10
		},	
		emailid : "required",
		pswd : {
		required: true,
		atLeastOneLowercaseLetter: true,
		atLeastOneUppercaseLetter: true,
		atLeastOneNumber: true,
		minlength: 8,
		},
		addr : "required",
		city : "required",
		},	
		messages: { 
				fname:"<h5 style='font-size: 15px;'>Please Enter First Name</h5>",
				lname:"<h5 style='color:red;font-size: 15px;'>Please Enter Last Name</h5>",
				mobno:"<h5 style='font-size: 15px;'>Please Enter Mobile No.</h5>",
				emailid:"<h5 style='font-size: 15px;'>Please Enter Email ID</h5>",
				//pswd:"<h5 style='color:red;font-size: 15px;'>Please Enter Valid Password</h5>",
				addr:"<h5 style='font-size: 15px;'>Please Enter Address</h5>",
				city:"<h5 style='font-size: 15px;'>Please Enter City</b></h5>",
								
			} 

		});
	
	}); 

	
</script>	


</body>

</html>