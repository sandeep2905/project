<?php
include("connection.php");

$id = $_POST['id'];

$sel = "SELECT * FROM vidhi WHERE MONTH(Date) = ".$id;
$rel=$con->query($sel);
if(mysqli_num_rows($rel) == 0){
	$data1=[];
}	
while($data=mysqli_fetch_array($rel))
{
	$data1[] = $data;
} 

echo json_encode($data1);  
     
?>