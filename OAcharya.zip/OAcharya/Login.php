<?php session_start();
include("connection.php");


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if($_GET['logintype'] == "admin" || $_GET['logintype'] == "user" || $_GET['logintype'] == "pandit"){


?>

<!DOCTYPE html>
<html>
<head>
<title>OAcharya</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/style.css" />


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script src="js/jquery.validate.min.js"></script>

</head>

<body style="background: url(images/Login-Banner.jpg); background-repeat: no-repeat; background-size: cover; background-color: #ffffff5e; background-blend-mode: color-burn;">

<div class="container">
	<div class="row">
		<div class="col-md-5 col-lg-5 mt-4 mb-4 mx-auto bg-white shadow-lg p-3 rounded">
				<form id="myform" method="POST">
						<div class="row">
							<div class="col-sm-12">
								<?php
									
								if($_GET['logintype'] == "admin"){
									
								?>									
								<h1 class="h1-formbox">Admin Login</h1>
								<?php
										
								}
								else if($_GET['logintype'] == "user"){
								?>
								<h1 class="h1-formbox">User Login</h1>
								
								<?php
								}
								else if($_GET['logintype'] == "pandit"){
								?>
								<h1 class="h1-formbox">Pandit Login</h1>
								
								<?php
								}
								?>
								
							</div>
						</div>

						<div class="row">
							<div class="col-sm-12">
								<div class="inputBox">
								
									<?php
									
									if($_GET['logintype'] == "admin"){
									
									?>
									
									<div class="inputText">Admin Id</div>
									<input type="text" name="txtbx_adminid" class="input">
									
									<?php
										
									}
									else if($_GET['logintype'] == "user"){
									?>
									
									<div class="inputText">Email Id</div>
									<input type="text" name="txtbx_emailid" class="input">
									
									<?php
									}
									else if($_GET['logintype'] == "pandit"){
									?>
									
									<div class="inputText">Email Id</div>
									<input type="text" name="txtbx_emailid" class="input">
									
									<?php
									}
									?>
									
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-sm-12">
								<div class="inputBox">
									<div class="inputText">Password</div>
									<input type="password" name="txtbx_pswd" class="input">
																		
								</div>
							</div>
						</div>
						
						<div class="row mb-2">
							<div class="col-sm-12 text-center">
							
							<?php
									
							if($_GET['logintype'] == "admin"){
									
							?>
							<input type="submit" name="btn_adminlogin" class="button-adminlogin" value="Submit" />
							
							<?php										
							}
							else if($_GET['logintype'] == "user"){
							?>
							<input type="submit" name="btn_userlogin" class="button-adminlogin" value="Submit" /><br/><br/>
							
							Not a user? <a href="UserRegistration.php">Register Here</a>
							
							<?php										
							}
							else if($_GET['logintype'] == "pandit"){
							?>
							<input type="submit" name="btn_panditlogin" class="button-adminlogin" value="Submit" /><br/><br/>
							Not a user? <a href="PanditRegistration.php">Register Here</a>
							<?php										
							}
							
							
							?>							
								
							</div>
						</div>
						
						<center style="color: blue; font-weight: bold;"><a href="index.php"> <i class="fa fa-arrow-left"></i> Back To Home</a></center>
												
				</form>
		</div>
	</div>
		
</div>

<?php

if(isset($_POST['btn_adminlogin'])){
	
	$body = "";

	$txtbx_adminid = mysqli_real_escape_string($con,$_POST['txtbx_adminid']);
	$txtbx_pswd = mysqli_real_escape_string($con,$_POST['txtbx_pswd']);
	
	$sel = "select adminid from admin where adminid='$txtbx_adminid' and password='$txtbx_pswd'";
	$rel=$con->query($sel);	
		
	if($data=mysqli_fetch_array($rel))
	{
		$adminid = $data['adminid'];
			
		$_SESSION["adminid_session"] = $adminid;
		
		require 'Exception.php';
		require 'PHPMailer.php';
	    require 'SMTP.php';
		
		
			$sel1 = "Select name,date from vidhi where type='Occasion' and CURRENT_DATE = date - INTERVAL 3 DAY";
			$rel1=$con->query($sel1);
			if(mysqli_num_rows($rel1) > 0){
				
				$sel2 = "Select * from User where status = 'No'";
				$rel2=$con->query($sel2);		
				if(mysqli_num_rows($rel2) > 0){
					
							$sel = "select CONCAT(fname, ' ',lname) as username,emailid from user where status='No'";		
							$rel=$con->query($sel);			
									
							$body.="<h2 style='font-size:18px;'>Hello,</h2></br>
							<h3 style='font-size:17px; font-weight:bold;'>Upcoming Festivals</h3></br>";
							
							while($data1=mysqli_fetch_array($rel1)){
								$body.="<h3 style='font-size:17px; font-weight:normal;'>".$data1['name']." is on ".$data1['date']."</h3></br></br>";
							}
															
							$body.="<h4 style='font-size:16px; font-weight:normal;'>Regards,</h4>
							<h4>OAcharya</h4></br>";
											 
							$mail = new PHPMailer(); 
							$mail->IsSMTP(); // send via SMTP
							//IsSMTP(); // send via SMTP
																
							$mail->SMTPOptions = array(
												'ssl' => array(
									'verify_peer' => false,
									'verify_peer_name' => false,
									'allow_self_signed' => true
								)
							);
							$mail->SMTPAuth = true; // turn on SMTP authentication
							$mail->Host = "smtp.gmail.com"; 
							$mail->Port=587;
							//$mail->Host="localhost";
							$mail->Username = "mailtestingw@gmail.com"; // SMTP username(Your email id)
							$mail->Password = "testmail1234"; // SMTP password(Your password)
							$webmaster_email = "mailtestingw@gmail.com"; //Reply to this email ID(Your email id)
							//$email=$email; // Recipients email ID
							//$name=$name; // Recipient's name
							$mail->From = $webmaster_email;
							$mail->FromName = "OAcharya";
							
							while($data=mysqli_fetch_array($rel))
							{
								//$recipients = array($data['emailid'] => $data['name']);			
								$mail->AddAddress($data['emailid'],$data['username']);
							}

							$mail->AddReplyTo($webmaster_email,"OAcharya");
							$mail->WordWrap = 50; // set word wrap
							//$mail->AddAttachment("/var/tmp/file.tar.gz"); // attachment
							//$mail->AddAttachment("/tmp/image.jpg", "new.jpg"); // attachment
							$mail->IsHTML(true); // send as HTML
							$mail->Subject = "Notifications from OAcharya";
							$mail->Body = $body; //HTML Body
							$mail->AltBody = "Notifications from OAcharya"; //Text Body
							if(!$mail->Send())
							{
								echo "Mailer Error: " . $mail->ErrorInfo;
							}
							else
							{
								$upd = "Update user set status='Yes'";
		  
								if(mysqli_query($con, $upd))
								{		
											   
								} 
								else
								{
										
								}																
								//echo "<script>alert('Success');</script>";					
							}		
					
				}
											
			}
			else{
				
				$upd = "Update user set status='No'";
		  
				if(mysqli_query($con, $upd))
				{		
											   
				} 
				else
				{
										
				}
			}	
						
			echo "<script>window.location.href='AddVidhi.php'</script>";								
														
	}
	else
	{
		echo "<script>alert('Invalid Login');</script>";
	}
	

}

if(isset($_POST['btn_userlogin'])){

	$txtbx_emailid = $_POST['txtbx_emailid'];
	$txtbx_pswd = $_POST['txtbx_pswd'];
	
	$sel = "select uid from user where emailid='$txtbx_emailid' and password='$txtbx_pswd'";
	$rel=$con->query($sel);	
		
	if($data=mysqli_fetch_array($rel))
	{
		$uid = $data['uid'];
			
		$_SESSION["uid_session"] = $uid;
		
		echo "<script>window.location.href='ShopProducts.php'</script>";							
	}
	else
	{
		echo "<script>alert('Invalid Login');</script>";
	}
	
}

if(isset($_POST['btn_panditlogin'])){

	$txtbx_emailid = $_POST['txtbx_emailid'];
	$txtbx_pswd = $_POST['txtbx_pswd'];
	
	$sel = "select panid from pandit where emailid='$txtbx_emailid' and password='$txtbx_pswd'";
	$rel=$con->query($sel);	
		
	if($data=mysqli_fetch_array($rel))
	{
		$panid = $data['panid'];
			
		$_SESSION["panid_session"] = $panid;
		
		echo "<script>window.location.href='UserBookings.php'</script>";							
	}
	else
	{
		echo "<script>alert('Invalid Login');</script>";
	}
	
}

?>
 

<script type="text/javascript">

	$(".input").focus(function() {
		$(this).parent().addClass("focus");
	});
	
	
	$("#myform").validate({
            
            rules:{
				
				<?php
				if($_GET['logintype'] == "admin")
				{
				?>						
				txtbx_adminid: "required",
					
				<?php	 
				}
				else if($_GET['logintype'] == "user" || $_GET['logintype'] == "pandit"){
				?>
               	txtbx_emailid: "required",
                
				<?php
				}
				?>
				
				txtbx_pswd : "required",				
				
           },

            messages:{
				<?php
				if($_GET['logintype'] == "admin")
				{
				?>					
				txtbx_adminid:"<h5 style='font-size: 15px;'>Please Enter Admin Id</h5>",
				<?php
				}
				else if($_GET['logintype'] == "user" || $_GET['logintype'] == "pandit"){					
				?>
				txtbx_emailid:"<h5 style='font-size: 15px;'>Please Enter Email Id</h5>",
				<?php 
				}
				?>
                txtbx_pswd:"<h5 style='font-size: 15px;'>Please Enter Password</h5>",
                							
            },

            submitHandler: function(form){
                form.submit();
            }

        });
	
</script>


</body>

</html>


<?php

}
else{
	echo "<script>window.location.href = 'index.php';</script>";
}	

?>