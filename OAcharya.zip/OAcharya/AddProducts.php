<?php session_start();
include('AdminHeader.php');

$val = !empty($_SESSION["adminid_session"])?$_SESSION:" ";

if($val == " ")
{
	echo"<script>window.location.href='Login.php?logintype=admin'</script>";
}
$adminid_session = $_SESSION["adminid_session"];

?>


<div class="container" style="margin-top:70px;">

<form method="POST" id="myform" enctype="multipart/form-data">

<div class="row">
	<div class="col-md-8 mb-5 mx-auto">
	
		<div class="card">
		<div class="card-header"><b>Add Products</b></div>
		<div class="card-body">	
		
			<div class="row">
				<div class="col-md-12 col-lg-12">
					<div class="form-group">
						<label>Product Name: </label>
						<input type="text" name="txtbx_pname" class="form-control" placeholder="Enter Product Name" />						
					</div>
				</div>         
			</div>
					
			<div class="row">
				<div class="col-md-12 col-lg-12">
					<div class="form-group">
						<label for="file">Upload Image: </label><br/>
						<input type="file" id="file" name="fileToUpload" accept=".png, .jpg, .jpeg">
						<label id="validation_upload" style="color:black; font-size:14px; display:none;"></label>				
					</div>
				</div>         
			</div>	
					
			<div class="row mt-3">
				<div class="col-md-12 col-lg-12">
					<label>Buy Link: </label>
					<input type="text" name="link" id="input_link" class="form-control" placeholder="Enter Reference Link">	
					<span id="link_valdn" style="color:red; font-size:15px; display:none; font-weight:bold;">Please Enter Valid Buy Link</span>
				</div>
			</div>
									
		</div>
		
		<div class="card-footer text-center"><button type="submit" name="btn_submit" class="btn btn-info">Submit</button></div>
		
	  </div>
  
	 </div>
	</div>
	
</form>
	
</div>


<?php 

if(isset($_POST['btn_submit']))
{	
	$txtbx_pname = mysqli_real_escape_string($con,$_POST['txtbx_pname']);
	$link = mysqli_real_escape_string($con,$_POST['link']);
	
	$file=$_FILES['fileToUpload']['tmp_name'];
    $filename=$_FILES['fileToUpload']['name'];
	
	if(isset($filename))
    {    
        $location = 'images/';  

        $imageFileType = strtolower(pathinfo($location.$filename,PATHINFO_EXTENSION));


        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg")
        {
            echo "<script>document.getElementById('validation_upload').innerHTML='Sorry, only .jpg,.png,.jpeg above mentioned files are allowed.';</script>";
            echo "<script>document.getElementById('validation_upload').style.display = 'block';</script>";                  

        }
        else
        {
            if(move_uploaded_file($file, $location.$filename))
            {					
				$insert = "Insert into products(pname,image,link) values('$txtbx_pname','$filename','$link')";
	
				if(mysqli_query($con, $insert))
				{
					echo "<script>alert('Product Added Successfully');</script>";
					//echo "<script>window.location.href='PostNews.php'</script>";			
				}	
				else
				{
					echo "<script>alert('Invalid');</script>";
				}
																	
			}
			
		}
			
	}
					
}

include('Footer.php')

?>


<script type="text/javascript">

$( "#input_link" ).keyup(function() {
  $("#link_valdn").hide();
});

 $("#input_link").change(function(){
	 
	var url = $("#input_link").val();
	
	if(url != ""){
		
		if(/^(http|https|ftp):\/\/[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/i.test(url)) {
			$("#link_valdn").hide();
		  
		}else {
			$("#link_valdn").show();
			
			//return false;
		}   
		
	}	
		
  });


 $(".select_date").datepicker({
    dateFormat: "yy-mm-dd",
	minDate:+1,
});

 $(".select_date").keypress(function (evt) {
       evt.preventDefault();
  });
  

	$(function()
    {		
		$("#myform").validate({ 		
		
			rules: { 
			txtbx_pname : "required",
			fileToUpload : "required",	
			link : "required",
			},		
			messages: {
				
				txtbx_pname:"<h5>Please Enter Product Name</h5>",
				link:"<h5>Please Enter Buy Link</h5>",				
				fileToUpload:"<h5 style='font-size: 15px;'>Please Upload Image</h5>",
				
				},
				
			});
			
	});
	
		
</script>

</body>
</html>