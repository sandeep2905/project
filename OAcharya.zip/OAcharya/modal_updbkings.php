<?php
include("connection.php");

$bid = $_POST['id'];
$status = $_POST['status'];

$update = "Update Bookings set status='".$status."' where bid='".$bid."'";
if(mysqli_query($con, $update))
{
	echo "Success";				
}	
else
{
	echo "Invalid";
}
     
?>