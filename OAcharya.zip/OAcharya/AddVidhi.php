<?php session_start();
include('AdminHeader.php');

$val = !empty($_SESSION["adminid_session"])?$_SESSION:" ";

if($val == " ")
{
	echo"<script>window.location.href='Login.php?logintype=admin'</script>";
}
$adminid_session = $_SESSION["adminid_session"];

?>


<div class="container" style="margin-top:70px;">

<form method="POST" id="myform">

<div class="row">
	<div class="col-md-8 mb-5 mx-auto">
	
		<div class="card">
		<div class="card-header"><b>Add Vidhi</b></div>
		<div class="card-body">	
		
			<div class="row">
				<div class="col-md-12 col-lg-12">
					<div class="form-group">
						<label>Vidhi Name: </label>
						<input type="text" name="txtbx_vidhiname" class="form-control" placeholder="Enter Vidhi Name" />						
					</div>
				</div>         
			</div>
		
			<div class="row">
				<div class="col-md-12 col-lg-12">
					<div class="form-group container1">
						<label>Type: </label><br/>
						<label class="radio-inline">
							<input type="radio" name="optradio_type" value="Occasion"> Occasion
						</label>
						<label class="radio-inline">
						  <input type="radio" name="optradio_type" value="Event"> Event
						</label>
											
					</div>
				</div>         
			</div>
						
			<div class="row">
				<div class="col-md-12 col-lg-12">
					<div class="form-group">					
						<label>Select Date: </label>
						<input type="text" autocomplete="off" class="form-control select_date" placeholder="Select Date" name="txtbx_date">						
					</div>
				</div>
			</div>			
					
			<div class="row">
				<div class="col-md-12 col-lg-12">
					<div class="form-group">
						<label>How to prepare?: </label>
						<textarea class="form-control" name="txt_prepare" id="exampleFormControlTextarea3" placeholder="Step:1 Purify your home, Step 2: Set up puja platform and so on" rows="7"></textarea>						
					</div>
				</div>         
			</div>
			
			<div class="row">
				<div class="col-md-12 col-lg-12">
					<div class="form-group">
						<label>Samagri: </label>
						<textarea class="form-control" name="txt_samagri" id="exampleFormControlTextarea4" placeholder="Coconut * 2, Flowers * 15, Fruits * 4, Sweets(3 Boxes), Diya * 4, Kalash * 1" rows="7"></textarea>						
					</div>
				</div>         
			</div>
			
		</div>
		
		<div class="card-footer text-center"><button type="submit" name="btn_submit" class="btn btn-success">Submit</button></div>
		
	  </div>
  
	 </div>
	</div>
	
</form>
	
</div>


<?php 

if(isset($_POST['btn_submit']))
{	
	$txtbx_vidhiname = mysqli_real_escape_string($con,$_POST['txtbx_vidhiname']);
	$txtbx_date = mysqli_real_escape_string($con,$_POST['txtbx_date']);
	$txt_prepare = mysqli_real_escape_string($con,$_POST['txt_prepare']);
	$txt_samagri = mysqli_real_escape_string($con,$_POST['txt_samagri']);
	$optradio_type = mysqli_real_escape_string($con,$_POST['optradio_type']);

	$insert = "Insert into vidhi(name,type,date,preparation,samagri) values('$txtbx_vidhiname','$optradio_type','$txtbx_date','$txt_prepare','$txt_samagri')";
			
	if(mysqli_query($con, $insert))
	{
		echo "<script>alert('Vidhi Added Successfully');</script>";
		echo "<script>window.location.href='AddVidhi.php'</script>";			
	}	
	else
	{
		echo "<script>alert('Invalid');</script>";
	}
					
}

include('Footer.php')

?>


<script type="text/javascript">

 $(".select_date").datepicker({
    dateFormat: "yy-mm-dd",
	minDate:+1,
	
});

 $(".select_date").keypress(function (evt) {
       evt.preventDefault();
  });
  

	$(function()
    {		
		$("#myform").validate({ 		
		
			rules: { 
			txtbx_vidhiname : "required",
			optradio_type : "required",
			txtbx_date: "required",
			txt_prepare: "required",
			txt_samagri : "required",
			},		
			messages: {
				
				txtbx_vidhiname:"<h5>Please Enter Vidhi Name</h5>",
				optradio_type:"<h5>Please Select Type</h5>",
				txtbx_date:"<h5>Please Select Date</h5>",
				txt_prepare: "<h5>Please Enter Steps to Prepare</h5>",
				txt_samagri:"<h5>Please Enter Required Samagri</h5>",
				
				},
				errorPlacement: function(error, element) 
				{
				if ( element.is(":radio") ) 
				{
					error.appendTo( element.parents('.container1') );
				}
				else 
				{ // This is the default behavior 
					error.insertAfter( element );
				}
			 },

				
			});
			
	});
	
		
</script>

</body>
</html>