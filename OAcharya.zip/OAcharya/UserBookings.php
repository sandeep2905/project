<?php session_start(); 
include('PanditHeader.php');

$val = !empty($_SESSION["panid_session"])?$_SESSION:" ";

if($val == " ")
{
	echo"<script>window.location.href='Login.php?logintype=pandit'</script>";
}
$panid_session = $_SESSION["panid_session"];

?>


<div class="container-fluid" style="margin-top: 70px;">

    <div class="row">
        <div class="col-md-10 col-lg-10"> 
			<form method="POST" id="searchbox">
				<div class="input-group" style="width: 50%;">
					<input name="search_name" type="text" class="form-control" placeholder="Search User">				
					<div class="input-group-btn">
						<button class="btn btn-primary" name="btn_search" type="submit">
							<i class="fa fa-search" aria-hidden="true" style="font-size: 17px;"></i>
						</button>
					</div>
				</div>
			</form>
		</div>
		<div class="col-md-2 col-lg-2"> 
			<label>Select Booking Status:</label>
			<select class="form-control" id="selc_bookings" onchange="change_bkings()">
				<option value="Pending">Pending</option>
				<option value="Accepted">Accepted</option>
				<option value="Declined">Declined</option>
			</select>
		</div> 
    </div>
		
	<div class="row mt-3">
        <div class="col-md-12 col-lg-12 text-center" id="txtHint">
		   			
				<?php

				if(isset($_POST['btn_search']))
				{
					$sel = "Select CONCAT(u.fname, ' ', u.lname) as username,b.date,b.time,b.note,b.vidhiname,b.bid,b.status from bookings as b join user as u on b.uid = u.uid where b.panid='".$panid_session."' and CONCAT(u.fname, ' ', u.lname) LIKE '%".$_POST['search_name']."%' and (b.status='Pending' or b.status='Accepted' or b.status='Declined') Order by b.date desc";	
				}
				else
				{
				   $sel = "Select CONCAT(u.fname, ' ', u.lname) as username,b.date,b.time,b.note,b.vidhiname,b.bid,b.status from bookings as b join user as u on b.uid = u.uid where b.panid='".$panid_session."' and b.status='Pending' Order by b.date desc";		   
				}
			
				$rel=$con->query($sel);
				if(mysqli_num_rows($rel)==0)
				{			  
					echo "<center><h4>No records to display</h4></center>
					<script>document.getElementById('searchbox').style.display='none'</script>";
				}
				else
				{
					echo '<script>document.getElementById("searchbox").style.display="block"</script>        <table class="table table-striped table-bordered table-hover text-center" width="100%"><thead>
					<tr>
					<th>User</th>			
					<th>Vidhi</th>				
					<th>Date</th>
					<th>Time</th>
					<th>Note</th>
					<th>Action</th>
					</tr>
					</thead>

					<tbody>';
						  
					while($data=mysqli_fetch_array($rel))
					{
						$vidhiname = $data['vidhiname'];
						$username=$data['username'];						
						$date=$data['date'];
						$time=$data['time'];
						$note = $data['note'];						
											
						echo'<tr>
						<td>'.$username.'</td>
						<td>'.$vidhiname.'</td>
						<td>'.$date.'</td>
						<td>'.$time.'</td>
						<td>'.$note.'</td>';
						
						if($data['status'] == "Pending"){
							echo '<td><button class="btn btn-info btn_status" data-id="Accepted" id='.$data['bid'].'>Accept</button>&nbsp; &nbsp;<button data-id="Declined" class="btn btn-danger btn_status" id='.$data['bid'].'>Decline</button></td>';
						}
						else{
							echo'<td></td>';
							
						}	
						
						echo'</tr>';					
					}
					
					echo'</tbody></table>';
				}
									
				?>
								
				</div>
							
		</div>			
						
</div>	

<?php include('Footer.php') ?>


<script type="text/javascript">


$(document).on("click",".btn_status",function() {
	
	var id = $(this).attr('id');
	var status = $(this).attr('data-id');
	
	$.ajax({
	  type: "POST",
	  url: "modal_updbkings.php",
	  data:{id:id,status:status},
	  success: function(data){
		  
		  console.log(data);
		 	
		  if(data== "Success")
		  {
			alert("Status Updated Successfully");
			window.location.href="UserBookings.php";
		  }
		  else{
			  
			  
		  } 
		 
		 
	  }
	  
	});
	
 });


function change_bkings(){
	 
	var status_val = $('#selc_bookings').find(":selected").val(); 
	var panid = "<?php echo $panid_session ?>";
	 
	$.ajax({
	  type: "POST",
	  url: "viewbookings_admin.php",
	  dataType: "json",
	  data:{status_val:status_val,panid:panid},
	  success: function(data){
		  
		  console.log(data);
		  
		var html = '';
		$("#txtHint").empty();
		
		if(data!=""){
			
			html+='<table class="table table-striped table-bordered table-hover text-center" width="100%" ><thead><tr><th>User</th><th>Vidhi</th><th>Date</th><th>Time</th><th>Note</th><th>Action</th></tr></thead>';
			
			$.each(data,function(key, val){
				
				if(val.status == "Pending"){
					html += '<tr><td>'+val.username+'</td><td>'+val.vidhiname+'</td><td>'+val.date+'</td><td>'+val.time+'</td><td>'+val.note+'</td><td><button class="btn btn-info btn_status" data-id="Accepted" id='+val.bid+'>Accept</button>&nbsp; &nbsp;<button data-id="Declined" class="btn btn-danger btn_status" id='+val.bid+'>Decline</button></td></tr>';
				}
				else{
					html += '<tr><td>'+val.username+'</td><td>'+val.vidhiname+'</td><td>'+val.date+'</td><td>'+val.time+'</td><td>'+val.note+'</td><td>'+val.status+'</td></td></tr>';
					
				}	
				
			
									
			});
			
			html+='</table>';
			
			$("#txtHint").append(html);
			$("#searchbox").show();
		}	
		else{
			
			
			html+='<center><h4>No records to display</h4></center>';
			
			$("#txtHint").append(html);	
			$("#searchbox").hide();
		}
						  		  
		
			
			
	  }
	  
	});	 
	 
	 
 } 

</script>
