<?php session_start();
include('AdminHeader.php');

$val = !empty($_SESSION["adminid_session"])?$_SESSION:" ";

if($val == " ")
{
	echo"<script>window.location.href='Login.php?logintype=admin'</script>";
}
$adminid_session = $_SESSION["adminid_session"];

?>

<style>

tbody {
    display: block;
    height: 450px;
    overflow:auto;
}
thead, tbody tr {
    display:table;
    width:100%;
    table-layout:fixed;
}

tbody td{	
	word-break: break-word;	
}	


</style>

<div class="container-fluid" style="margin-top: 70px;">

    <div class="row" id="searchbox">
        <div class="col-md-6 col-lg-6"> 
			<form method="POST">
				<div class="input-group" style="width: 60%;">
					<input name="search_name" type="text" class="form-control" placeholder="Search">				
					<div class="input-group-btn">
						<button class="btn btn-primary" name="btn_search" type="submit">
							<i class="fa fa-search" aria-hidden="true" style="font-size: 17px;"></i>
						</button>
					</div>
				</div>
			</form>
		</div>          
    </div>
		
	<div class="row mt-3">
        <div class="col-md-12 col-lg-12 text-center">
		
		 <div class="table-responsive" id="ViewTableArea">
		   <table id="ViewTable" class="table table-striped table-bordered table-hover text-center" width="100%">				
				<?php

				if(isset($_POST['btn_search']))
				{
					$sel = "Select CONCAT(fname, ' ', lname) as panditname,mobno,emailid,address,city from pandit where fname like '%".$_POST['search_name']."%' or lname like '%".$_POST['search_name']."%' or mobno like '%".$_POST['search_name']."%' or emailid like '%".$_POST['search_name']."%' or address like '%".$_POST['search_name']."%' or city like '%".$_POST['search_name']."%' or CONCAT(fname, ' ', lname) LIKE '".$_POST['search_name']."%'";	
				}
				else
				{
				   $sel = "Select CONCAT(fname, ' ', lname) as panditname,mobno,emailid,address,city from pandit";		   
				}
			
				$rel=$con->query($sel);
				if(mysqli_num_rows($rel)==0)
				{			  
					echo "<center><h4>No records to display</h4></center>
					<script>document.getElementById('searchbox').style.display='none'</script>";
				}
				else
				{
					echo '<script>document.getElementById("searchbox").style.display="block"</script>        <thead>
					<tr>
					<th>Name</th>		
					<th>Mobile No.</th>				
					<th>Email Id</th>
					<th>Address</th>
					<th>City</th>
					</tr>
					</thead>

					<tbody>';
						  
					while($data=mysqli_fetch_array($rel))
					{
						$panditname = $data['panditname'];
						$mobno=$data['mobno'];							
						$emailid=$data['emailid'];
						$address=$data['address'];
						$city = $data['city'];						
											
						echo'<tr>
						<td>'.$panditname.'</td>
						<td>'.$mobno.'</td>
						<td>'.$emailid.'</td>
						<td>'.$address.'</td>
						<td>'.$city.'</td>		
						</tr>';					
					}
					
					echo'</tbody>';
				}
									
				?>
				
				</table> 
				</div>
				
			</div>
		</div>			
						
</div>	

<?php include('Footer.php') ?>
