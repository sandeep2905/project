<?php
include("connection.php");

$status_val = $_POST['status_val'];

if(isset($_POST['uid'])){
	
	$sel = "Select CONCAT(p.fname, ' ', p.lname) as panditname,b.date,b.time,b.note,b.vidhiname,b.status from bookings as b join pandit as p on b.panid = p.panid where b.uid='".$_POST['uid']."' and b.status='".$status_val."' Order by b.date desc";	
}	
else if(isset($_POST['panid'])){
	
	$sel = "Select CONCAT(u.fname, ' ', u.lname) as username,b.date,b.time,b.note,b.vidhiname,b.bid,b.status from bookings as b join user as u on b.uid = u.uid where b.panid='".$_POST['panid']."' and b.status='".$status_val."' Order by b.date desc";	
}
else if(isset($_POST['adminid'])){
	
	$sel = "Select CONCAT(u.fname, ' ', u.lname) as username,CONCAT(p.fname, ' ', p.lname) as panditname,b.date,b.time,b.note,b.vidhiname,b.bid,b.status from bookings as b join user as u on b.uid = u.uid join pandit as p on b.panid = p.panid and b.status='".$status_val."' Order by b.date desc";		
}

$rel=$con->query($sel);
if(mysqli_num_rows($rel) == 0){
	
	$data1 = [];
}
else{
	while($data=mysqli_fetch_array($rel))
	{
		$data1[] = $data;
	}
}	
 

echo json_encode($data1);  
     
?>