<?php session_start(); 
include('UserHeader.php');

$val = !empty($_SESSION["uid_session"])?$_SESSION:" ";

if($val == " ")
{
	echo"<script>window.location.href='Login.php?logintype=user'</script>";
}
$uid_session = $_SESSION["uid_session"];

$vid = $_GET['vid'];

$sel = "Select name,type,date,preparation,samagri from vidhi";
$rel=$con->query($sel);
if($data = mysqli_fetch_array($rel)){
	$name = $data['name'];
	$type = $data['type'];
	$date = $data['date'];
	$preparation = $data['preparation'];
	$samagri = $data['samagri'];
}	

?>


<div class="container-fluid" style="margin-top: 70px;">

	<div class="col-md-6 mx-auto card shadow-lg p-3 bg-white rounded mt-3 mb-3" id="table_months">
		<div class="row">
			<div class="col-md-6 col-lg-6">
				<div class="form-group">
					<label><b>Name:</b></label>
					<input type="text" class="form-control" readonly value="<?php echo $name ?>" />
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-md-6 col-lg-6">
				<label><b>Type: </b><?php echo $type ?><label>				
			</div>
		</div>
		
		<div class="row">
			<div class="col-md-12 col-lg-12">
				<div class="form-group">					
					<label><b>Date: </b></label>
					<input type="text" class="form-control" value="<?php echo $date ?>" readonly>						
				</div>
			</div>
		</div>	
		
		<div class="row">
			<div class="col-md-12 col-lg-12">
				<div class="form-group">
					<label><b>Pooja Vidhi: </b></label>
					<textarea class="form-control" rows="7" readonly><?php echo $preparation ?></textarea>						
				</div>
			</div>         
		</div>
		
		<div class="row">
			<div class="col-md-12 col-lg-12">
				<div class="form-group">
					<label><b>Pooja Samagri: </b></label>
					<textarea class="form-control" rows="7" readonly><?php echo $samagri ?></textarea>						
				</div>
			</div>         
		</div>
		
		<div class="row mx-auto">
			<div class="col-md-8 col-lg-8">
				<a href="BookPandit.php" class="btn btn-success">Book pandit</a>
			</div>
			<div class="col-md-4 col-lg-4">
				<a href="ShopProducts.php" class="btn btn-primary">Shop</a>
			</div> 			
		</div>
		
	</div>

</div> 



<?php include('Footer.php') ?>
