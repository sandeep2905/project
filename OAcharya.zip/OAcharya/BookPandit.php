<?php session_start(); 
include('UserHeader.php');

$val = !empty($_SESSION["uid_session"])?$_SESSION:" ";

if($val == " ")
{
	echo"<script>window.location.href='Login.php?logintype=user'</script>";
}
$uid_session = $_SESSION["uid_session"];

$sel = "Select address from user where uid='".$uid_session."'";
$rel=$con->query($sel);
if($data = mysqli_fetch_array($rel)){
	$address = $data['address'];
}	

?>

<style>

.tbody {
    display: block;
    height: 450px;
    overflow:auto;
}
.thead, .tbody tr {
    display:table;
    width:100%;
    table-layout:fixed;
}

.tbody td{	
	word-break: break-word;	
}	


</style>

<div class="container-fluid" style="margin-top: 70px;">

    <div class="row" id="searchbox">
        <div class="col-md-6 col-lg-6"> 
			<form method="POST">
				<div class="input-group" style="width: 60%;">
					<input name="search_name" type="text" class="form-control" placeholder="Search Location">				
					<div class="input-group-btn">
						<button class="btn btn-primary" name="btn_search" type="submit">
							<i class="fa fa-search" aria-hidden="true" style="font-size: 17px;"></i>
						</button>
					</div>
				</div>
			</form>
		</div>          
    </div>
		
	<div class="row mt-3">
        <div class="col-md-12 col-lg-12 text-center">
		
		 <div class="table-responsive" id="ViewTableArea">
		   <table id="ViewTable" class="table table-striped table-bordered table-hover text-center" width="100%">				
				<?php

				if(isset($_POST['btn_search']))
				{
					$sel = "Select CONCAT(fname, ' ', lname) as panditname,mobno,emailid,address,city,panid from pandit where address like '%".$_POST['search_name']."%' or city like '%".$_POST['search_name']."%'";	
				}
				else
				{
				   $sel = "Select CONCAT(fname, ' ', lname) as panditname,mobno,emailid,address,city,panid from pandit";		   
				}
			
				$rel=$con->query($sel);
				if(mysqli_num_rows($rel)==0)
				{			  
					echo "<center><h4>No records to display</h4></center>
					<script>document.getElementById('searchbox').style.display='none'</script>";
				}
				else
				{
					echo '<script>document.getElementById("searchbox").style.display="block"</script>        <thead class="thead">
					<tr>
					<th>Name</th>		
					<th>Mobile No.</th>				
					<th>Email Id</th>
					<th>Address</th>
					<th>City</th>
					<th>Action</th>
					</tr>
					</thead>

					<tbody class="tbody">';
						  
					while($data=mysqli_fetch_array($rel))
					{
						$panditname = $data['panditname'];
						$mobno=$data['mobno'];							
						$emailid=$data['emailid'];
						$address=$data['address'];
						$city = $data['city'];
						$panid = $data['panid'];	
											
						echo'<tr>
						<td>'.$panditname.'</td>
						<td>'.$mobno.'</td>
						<td>'.$emailid.'</td>
						<td>'.$address.'</td>
						<td>'.$city.'</td>
						<td><button class="btn btn-info btn_book" id='.$panid.'>Book</button></td>
						</tr>';					
					}
					
					echo'</tbody>';
				}
									
				?>
				
				</table> 
				</div>
				
			</div>
		</div>			
						
</div>	


<div class="modal small fade" id="Modal_Book" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" style="max-width: 600px;">
        <div class="modal-content">
            <div class="modal-header">              
                <h3 class="modal-title">Book Pandit</h3>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
			
			<form id="myform" method="post">
            <div class="modal-body">
					
			<div class="row">
				<div class="col-md-12 col-lg-12">
					<div class="form-group">
						<label>Vidhi Name: </label>
						<input type="text" name="txtbx_vidhiname" class="form-control" placeholder="Enter Vidhi Name" />						
					</div>
				</div>         
			</div>
			
			<div class="row">
				<div class="col-md-12 col-lg-12">
					<div class="form-group">					
						<label>Select Date: </label>
						<input type="text" autocomplete="off" class="form-control select_date" placeholder="Select Date" name="txtbx_date">						
					</div>
				</div>
			</div>	

			<div class="row">
				<div class="col-md-4 col-lg-4">
					<div class="form-group">					
						<label>Select Time: </label>
						<input type="text" autocomplete="off" class="form-control selc_time" placeholder="Select Time" name="txtbx_time">						
					</div>
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-6 col-lg-6">
					<div class="form-group">
						<label>Note: </label>
						<textarea class="form-control" name="txtbx_note" placeholder="Enter Note" rows="4"></textarea>						
					</div>
				</div>         
			</div>

			<div class="row">
				<div class="col-md-6 col-lg-6">
					<div class="form-group">
						<label>Venue: </label>
						<textarea class="form-control" name="txtbx_venue" placeholder="Enter Venue" rows="4"><?php echo $address ?>	</textarea>						
					</div>
				</div>         
			</div>		
		
			<input type="hidden" value="" id="panid" name="txtbx_panid"/>
						  
			</div>
			
            <div class="modal-footer">
                <button class="btn btn-default" data-dismiss="modal" aria-hidden="true">Close</button> <input type="submit" name="btn_submit" class="btn btn-primary" value="Submit"/>
            </div>
		</form>
      
    </div>
	</div>
</div>	



<?php 

if(isset($_POST['btn_submit']))
{		
	$txtbx_vidhiname = mysqli_real_escape_string($con,$_POST['txtbx_vidhiname']);	
	$txtbx_date = mysqli_real_escape_string($con,$_POST['txtbx_date']);
	$txtbx_time = mysqli_real_escape_string($con,$_POST['txtbx_time']);
	$txtbx_note = mysqli_real_escape_string($con,$_POST['txtbx_note']);
	$txtbx_panid = mysqli_real_escape_string($con,$_POST['txtbx_panid']);
	$txtbx_venue = mysqli_real_escape_string($con,$_POST['txtbx_venue']);
	
	
	$var="select max(bid) as bid from bookings";
	$res_var=$con->query($var);
	$row = mysqli_fetch_assoc($res_var);
	$bid_row = $row['bid'];	
	if(!empty($bid_row))
	{
		$bid_arr = explode('-',$bid_row);
		$bid_val = $bid_arr[1] + 1;	
		$bid = 'BId-'.$bid_val;
	}
	else
	{		
		$bid = 'BId-1';						
	}
	
	$sel = "select * from bookings where panid='$txtbx_panid' and date='$txtbx_date' and time='$txtbx_time'";
	$rel=$con->query($sel);	
								
	if(mysqli_num_rows($rel) > 0)
	{
		echo "<script>alert('Booking already exists');</script>";
	}	
	else{
		
		$insert = "Insert into bookings (bid, panid, uid, vidhiname, date, time, note, venue,status) values('$bid','$txtbx_panid','$uid_session','$txtbx_vidhiname','$txtbx_date','$txtbx_time','$txtbx_note','$txtbx_venue','Pending')";

		if(mysqli_query($con, $insert))
		{
			echo "<script>alert('Booking Done Successfully');</script>";
			echo "<script>window.location.href='MyBookings.php'</script>";			
		}	
		else
		{
			echo "<script>alert('Invalid');</script>";
		}
		
	}	
	
		
}


include('Footer.php') ?>


<script type="text/javascript">


$(document).on("click",".btn_book",function() {
	
	var id = $(this).attr('id');
	
	$('#Modal_Book').modal('show');
		
	$("#panid").val(id);
	
 });

 
$(".select_date").datepicker({
    dateFormat: "yy-mm-dd",
	minDate:+1,
});

 $(".select_date").keypress(function (evt) {
       evt.preventDefault();
  });
  

$('.selc_time').timepicker({
    minTime: '8:00am',
    maxTime: '8:00pm',
});


$(function()
    {		
		$("#myform").validate({ 		
		
			rules: { 
			txtbx_vidhiname : "required",
			txtbx_date: "required",
			txtbx_time: "required",
			txtbx_note : "required",
			txtbx_venue : "required",
			},		
			messages: {
				
				txtbx_vidhiname:"<h5>Please Enter Vidhi Name</h5>",
				txtbx_date:"<h5>Please Select Date</h5>",
				txtbx_time: "<h5>Please Select Time</h5>",
				txtbx_note:"<h5>Please Enter Note</h5>",
				txtbx_venue:"<h5>Please Enter Venue</h5>",
				
				},			
				
			});
			
	});

</script>
