<?php
include("connection.php");
?>

<!DOCTYPE html>
<html>
<head>
<title>OAcharya</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="http://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css"/>
<link rel="stylesheet" href="css/jquery.timepicker.min.css" />
<link rel="stylesheet" href="css/style.css" />

</head>

<body>

<div class="sticky">

<nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background-color: #99210e;">
  <a class="navbar-brand" href="#" style="color:white; font-family: cursive; font-size:24px;">OAcharya</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
    <ul class="navbar-nav">
	  <li class="nav-item">
        <a class="nav-link" href="ShopProducts.php">Shop Products</a>
      </li>	
	  <li class="nav-item">
        <a class="nav-link ones" href="Vidhis.php">Pooja Vidhis</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="BookPandit.php">Book Pandit</a>
      </li>	
	  <li class="nav-item">
        <a class="nav-link" href="MyBookings.php">My Bookings</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="ChangePassword.php">Change Password</a>
      </li>	  
	  <li class="nav-item">
        <a class="nav-link" href="Logout.php"><span class="fa fa-sign-in"></span> Logout</a>
      </li>
    </ul>
  </div>
</nav>