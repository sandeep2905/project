<?php session_start(); 
include('UserHeader.php');

$val = !empty($_SESSION["uid_session"])?$_SESSION:" ";

if($val == " ")
{
	echo"<script>window.location.href='Login.php?logintype=user'</script>";
}
$uid_session = $_SESSION["uid_session"];

?>

<div class="container-fluid" style="margin-top:7%;">

	<div class="row">
	<div class="col-md-4 col-lg-4 mt-4 mx-auto bg-white shadow-lg p-3 mb-5 rounded">
		<div class="col-md-12 text-center">
			<h5 class="text-primary">Change Your Account Password</h5>
		</div>
		
		<br/>
		
		<form id="form1" method="post">
		
		    <div class="form-group">
				<label>Old Password:</label>
				<input type="password" id="oldpass_id" class="form-control" placeholder="Enter Old Password" name="oldpass"/>
				<h5 style="display:none;" class="error" id="oldpswd_val">Old password does not match</h5>
				
			</div>
					 
		  <div class="form-group">
			<label>New Password:</label>
			<input type="password" class="form-control" id="newpass" placeholder="Enter New Password" name="newpass" />
		  </div>
		  
		  <div class="form-group">
			<label for="pwd">Confirm Password:</label>
			<input type="password" class="form-control" name="confpwd" placeholder="Enter Confirm Password" />
		  </div> 
		  
		  <input type="hidden" value="<?php echo $uid_session ?>" name="uid"/>
		  <button type="submit" class="btn btn-primary">Submit</button>
		
		</form>
		
		 <br/>
		
	</div>
	</div>

</div>

<?php 
include('footer.php')
?>

<script type="text/javascript" language="javascript" >
	
	$(function(){
		
		$.validator.addMethod("atLeastOneLowercaseLetter", function (value, element) {
			return this.optional(element) || /[a-z]+/.test(value);
		}, "<h5 style='color:red; font-size:15px;'>Must have at least one lowercase letter</h5>");
		 		 
		$.validator.addMethod("atLeastOneUppercaseLetter", function (value, element) {
			return this.optional(element) || /[A-Z]+/.test(value);
		}, "<h5 style='color:red; font-size:15px;'>Must have at least one uppercase letter</h5>");
		 

		$.validator.addMethod("atLeastOneNumber", function (value, element) {
			return this.optional(element) || /[0-9]+/.test(value);
		}, "<h5 style='color:red; font-size:15px;'>Must have at least one number</h5>");
		
		
	$( "#form1" ).validate({
	  rules: {
		  oldpass:"required",
		  newpass : {
			required: true,
			atLeastOneLowercaseLetter: true,
			atLeastOneUppercaseLetter: true,
			atLeastOneNumber: true,
			minlength: 8,
			},
		  confpwd:{
		  equalTo: "#newpass"
		  }
	  },
		messages: {
			oldpass: "<h5 style='font-size: 15px;'>Please Enter Valid Old Password</h5>",
			//newpass: "<h5 style='font-size: 15px;'>Please Enter Valid New Password</h5>",
			confpwd: "<h5 style='font-size: 15px;'>Please Enter Confirm Password Same as New Password</h5>"
		},
	});
	
 });
	
	
	
	
$(document).on('submit', '#form1', function(event){
  
	event.preventDefault();
	
	//var myform = document.getElementById("form1");
    //var fd = new FormData(myform );
	
	$.ajax({
	  type: "POST",
	  url: "ChangePassword_upd.php",
	  data:new FormData(this),	
	  contentType: false,
      cache: false,
      processData:false,
	  success: function(data){
		  	
			if(data == "Updated"){
				
				$("#oldpswd_val").hide();
				
				alert("Password Updated Successfully");
				window.location.href="ChangePassword.php";	
				
			}
			else if(data == "No match"){
				
				$("#oldpswd_val").show();
				
			}						
	  }
	  
	});
	
});
	
	
	
	
	
	
	
</script>