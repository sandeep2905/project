-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 08, 2020 at 01:16 PM
-- Server version: 5.7.21
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `oacharya`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `adminid` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminid`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
CREATE TABLE IF NOT EXISTS `bookings` (
  `bid` varchar(100) NOT NULL,
  `panid` varchar(100) NOT NULL,
  `uid` varchar(100) NOT NULL,
  `vidhiname` varchar(800) NOT NULL,
  `date` varchar(100) NOT NULL,
  `time` varchar(50) NOT NULL,
  `note` text NOT NULL,
  `venue` text NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`bid`, `panid`, `uid`, `vidhiname`, `date`, `time`, `note`, `venue`, `status`) VALUES
('BId-1', 'PAN-101', 'U-101', 'Makar sankranti Pooja at home', '2020-01-15', '10:00am', 'Test', 'Goregaon East	', 'Accepted'),
('BId-2', 'PAN-101', 'U-101', 'Diwali Lakshmi Pooja', '2020-10-31', '7:30pm', 'Test', 'Goregaon East	', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `pandit`
--

DROP TABLE IF EXISTS `pandit`;
CREATE TABLE IF NOT EXISTS `pandit` (
  `panid` varchar(200) NOT NULL,
  `fname` varchar(200) NOT NULL,
  `lname` varchar(200) NOT NULL,
  `mobno` varchar(50) NOT NULL,
  `emailid` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pandit`
--

INSERT INTO `pandit` (`panid`, `fname`, `lname`, `mobno`, `emailid`, `password`, `address`, `city`) VALUES
('PAN-101', 'Mohanlal', 'Sharma', '9823456789', 'mohan@gmail.com', 'Mohan123', 'Goregaon East', 'Mumbai');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pname` varchar(500) NOT NULL,
  `image` varchar(10000) NOT NULL,
  `link` varchar(200) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`pid`, `pname`, `image`, `link`) VALUES
(1, 'The Holy Mart Cotton Cloth for Puja (Red)', 'pooja-red-cloth-500x500.jpg', 'https://www.amazon.in/Cloth-Puja-Holy-Mart-kapda/dp/B0736RTFPL?ref_=fsclp_pl_dp_7'),
(2, 'Diyas for Pooja', 'download (9).jpg', 'https://www.amazon.in/ITOS365-Ganehsa-Brass-Diyas-Pooja/dp/B015EOMZ36?ref_=fsclp_pl_dp_11');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `uid` varchar(100) NOT NULL,
  `fname` varchar(200) NOT NULL,
  `lname` varchar(200) NOT NULL,
  `mobno` varchar(50) NOT NULL,
  `emailid` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `fname`, `lname`, `mobno`, `emailid`, `password`, `address`, `city`) VALUES
('U-101', 'Ram', 'Mehta', '9823456278', 'ram@gmail.com', 'Rammehta1234', 'Andheri', 'Mumbai'),
('U-102', 'Sam', 'Dsouza', '8976234567', 'sam@gmail.com', 'Samdsouza123', 'Goregaon', 'Mumbai');

-- --------------------------------------------------------

--
-- Table structure for table `vidhi`
--

DROP TABLE IF EXISTS `vidhi`;
CREATE TABLE IF NOT EXISTS `vidhi` (
  `vid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `type` varchar(50) NOT NULL,
  `date` varchar(100) NOT NULL,
  `preparation` text NOT NULL,
  `samagri` text NOT NULL,
  PRIMARY KEY (`vid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vidhi`
--

INSERT INTO `vidhi` (`vid`, `name`, `type`, `date`, `preparation`, `samagri`) VALUES
(1, 'Diwali Puja Vidhi', 'Occasion', '2020-10-31', 'Step 1: Purify your home,\r\nStep 2: Set up puja platform,\r\nStep 3: Place a kalash, \r\nStep 4: Place idol of Lakshmi and Ganesha for puja\r\nStep 5: Place accounts books/wealth related items\r\nStep 6: Apply tilak and light diya\r\nStep 7: Offer flowers\r\nStep 8: Recite Puja Mantra\r\nStep 9: Offer water\r\nStep 10: Offer mala (garland)\r\nStep 11: Offer fruits and sweets\r\nStep 12: Perform Lakshmi Aarti', 'Coconut * 2, Flowers * 15, Fruits * 4, Sweets(3 Boxes), Diya * 4, Kalash * 1, Agarbathi(4 packets), Idols * 2'),
(2, 'Makar sankranti', 'Occasion', '2020-01-15', 'Step1: Break Coconut at worship place,\r\nStep2: Sprinkle Gangajal on Samagri and place\r\nStep3: Lit a diya with two wicks or two lamps\r\nStep4: First worship to Lord Ganesh\r\nStep5: Next worship to Lord Surya\r\nStep6: Put flowers,garlands,tilak,dakshina(coins) on photo of Lord Surya\r\nStep7: Place Sweets(Til and Gud Ladoo) ', 'Coconut * 2, Flowers * 4, Idols * 2, Diyas * 3, Tilak,Sweets (Boxes * 8), Flat Stools, Small bottle of Gangajal');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
