<?php
include("connection.php");

$oldpass = $_POST['oldpass'];	
$newpass = $_POST['newpass'];
$uid = $_POST['uid'];

$pswrd =  "";	

if($oldpass!="" && $newpass !="")
{	
	$sel = "select password from user where uid='".$uid."'";
	$rel=$con->query($sel);
	$data=mysqli_fetch_assoc($rel);		
	$password_fetch = $data['password'];
		
	if($password_fetch != $oldpass)
	{
		$pswrd = 'No match';
	}
	else
	{			
		$update = "Update user set password='".$newpass."' where uid='".$uid."'";				
		if(mysqli_query($con, $update))
		{
			$pswrd = 'Updated';		
		}	
		else
		{
			echo "<script>alert('Invalid');</script>";
		}
			
	} 
}

echo $pswrd;
	
    
?>