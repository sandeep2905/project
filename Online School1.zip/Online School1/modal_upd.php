<?php
include("connection.php");

$tid = $_POST['id'];
$sel = "select name,gender,dateofbirth,emailid,contactno,schoolname,address,city,qualification,dept from teacher where tid='$tid'";
$rel=$con->query($sel);
while($data = mysqli_fetch_array($rel))
{
	$output['name'] = $data['name'];
	$output['gender'] = $data['gender'];
	$output['dateofbirth'] = $data['dateofbirth'];
	$output['emailid'] = $data['emailid'];
	$output['contactno'] = $data['contactno'];
	$output['schoolname'] = $data['schoolname'];
	$output['address'] = $data['address'];
	$output['city'] = $data['city'];
	$output['qualification'] = $data['qualification'];
	$output['dept'] = $data['dept'];
} 
echo json_encode($output);       
?>