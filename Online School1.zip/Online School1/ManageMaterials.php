<?php include('TeacherHeader.php');

$val = !empty($_SESSION["tid_session"])?$_SESSION:" ";

if($val == " ")
{
	echo"<script>window.location.href='TeacherLogin.php'</script>";
}
$tid_session = $_SESSION["tid_session"];
?>


<div class="content">
<div class="container">

<?php
		
$search_name="";

if(isset($_POST['btn_search']))
{
   $search_name = $_POST['search_name'];
}
else
{
   $search_name = "";   
}
	

if($search_name == "")
{
	$sel = "select materialid,subj,name,description,file from materials where tid='$tid_session'";	  	
}
else
{
    $sel = "select materialid,subj,name,description,file from materials where tid='$tid_session' and name like '%$search_name%'";
}

?>

<div class="modal small fade" id="myModal_Del" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                
                 <h3 id="myModalLabel">Delete Confirmation</h3>

            </div>
            <div class="modal-body">
                <p class="error-text" style="font-size:17px;"><i class="fa fa-warning modal-icon"></i> Are you sure you want to delete?
                    </p>
            </div>
            <div class="modal-footer">
               <button class="btn btn-default"data-dismiss="modal" aria-hidden="true">No</button> <a href="#" class="btn btn-danger" id="modalDelete" >Yes</a>

            </div>
        </div>
    </div>
</div>

<div class="row">
<div class="col-md-6 col-lg-6">
	<div id="searchbox">
	 <form method="post">
		<div class="input-group" style="width: 60%;">
			<input name="search_name" type="text" class="form-control" placeholder="Search Material Name">
			<div class="input-group-btn">
				<button class="btn btn-primary" name="btn_search" type="submit">
					<i class="fa fa-search" aria-hidden="true" style="font-size: 25px;"></i>
				</button>
			</div>
		</div>	
	  </form>	
	</div>		
</div>


<div class="col-md-6 col-lg-6" align="right">
	<button class="btn btn-primary" style="width:10%;" id="btn_add">Add</button>
</div>
</div>

</br>

	<table class="table table-bordered table-hover">
			
	<?php
						
	$rel=$con->query($sel);
	if(mysqli_num_rows($rel)==0)
	{			  
		echo "<center><h3>No records to display</h3></center>";
		echo "<script>document.getElementById('searchbox').style.display='none'</script>";
	}
	else
	{
		echo "<script>document.getElementById('searchbox').style.display='block'</script>";	
		echo'<thead style="background-color:grey;color:white">           
		<tr>                  						
		<th>Subject</th>
		<th>Material Name</th>
		<th>Description</th>
		<th>File</th>
		<th>Action</th>
		<th>Action</th>
		</tr>
		</thead>

		<tbody>';
			  
		while($data=mysqli_fetch_array($rel))
		{
			$materialid=$data['materialid'];
			$subj=$data['subj'];			
			$name=$data['name'];
			$file=$data['file'];
			$description=$data['description'];	
			
			echo'<tr>
			<td>'.$subj.'</td>
			<td>'.$name.'</td>
			<td>'.$description.'</td>
			<td><a href="DownloadFile_Matr.php?materialid='.$materialid.'">'.$file.'</a></td>
			<td><button class="btn btn-primary btn_update" id="'.$materialid.'">Update</button></td>		
			<td><a href="#myModal_Del" class="btn btn-danger trash" id="'.$materialid.'" role="button" data-toggle="modal">Delete</a></td>				
			</tr>';
			
		}
		echo"</tbody>";
	}		
			
	?>
				 
  </table>
  
  
<?php 
  
if(isset($_POST['btn_submit']))
{
	$cid = $_POST['cid'];

	$sel = "select subject from course where cid='$cid'";
	$rel=$con->query($sel);			
	$data=mysqli_fetch_assoc($rel);
	$subject = $data['subject'];
	
    $material_name = $_POST['material_name'];
	$descr = $_POST['descr'];
    
	$file=$_FILES['fileToUpload']['tmp_name'];
    $iname=$_FILES['fileToUpload']['name'];
	
	
	if($cid == "nodata")
	{
		echo "<script>alert('Please Select Valid Subject');</script>";
	}
	else
	{
		if(isset($iname))
       {                 
                $location = 'files/';  

                $FileType = strtolower(pathinfo($location.$iname,PATHINFO_EXTENSION));

                if($FileType != "jpg" && $FileType != "png" && $FileType != "jpeg" && $FileType != "doc" && $FileType != "docx" && $FileType != "pdf")
                {
                    echo "<script>document.getElementById('validation_upload').innerHTML='Sorry, only .jpg,.png,.jpeg,.doc,.docx,.pdf files are allowed.';</script>";
                    echo "<script>document.getElementById('validation_upload').style.display = 'block';</script>";                  

                }
                else
                {
                	if(move_uploaded_file($file, $location.$iname))
                    {					
						$ins = "Insert into materials(subj,name,description,tid,file) values('$subject','$material_name','$descr','$tid_session','$iname')";				

						if(mysqli_query($con, $ins))
						{
							echo "<script>alert('Materials Added Succesfully');</script>";
							echo "<script>window.location.href='ManageMaterials.php'</script>";			
						}	
						else
						{
							echo "<script>alert('Invalid');</script>";
						}
																	
					}
				}
			
	   }

	}
    
       
	
}

if(isset($_POST['btn_update']))
{
	$material_name = $_POST['material_name'];
	$descr = $_POST['descr'];
	$materialid_upd = $_POST['materialid_upd'];
	
	$update = "Update materials set name='$material_name',description='$descr' where materialid='$materialid_upd'";				
	if(mysqli_query($con, $update))
	{
		echo "<script>alert('Materials Updated Succesfully');</script>";
		echo "<script>window.location.href='ManageMaterials.php'</script>";			
	}	
	else
	{
		echo "<script>alert('Invalid');</script>";
	}
}
 
 
?>
  
</div>
</div>




<div class="modal small fade" id="myModal_Add" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" style="max-width: 600px;">
        <div class="modal-content">
            <div class="modal-header">              
                 <h3 class="modal-title">Add Materials</h3>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
			
			<form id="myform" method="post" enctype="multipart/form-data">
            <div class="modal-body">
			
			   <div class="row">
			   
			   <div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Select Subject:</label>
							<select class="form-control" name="cid">
									<?php
									
										$sel="select cid,subject from course where tid='$tid_session'";
										$rel=$con->query($sel);

										if(mysqli_num_rows($rel)==0)
										{
											 echo "<option value='nodata'>--No records to display--</option>";
										}
										else
										{
											echo'<option value="--Select Subject--">--Select Subject--</option>';
											  while($data=mysqli_fetch_array($rel))
											  {                            
													echo "<option value='".$data['cid']."'>".$data['subject']."</option>";						             
											  }
										}
										
									?>
							</select>
						</div>
					</div>
			   	   
				   <div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Material Name:</label>
							<input type="text" class="form-control" name="material_name" placeholder="Enter Material Name">
						</div>
					</div>
					
					<div class="clearfix"></div>
					
					<div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Description:</label>
							<textarea  rows="5" name="descr" class="form-control" placeholder="Enter Description"></textarea>
						</div>
					</div>
					
					<div class="clearfix"></div>
								
					<div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Upload File:</label>
							<input type="file" name="fileToUpload">			 	
							<label id="validation_upload" style="color:red; font-size:14px; display:none;"></label>
						</div>
					</div>
					
					<div class="clearfix"></div>
					
		       </div>
			  </div>
            <div class="modal-footer">
                <button class="btn btn-default" data-dismiss="modal" aria-hidden="true">Close</button> <input type="submit" name="btn_submit" class="btn btn-primary" value="Submit"/>
            </div>
			</form>
      
    </div>
	</div>
</div>


<div class="modal small fade" id="myModal_Update" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" style="max-width: 600px;">
        <div class="modal-content">
            <div class="modal-header">              
                 <h3 class="modal-title">Update Materials</h3>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
			
			<form id="myform1" method="post">
            <div class="modal-body">
			
			   <div class="row">
				   <div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Material Name:</label>
							<input type="text" class="form-control" id="matrname" name="material_name" placeholder="Enter Material Name">
						</div>
					</div>
									
					<div class="clearfix"></div>			
					
					<div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Description:</label>
							<textarea  rows="5" name="descr" id="descrp" class="form-control" placeholder="Enter Description"></textarea>
						</div>
					</div>
										
					<div class="clearfix"></div>
					
					<input type="hidden" id="materialid" value="" name="materialid_upd"/>
					
		       </div>
			  </div>
            <div class="modal-footer">
                <button class="btn btn-default" data-dismiss="modal" aria-hidden="true">Close</button> <input type="submit" name="btn_update" class="btn btn-primary" value="Submit"/>
            </div>
			</form>
      
    </div>
	</div>
</div>


<?php include('footer.php')?>

<script>

$('#btn_add').click(function(){
	$('#myModal_Del').modal('hide');
	$('#myModal_Add').modal('show');	
});

$('.btn_update').click(function(){
	
	var id = $(this).attr('id');
	
	$('#myModal_Add').modal('hide');
	$('#myModal_Del').modal('hide');
	
	$.ajax({
	  type: "POST",
	  url: "modal_updmaterials.php",
	  dataType: "json",
	  data:{id:id},
	  success: function(data){
		  
		$('#myModal_Update').modal('show');

		$("#matrname").val(data.name);
		$("#descrp").val(data.description);
		
	  }
	});
	
	$("#materialid").val(id);
	
});

$('.trash').click(function(){
	
	$('#myModal_Add').modal('hide');
	$('#myModal_Update').modal('hide');
	
    var id = $(this).attr('id');
    $('#modalDelete').attr('href','modal_delmaterials.php?id='+id);
	
});

$(function()
    {
		 $.validator.addMethod("value1", function(value, element, arg){
		  return arg !== value;
		 },);
		 
		 
		
         $("#myform").validate({
            
            rules:{
				cid: { value1: "--Select Subject--"	},		
				material_name : "required",
				descr : "required",
				fileToUpload: "required",								
            },

            messages:{
				cid: { value1: "<h5 style='color:red; font-size:15px;'><b>Please Select Subject</b></h5>" },
                material_name:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Material Name</b></h5>",
				descr:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Description</b></h5>",	
				fileToUpload:"<h5 style='color:red;font-size: 15px;'><b>Please Choose a File</b></h5>",								
            },
			
            submitHandler: function(form){
                form.submit();
            }
			

        });
		
	});
	
		
		$("#myform1").validate({
            
            rules:{
				
				material_name : "required",
				descr : "required",							
            },

            messages:{
                material_name:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Material Name</b></h5>",
				descr:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Description</b></h5>",	
				
            },
			
            submitHandler: function(form){
                form.submit();
            }
			

        });
		
		
</script>
