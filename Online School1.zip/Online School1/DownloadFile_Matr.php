<?php

include("connection.php");

$materialid = $_GET['materialid'];

$sel = "select file from materials where materialid='$materialid'";
$res=$con->query($sel);
$data = mysqli_fetch_assoc($res);
$file_fetch = $data['file'];
$file = "files/".$file_fetch;	

$contenttype = "application/force-download";
header("Content-Type: " . $contenttype);
header("Content-Disposition: attachment; filename=\"" . basename($file) . "\";");
readfile($file);
exit();

?>