<?php include('StudentHeader.php');

$val = !empty($_SESSION["sid_session"])?$_SESSION:" ";

if($val == " ")
{
	echo"<script>window.location.href='StudentLogin.php'</script>";
}
$sid_session = $_SESSION["sid_session"];
?>


<div class="content">
<div class="container-fluid">

	<div class="row">
	<div class="col-md-6 mx-auto shadow-lg p-3 mb-5 bg-white rounded lgndiv">
		<div class="col-md-12 text-center">
			<h4 class="text-primary">Add Complaints</h4>
		</div>
		
		<form id="myform" method="post">
		  <div class="form-group">
			<label>Complaint Name:</label>
			<input type="text" class="form-control" placeholder="Enter Complaint Name" name="compl_name" />
		  </div>
		  
		  <div class="form-group">
			<label>Description:</label>
			<textarea  rows="5" name="descr" class="form-control" placeholder="Enter Description"></textarea>
		  </div> 
		  <button type="submit" class="btn btn-primary" name="btn_submit">Submit</button>
		</form>
	
		
	</div>
	</div>

</div>
</div>

<?php 

if(isset($_POST['btn_submit']))
{	
    $compl_name = $_POST['compl_name'];
	$descr = $_POST['descr'];
	$date = date("Y-m-d");
	
	$ins = "Insert into complaints(name,descr,sid,date) values('$compl_name','$descr','$sid_session','$date')";				

	if(mysqli_query($con, $ins))
	{
		echo "<script>alert('Complaint Added Succesfully');</script>";
		echo "<script>window.location.href='MyComplaints.php'</script>";			
	}	
	else
	{
		echo "<script>alert('Invalid');</script>";
	}
				
}

include('footer.php')

?>

<script>

    $(function()
    {
            $("#myform").validate({
            
            rules:{
                compl_name: "required",		
                descr : "required",				
           },

            messages:{				
			   compl_name:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Complaint Name</b></h5>",
               descr:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Description</b></h5>",
                							
            },

            submitHandler: function(form){
                form.submit();
            }

        });

    }); 
	
</script>
