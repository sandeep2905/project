<?php
include("connection.php");

$materialid = $_POST['id'];
$sel = "select name,description from materials where materialid='$materialid'";
$rel=$con->query($sel);
while($data = mysqli_fetch_array($rel))
{
	$output['name'] = $data['name'];
	$output['description'] = $data['description'];
} 
echo json_encode($output);       
?>