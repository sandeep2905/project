<?php session_start();
include("connection.php");
include('header.php'); ?>

<div class="container-fluid mainbg">

	<div class="row">
	<div class="col-md-4 mx-auto shadow-lg p-3 mb-5 bg-white rounded lgndiv">
		<div class="col-md-12 text-center">
			<h4 class="text-primary">Admin Login</h4>
		</div>
		
		<form id="myform" method="post">
		  <div class="form-group">
			<label>Admin ID:</label>
			<input type="text" class="form-control" name="adminid" />
		  </div>
		  <div class="form-group">
			<label>Password:</label>
			<input type="password" class="form-control" name="pswd" />
		  </div> 
		  <button type="submit" class="btn btn-primary" name="btn_login">Login</button>
		</form>
		
		<center style="color: blue; font-weight: bold;"><a href="index.php"> <i class="fa fa-arrow-left"></i> Back</a></center>
		<br/>
		
	</div>
	</div>

</div>

</div>

<?php

if(isset($_POST['btn_login']))
{	
    $adminid = $_POST['adminid'];	
    $pswd = $_POST['pswd'];
		
	$sel = "select adminid from admin where adminid='$adminid' and password='$pswd'";
	$rel=$con->query($sel);	
		
	if($data=mysqli_fetch_assoc($rel))
	{
		$adminid = $data['adminid'];
			
		$_SESSION["adminid_session"] = $adminid;
		
		echo "<script>window.location.href='ManageTeacher.php'</script>";							
	}
	else
	{
		echo "<script>alert('Invalid Login');</script>";
	}
			
}

include('footer.php'); 
 
?>

<script>

    $(function()
    {
            $("#myform").validate({
            
            rules:{
                adminid: "required",		
                pswd : "required",				
           },

            messages:{				
			   adminid:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Admin ID</b></h5>",
               pswd:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Password</b></h5>",
                							
            },

            submitHandler: function(form){
                form.submit();
            }

        });

    }); 
	
</script>
