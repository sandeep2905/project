
<?php include('header.php'); ?>

<div class="container-fluid mainbg">

	<div class="col-md-12 maindiv">
		<h4 class="head">Online School</h4>
	</div>

</div>

</div>

<?php include('footer.php'); ?>