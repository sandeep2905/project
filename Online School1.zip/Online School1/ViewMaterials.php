<?php include('StudentHeader.php');

$val = !empty($_SESSION["sid_session"])?$_SESSION:" ";

if($val == " ")
{
	echo"<script>window.location.href='StudentLogin.php'</script>";
}
$sid_session = $_SESSION["sid_session"];
?>


<div class="content">
<div class="container">

<?php
		
$search_name="";

if(isset($_POST['btn_search']))
{
   $search_name = $_POST['search_name'];
}
else
{
   $search_name = "";   
}
	

if($search_name == "")
{
	$sel = "select t.name as tname,m.materialid,m.subj,m.name,m.description,m.file from materials as m join teacher as t on t.tid = m.tid";	  	
}
else
{
    $sel = "select t.name as tname,materialid,subj,name,description,file from materials as m join teacher as t on t.tid = m.tid where m.subj like '%$search_name%'";
}

?>


	<div id="searchbox">
	 <form method="post">
		<div class="input-group" style="width: 35%;">
			<input name="search_name" type="text" class="form-control" placeholder="Search Subject">
			<div class="input-group-btn">
				<button class="btn btn-primary" name="btn_search" type="submit">
					<i class="fa fa-search" aria-hidden="true" style="font-size: 25px;"></i>
				</button>
			</div>
		</div>	
	  </form>	
	</div>		

</br>

	<table class="table table-bordered table-hover">
			
	<?php
						
	$rel=$con->query($sel);
	if(mysqli_num_rows($rel)==0)
	{			  
		echo "<center><h3>No records to display</h3></center>";
		echo "<script>document.getElementById('searchbox').style.display='none'</script>";
	}
	else
	{
		echo "<script>document.getElementById('searchbox').style.display='block'</script>";	
		echo'<thead style="background-color:grey;color:white">           
		<tr>
		<th>Teacher Name</th>	
        <th>Subject</th>		
		<th>Material Name</th>
		<th>Description</th>
		<th>File</th>
		
		</tr>
		</thead>

		<tbody>';
			  
		while($data=mysqli_fetch_array($rel))
		{		
			$materialid=$data['materialid'];
			$tname=$data['tname'];
			$subj=$data['subj'];
			$name=$data['name'];
			$file=$data['file'];
			$description=$data['description'];	
			
			echo'<tr>
			<td>'.$tname.'</td>
			<td>'.$subj.'</td>
			<td>'.$name.'</td>
			<td>'.$description.'</td>
			<td><a href="DownloadFile_Matr.php?materialid='.$materialid.'">'.$file.'</a></td>			
			</tr>';
			
		}
		echo"</tbody>";
	}		
			
	?>
				 
  </table>
  
  
</div>
</div>

<?php include('footer.php')?>
