<?php session_start();
include("connection.php");
include('header.php'); ?>

<div class="container-fluid mainbg">

	<div class="row">
	<div class="col-md-4 mx-auto shadow-lg p-3 mb-5 bg-white rounded lgndiv">
		<div class="col-md-12 text-center">
			<h4 class="text-primary">Student Login</h4>
		</div>
		
		<form id="myform" method="post">
		  <div class="form-group">
			<label>Email address:</label>
			<input type="text" class="form-control" name="emailid" />
		  </div>
		  <div class="form-group">
			<label>Password:</label>
			<input type="password" class="form-control" name="pswd" />
		  </div> 
		  <button type="submit" class="btn btn-primary" name="btn_login">Login</button>
		</form>
		
		<center style="color: blue; font-weight: bold;"><a href="index.php"> <i class="fa fa-arrow-left"></i> Back</a></center>
		<br/>
		
	</div>
	</div>

</div>

</div>

<?php

if(isset($_POST['btn_login']))
{	
    $emailid = $_POST['emailid'];	
    $pswd = $_POST['pswd'];
		
	$sel = "select sid from students where emailid='$emailid' and password='$pswd'";
	$rel=$con->query($sel);	
		
	if($data=mysqli_fetch_assoc($rel))
	{
		$sid = $data['sid'];
			
		$_SESSION["sid_session"] = $sid;
		
		echo "<script>window.location.href='ViewMaterials.php'</script>";							
	}
	else
	{
		echo "<script>alert('Invalid Login');</script>";
	}
			
}

include('footer.php'); 
 
?>

<script>

    $(function()
    {
            $("#myform").validate({
            
            rules:{
                emailid: {
                    required:true,
                    email:true

                },		
                pswd : "required",				
           },

            messages:{				
			   emailid:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Email ID</b></h5>",
               pswd:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Password</b></h5>",
                							
            },

            submitHandler: function(form){
                form.submit();
            }

        });

    }); 
	
</script>
