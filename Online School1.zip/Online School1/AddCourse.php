<?php include('AdminHeader.php');

$val = !empty($_SESSION["adminid_session"])?$_SESSION:" ";

if($val == " ")
{
	echo"<script>window.location.href='AdminLogin.php'</script>";
}
$adminid_session = $_SESSION["adminid_session"];
?>


<div class="content">
<div class="container">

<?php
		
$search_name="";

if(isset($_POST['btn_search']))
{
   $search_name = $_POST['search_name'];
}
else
{
   $search_name = "";   
}
	

if($search_name == "")
{
	$sel = "select t.name,c.coursename,c.subject from teacher as t join course as c on c.tid = t.tid";	  	
}
else
{
    $sel = "select t.name,c.coursename,c.subject from teacher as t join course as c on c.tid = t.tid where c.subject like '%$search_name%'";
}

?>


<div class="row">
<div class="col-md-6 col-lg-6">
	<div id="searchbox">
	 <form method="post">
		<div class="input-group" style="width: 60%;">
			<input name="search_name" type="text" class="form-control" placeholder="Search Subject">
			<div class="input-group-btn">
				<button class="btn btn-primary" name="btn_search" type="submit">
					<i class="fa fa-search" aria-hidden="true" style="font-size: 25px;"></i>
				</button>
			</div>
		</div>	
	  </form>	
	</div>		
</div>


<div class="col-md-6 col-lg-6" align="right">
	<button class="btn btn-primary" style="width:10%;" id="btn_add">Add</button>
</div>
</div>

</br>

	<table class="table table-bordered table-hover">
			
	<?php
						
	$rel=$con->query($sel);
	if(mysqli_num_rows($rel)==0)
	{			  
		echo "<center><h3>No records to display</h3></center>";
		echo "<script>document.getElementById('searchbox').style.display='none'</script>";
	}
	else
	{
		echo "<script>document.getElementById('searchbox').style.display='block'</script>";	
		echo'<thead style="background-color:grey;color:white">           
		<tr>                  						
		<th>Teacher Name</th>
		<th>Course Name</th>
		<th>Subject</th>
		</tr>
		</thead>

		<tbody>';
			  
		while($data=mysqli_fetch_array($rel))
		{		
			$name=$data['name'];
			$coursename=$data['coursename'];
			$subject=$data['subject'];							
			
			echo'<tr>
			<td>'.$name.'</td>
			<td>'.$coursename.'</td>
			<td>'.$subject.'</td>			
			</tr>';			
		}
		echo"</tbody>";
	}		
			
	?>
				 
  </table>
  
  
<?php 
  
if(isset($_POST['btn_submit']))
{	
    $course_name = $_POST['course_name'];
    $subj = $_POST['subj'];
	$tid = $_POST['tid'];
	
		
	$ins = "Insert into course(coursename,subject,tid) values('$course_name','$subj','$tid')";							
						
	if(mysqli_query($con, $ins))
	{
		echo "<script>alert('Course Details Added Successfully');</script>";
		echo "<script>window.location.href='AddCourse.php'</script>";									
	}	
	else
	{
		echo "<script>alert('Invalid');</script>";							
	}	
}
 
?>
  
</div>
</div>




<div class="modal small fade" id="myModal_Add" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" style="max-width: 600px;">
        <div class="modal-content">
            <div class="modal-header">              
                 <h3 class="modal-title">Add Course</h3>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
			
			<form id="myform" method="post">
            <div class="modal-body">
			
			   <div class="row">
				   <div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Course Name:</label>
							<input type="text" class="form-control" name="course_name" placeholder="Enter Course Name">
						</div>
					</div>
					
					<div class="clearfix"></div>
												
					 <div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Subject:</label>
							<input type="text" class="form-control" name="subj" placeholder="Enter Subject">
						</div>
					</div>
					
					<div class="clearfix"></div>
					
					<div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Assign Teacher:</label>
							<select class="form-control" name="tid">
									<?php
									
										$sel="select tid,name from teacher";
										$rel=$con->query($sel);

										if(mysqli_num_rows($rel)==0)
										{
											 echo "<option value='nodata'>--No records to display--</option>";
										}
										else
										{
											echo'<option value="--Select Teacher Name--">--Select Teacher Name--</option>';
											  while($data=mysqli_fetch_array($rel))
											  {                            
													echo "<option value='".$data['tid']."'>".$data['name']."</option>";						             
											  }
										}
										
									?>
							</select>
						</div>
					</div>
					
					<div class="clearfix"></div>
					
		       </div>
			  </div>
            <div class="modal-footer">
                <button class="btn btn-default" data-dismiss="modal" aria-hidden="true">Close</button> <input type="submit" name="btn_submit" class="btn btn-primary" value="Submit"/>
            </div>
			</form>
      
    </div>
	</div>
</div>

<?php include('footer.php')?>

<script>

$('#btn_add').click(function(){
	$('#myModal_Add').modal('show');	
});

  	$(function()
    {
		 $.validator.addMethod("teacher", function(value, element, arg){
		  return arg !== value;
		 },);
		 
         $("#myform").validate({
            
            rules:{
                course_name : "required",		
				subj : "required",
				tid: { teacher: "--Select Teacher Name--" },	
            },

            messages:{
                course_name:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Course Name</b></h5>",				
				subj:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Subject</b></h5>",
				tid: { teacher: "<h5 style='color:red; font-size:15px;'><b>Please Select Teacher Name</b></h5>" },
            },
			
            submitHandler: function(form){
                form.submit();
            }
			

        });
	});			

</script>
