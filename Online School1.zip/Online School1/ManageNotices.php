<?php include('AdminHeader.php');

$val = !empty($_SESSION["adminid_session"])?$_SESSION:" ";

if($val == " ")
{
	echo"<script>window.location.href='AdminLogin.php'</script>";
}
$adminid_session = $_SESSION["adminid_session"];
?>


<div class="content">
<div class="container">

<?php
		
$search_name="";

if(isset($_POST['btn_search']))
{
   $search_name = $_POST['search_name'];
}
else
{
   $search_name = "";   
}
	

if($search_name == "")
{
	$sel = "select noticeid,noticename,file,date from notices Order by date desc";	  	
}
else
{
    $sel = "select noticeid,noticename,file,date from notices where noticename like '%$search_name%' Order by date desc";
}

?>

<div class="modal small fade" id="myModal_Del" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                
                 <h3 id="myModalLabel">Delete Confirmation</h3>

            </div>
            <div class="modal-body">
                <p class="error-text" style="font-size:17px;"><i class="fa fa-warning modal-icon"></i> Are you sure you want to delete?
                    </p>
            </div>
            <div class="modal-footer">
               <button class="btn btn-default"data-dismiss="modal" aria-hidden="true">No</button> <a href="#" class="btn btn-danger" id="modalDelete" >Yes</a>

            </div>
        </div>
    </div>
</div>

<div class="row">
<div class="col-md-6 col-lg-6">
	<div id="searchbox">
	 <form method="post">
		<div class="input-group" style="width: 60%;">
			<input name="search_name" type="text" class="form-control" placeholder="Search Notice Name">
			<div class="input-group-btn">
				<button class="btn btn-primary" name="btn_search" type="submit">
					<i class="fa fa-search" aria-hidden="true" style="font-size: 25px;"></i>
				</button>
			</div>
		</div>	
	  </form>	
	</div>		
</div>


<div class="col-md-6 col-lg-6" align="right">
	<button class="btn btn-primary" style="width:10%;" id="btn_add">Add</button>
</div>
</div>

</br>

	<table class="table table-bordered table-hover">
			
	<?php
						
	$rel=$con->query($sel);
	if(mysqli_num_rows($rel)==0)
	{			  
		echo "<center><h3>No records to display</h3></center>";
		echo "<script>document.getElementById('searchbox').style.display='none'</script>";
	}
	else
	{
		echo "<script>document.getElementById('searchbox').style.display='block'</script>";	
		echo'<thead style="background-color:grey;color:white">           
		<tr>                  						
		<th>Notice Name</th>
		<th>File</th>
		<th>Date</th>
		<th>Action</th>
		</tr>
		</thead>

		<tbody>';
			  
		while($data=mysqli_fetch_array($rel))
		{		
			$noticeid=$data['noticeid'];
			$noticename=$data['noticename'];
			$file=$data['file'];
			$date=$data['date'];	
			
			echo'<tr>
			<td>'.$noticename.'</td>
			<td><a href="DownloadFile.php?noticeid='.$noticeid.'">'.$file.'</a></td>
			<td>'.$date.'</td>
			<td><a href="#myModal_Del" class="btn btn-danger trash" id="'.$noticeid.'" role="button" data-toggle="modal">Delete</a></td>				
			</tr>';
			
		}
		echo"</tbody>";
	}		
			
	?>
				 
  </table>
  
  
<?php 
  
if(isset($_POST['btn_submit']))
{	
    $notice_name = $_POST['notice_name'];
	$date = date("Y-m-d");
    
	$file=$_FILES['fileToUpload']['tmp_name'];
    $iname=$_FILES['fileToUpload']['name'];
    
       if(isset($iname))
       {                 
                $location = 'files/';  

                $FileType = strtolower(pathinfo($location.$iname,PATHINFO_EXTENSION));

                if($FileType != "jpg" && $FileType != "png" && $FileType != "jpeg" && $FileType != "doc" && $FileType != "docx" && $FileType != "pdf")
                {
                    echo "<script>document.getElementById('validation_upload').innerHTML='Sorry, only .jpg,.png,.jpeg,.doc,.docx,.pdf files are allowed.';</script>";
                    echo "<script>document.getElementById('validation_upload').style.display = 'block';</script>";                  

                }
                else
                {
                	if(move_uploaded_file($file, $location.$iname))
                    {					
						$ins = "Insert into notices(noticename,file,date) values('$notice_name','$iname','$date')";				

						if(mysqli_query($con, $ins))
						{
							echo "<script>alert('Notices Added Succesfully');</script>";
							echo "<script>window.location.href='ManageNotices.php'</script>";			
						}	
						else
						{
							echo "<script>alert('Invalid');</script>";
						}
																	
					}
				}
			
	   }
	
}
 
?>
  
</div>
</div>




<div class="modal small fade" id="myModal_Add" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" style="max-width: 600px;">
        <div class="modal-content">
            <div class="modal-header">              
                 <h3 class="modal-title">Add Notices</h3>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
			
			<form id="myform" method="post" enctype="multipart/form-data">
            <div class="modal-body">
			
			   <div class="row">
				   <div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Notice Name:</label>
							<input type="text" class="form-control" name="notice_name" placeholder="Enter Notice Name">
						</div>
					</div>
					
					<div class="clearfix"></div>
								
					<div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Upload File:</label>
							<input type="file" name="fileToUpload">			 	
							<label id="validation_upload" style="color:red; font-size:14px; display:none;"></label>
						</div>
					</div>
					
					<div class="clearfix"></div>
					
		       </div>
			  </div>
            <div class="modal-footer">
                <button class="btn btn-default" data-dismiss="modal" aria-hidden="true">Close</button> <input type="submit" name="btn_submit" class="btn btn-primary" value="Submit"/>
            </div>
			</form>
      
    </div>
	</div>
</div>


<?php include('footer.php')?>

<script>

$('#btn_add').click(function(){
	$('#myModal_Del').modal('hide');
	$('#myModal_Add').modal('show');	
});

$('.trash').click(function(){
	
	$('#myModal_Add').modal('hide');
	
    var id = $(this).attr('id');
    $('#modalDelete').attr('href','modal_delnotices.php?id='+id);
	
});
		
         $("#myform").validate({
            
            rules:{              			
				notice_name : "required",
				fileToUpload: "required",								
            },

            messages:{
                notice_name:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Notice Name</b></h5>",				
				fileToUpload:"<h5 style='color:red;font-size: 15px;'><b>Please Choose a File</b></h5>",								
            },
			
            submitHandler: function(form){
                form.submit();
            }
			

        });
		
</script>
