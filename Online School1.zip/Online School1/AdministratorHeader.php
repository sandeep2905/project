<?php session_start();
include("connection.php");
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/style.css" />
<link rel="stylesheet" href="http://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
</head>

<body data-spy="scroll" data-target=".navbar" data-offset="50">

<div class="sticky">

<nav class="navbar navbar-expand-lg navbar-dark bg-secondary fixed-top">
   <a class="navbar-brand" href="#" style="font-size: 26px; font-family: sans-serif; color: #ede4b7; font-weight: bold;">Online School</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="ManageStudents.php">Manage Students</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="ManageBooks.php">Manage Books</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="ViewComplaints.php">View Complaints</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="ViewNotices_Administ.php">View Notices</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="Logout.php">Logout</a>
      </li>
    </ul>
  </div>
</nav>