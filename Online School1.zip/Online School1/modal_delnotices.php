<?php
include("connection.php");

      $id = $_GET['id'];
	  
      $delete = "delete from notices where noticeid='$id'";
      
      if(mysqli_query($con, $delete))
      {		
		echo "<script>alert(Notice Deleted Successfully');</script>";
		echo "<script>window.location.href='ManageNotices.php'</script>";		   
      } 
      else
      {
        echo "<script>alert('Error while deleting');</script>";
      }

?>