<?php
include("connection.php");

$staffid = $_POST['id'];
$sel = "select name,gender,dateofbirth,emailid,contactno,schoolname,address,city,dept from staff where staffid='$staffid'";
$rel=$con->query($sel);
while($data = mysqli_fetch_array($rel))
{
	$output['name'] = $data['name'];
	$output['gender'] = $data['gender'];
	$output['dateofbirth'] = $data['dateofbirth'];
	$output['emailid'] = $data['emailid'];
	$output['contactno'] = $data['contactno'];
	$output['schoolname'] = $data['schoolname'];
	$output['address'] = $data['address'];
	$output['city'] = $data['city'];
	$output['dept'] = $data['dept'];
} 
echo json_encode($output);       
?>