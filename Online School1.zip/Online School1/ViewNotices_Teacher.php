<?php include('TeacherHeader.php');

$val = !empty($_SESSION["tid_session"])?$_SESSION:" ";

if($val == " ")
{
	echo"<script>window.location.href='TeacherLogin.php'</script>";
}
$tid_session = $_SESSION["tid_session"];
?>


<div class="content">
<div class="container">

<?php
		
$search_name="";

if(isset($_POST['btn_search']))
{
   $search_name = $_POST['search_name'];
}
else
{
   $search_name = "";   
}
	

if($search_name == "")
{
	$sel = "select noticeid,noticename,file,date from notices Order by date desc";
}
else
{
    $sel = "select noticeid,noticename,file,date from notices where noticename like '%$search_name%' Order by date desc";
}

?>


	<div id="searchbox">
	 <form method="post">
		<div class="input-group" style="width:35%;">
			<input name="search_name" type="text" class="form-control" placeholder="Search Notice Name">
			<div class="input-group-btn">
				<button class="btn btn-primary" name="btn_search" type="submit">
					<i class="fa fa-search" aria-hidden="true" style="font-size: 25px;"></i>
				</button>
			</div>
		</div>	
	  </form>	
	</div>		



</br>

	<table class="table table-bordered table-hover">
			
	<?php
						
	$rel=$con->query($sel);
	if(mysqli_num_rows($rel)==0)
	{			  
		echo "<center><h3>No records to display</h3></center>";
		echo "<script>document.getElementById('searchbox').style.display='none'</script>";
	}
	else
	{
		echo "<script>document.getElementById('searchbox').style.display='block'</script>";	
		echo'<thead style="background-color:grey;color:white">           
		<tr>                  						
		<th>Notice Name</th>
		<th>File</th>
		<th>Date</th>
		</tr>
		</thead>

		<tbody>';
			  
		while($data=mysqli_fetch_array($rel))
		{		
			$noticeid=$data['noticeid'];
			$noticename=$data['noticename'];
			$file=$data['file'];
			$date=$data['date'];	
			
			echo'<tr>
			<td>'.$noticename.'</td>
			<td><a href="DownloadFile.php?noticeid='.$noticeid.'">'.$file.'</a></td>
			<td>'.$date.'</td>			
			</tr>';
			
		}
		echo"</tbody>";
	}		
			
	?>
				 
  </table>
  
  

</div>
</div>

<?php include('footer.php')?>