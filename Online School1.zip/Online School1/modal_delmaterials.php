<?php
include("connection.php");

      $id = $_GET['id'];
	  
      $delete = "delete from materials where materialid='$id'";
      
      if(mysqli_query($con, $delete))
      {		
		echo "<script>alert(Material Deleted Successfully');</script>";
		echo "<script>window.location.href='ManageMaterials.php'</script>";		   
      } 
      else
      {
        echo "<script>alert('Error while deleting');</script>";
      }

?>