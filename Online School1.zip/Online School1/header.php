<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/style.css" />
</head>
<body>

<div class="sticky">

<nav class="navbar navbar-expand-lg navbar-dark bg-secondary">
  <a class="navbar-brand" href="#">Online School</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="AdminLogin.php">Admin Login</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="AdministratorLogin.php">Administrator Login</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="TeacherLogin.php">Teacher Login</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="StudentLogin.php">Student Login</a>
      </li>
	  
    </ul>
  </div>
</nav>