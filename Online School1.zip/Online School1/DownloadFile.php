<?php

include("connection.php");

$noticeid = $_GET['noticeid'];

$sel = "select file from notices where noticeid='$noticeid'";
$res=$con->query($sel);
$data = mysqli_fetch_assoc($res);
$file_fetch = $data['file'];
$file = "files/".$file_fetch;	

$contenttype = "application/force-download";
header("Content-Type: " . $contenttype);
header("Content-Disposition: attachment; filename=\"" . basename($file) . "\";");
readfile($file);
exit();

?>