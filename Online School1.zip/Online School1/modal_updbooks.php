<?php
include("connection.php");

$bookid = $_POST['id'];
$sel = "select bookname,catg,authorname,description,image,price from books where bookid='$bookid'";
$rel=$con->query($sel);
while($data = mysqli_fetch_array($rel))
{
	$output['bookname'] = $data['bookname'];
	$output['catg'] = $data['catg'];
	$output['authorname'] = $data['authorname'];
	$output['description'] = $data['description'];
	$output['image'] = $data['image'];
	$output['price'] = $data['price'];
} 
echo json_encode($output);       
?>