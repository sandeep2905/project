<?php include('StudentHeader.php');

$val = !empty($_SESSION["sid_session"])?$_SESSION:" ";

if($val == " ")
{
	echo"<script>window.location.href='StudentLogin.php'</script>";
}
$sid_session = $_SESSION["sid_session"];
?>

<div class="content">
<div class="container">

<?php
		
$search_name="";

if(isset($_POST['btn_search']))
{
   $search_name = $_POST['search_name'];
}
else
{
   $search_name = "";   
}
	

if($search_name == "")
{
	$sel = "select bookname,catg,authorname,description,image,price from books";	  	
}
else
{
    $sel = "select bookname,catg,authorname,description,image,price from books where bookname like '%$search_name%'";
}

?>


	<div id="searchbox">
	 <form method="post">
		<div class="input-group" style="width: 35%;">
			<input name="search_name" type="text" class="form-control" placeholder="Search Book Name">
			<div class="input-group-btn">
				<button class="btn btn-primary" name="btn_search" type="submit">
					<i class="fa fa-search" aria-hidden="true" style="font-size: 25px;"></i>
				</button>
			</div>
		</div>	
	  </form>	
	</div>		

</br>

	<table class="table table-bordered table-hover">
			
	<?php
						
	$rel=$con->query($sel);
	if(mysqli_num_rows($rel)==0)
	{			  
		echo "<center><h3>No records to display</h3></center>";
		echo "<script>document.getElementById('searchbox').style.display='none'</script>";
	}
	else
	{
		echo "<script>document.getElementById('searchbox').style.display='block'</script>";	
		echo'<thead style="background-color:grey;color:white">           
		<tr> 
		<th>Image</th>
		<th>Book Name</th>
		<th>Category</th>
		<th>Auhor Name</th>
		<th>Description</th>
		<th>Price</th>
		</tr>
		</thead>

		<tbody>';
			  
		while($data=mysqli_fetch_array($rel))
		{					
			$bookname=$data['bookname'];
			$catg=$data['catg'];
			$authorname=$data['authorname'];							
			$description=$data['description'];
			$image=$data['image'];
			$price=$data['price'];
			
			echo'<tr>
			<td>
				<img src="images/'.$image.'" alt="bookimages" style="width:100px; height:80px;"/>
			</td>			
			<td>'.$bookname.'</td>
			<td>'.$catg.'</td>
			<td>'.$authorname.'</td>
			<td>'.$description.'</td>
			<td>'.$price.'</td>
			
			</tr>';
			
		}
		echo"</tbody>";
	}		
			
	?>
				 
  </table>

  
</div>
</div>


<?php include('footer.php')?>

