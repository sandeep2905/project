<?php include('AdministratorHeader.php');

$val = !empty($_SESSION["administratorid_session"])?$_SESSION:" ";

if($val == " ")
{
	echo"<script>window.location.href='AdministratorLogin.php'</script>";
}
$administratorid_session = $_SESSION["administratorid_session"];
?>


<div class="content">
<div class="" style="margin-left: 2%; margin-right: 2%;">

<?php
		
$search_name="";

if(isset($_POST['btn_search']))
{
   $search_name = $_POST['search_name'];
}
else
{
   $search_name = "";   
}
	

if($search_name == "")
{
	$sel = "select bookid,bookname,catg,authorname,description,image,price from books";	  	
}
else
{
    $sel = "select bookid,bookname,catg,authorname,description,image,price from books where bookname like '%$search_name%'";
}

?>


<div class="row">
<div class="col-md-6 col-lg-6">
	<div id="searchbox">
	 <form method="post">
		<div class="input-group" style="width: 60%;">
			<input name="search_name" type="text" class="form-control" placeholder="Search Book Name">
			<div class="input-group-btn">
				<button class="btn btn-primary" name="btn_search" type="submit">
					<i class="fa fa-search" aria-hidden="true" style="font-size: 25px;"></i>
				</button>
			</div>
		</div>	
	  </form>	
	</div>		
</div>


<div class="col-md-6 col-lg-6" align="right">
	<button class="btn btn-primary" style="width:10%;" id="btn_add">Add</button>
</div>
</div>



</br>

	<table class="table table-bordered table-hover">
			
	<?php
						
	$rel=$con->query($sel);
	if(mysqli_num_rows($rel)==0)
	{			  
		echo "<center><h3>No records to display</h3></center>";
		echo "<script>document.getElementById('searchbox').style.display='none'</script>";
	}
	else
	{
		echo "<script>document.getElementById('searchbox').style.display='block'</script>";	
		echo'<thead style="background-color:grey;color:white">           
		<tr> 
		<th>Image</th>
		<th>Book Name</th>
		<th>Category</th>
		<th>Auhor Name</th>
		<th>Description</th>
		<th>Price</th>
		<th>Action</th>
		</tr>
		</thead>

		<tbody>';
			  
		while($data=mysqli_fetch_array($rel))
		{		
			$bookid=$data['bookid'];
			$bookname=$data['bookname'];
			$catg=$data['catg'];
			$authorname=$data['authorname'];							
			$description=$data['description'];
			$image=$data['image'];
			$price=$data['price'];
			
			echo'<tr>
			<td>
				<img src="images/'.$image.'" alt="bookimages" style="width:100px; height:80px;"/>
			</td>			
			<td>'.$bookname.'</td>
			<td>'.$catg.'</td>
			<td>'.$authorname.'</td>
			<td>'.$description.'</td>
			<td>'.$price.'</td>
			<td><button class="btn btn-primary btn_update" id="'.$bookid.'">Update</button></td>	
			</tr>';
			
		}
		echo"</tbody>";
	}		
			
	?>
				 
  </table>
  
  
<?php 
  
if(isset($_POST['btn_submit']))
{	
    $book_name = $_POST['book_name'];
	$author_name = $_POST['author_name'];
    $descr = $_POST['descr'];
	$price = $_POST['price'];
	$catg = $_POST['catg'];
	
	$file=$_FILES['fileToUpload']['tmp_name'];
    $iname=$_FILES['fileToUpload']['name'];
    
       if(isset($iname))
       {                 
                $location = 'images/';  

                $ImageFileType = strtolower(pathinfo($location.$iname,PATHINFO_EXTENSION));

                if($ImageFileType != "jpg" && $ImageFileType != "png" && $ImageFileType != "jpeg")
                {
                    echo "<script>document.getElementById('validation_upload').innerHTML='Sorry, only .jpg,.png,.jpeg files are allowed.';</script>";
                    echo "<script>document.getElementById('validation_upload').style.display = 'block';</script>";                  

                }
                else
                {
                	if(move_uploaded_file($file, $location.$iname))
                    {					
						$ins = "Insert into books(bookname,catg,authorname,description,image,price) values('$book_name','$catg','$author_name','$descr','$iname','$price')";				

						if(mysqli_query($con, $ins))
						{
							echo "<script>alert('Book Details Added Succesfully');</script>";
							echo "<script>window.location.href='ManageBooks.php'</script>";			
						}	
						else
						{
							echo "<script>alert('Invalid');</script>";
						}
																	
					}
				}
			
	   }
	
}

if(isset($_POST['btn_update']))
{
	$book_name = $_POST['book_name'];
	$author_name = $_POST['author_name'];
    $descr = $_POST['descr'];
	$price = $_POST['price'];
	$catg = $_POST['catg'];
	$bookid = $_POST['bookid_upd'];
	
	$update = "Update books set bookname='$book_name',catg='$catg',authorname='$author_name',description='$descr',price='$price' where bookid='$bookid'";				
	if(mysqli_query($con, $update))
	{
		echo "<script>alert('Book Details Updated Succesfully');</script>";
		echo "<script>window.location.href='ManageBooks.php'</script>";			
	}	
	else
	{
		echo "<script>alert('Invalid');</script>";
	}
}
 
?>
  
</div>
</div>




<div class="modal small fade" id="myModal_Add" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" style="max-width: 600px;">
        <div class="modal-content">
            <div class="modal-header">              
                 <h3 class="modal-title">Add Books</h3>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
			
			<form id="myform" method="post" enctype="multipart/form-data">
            <div class="modal-body">
			
			   <div class="row">
				   <div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Book Name:</label>
							<input type="text" class="form-control" name="book_name" placeholder="Enter Book Name">
						</div>
					</div>
					
					<div class="clearfix"></div>
					
					<div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Author Name:</label>
							<input type="text" class="form-control" name="author_name" placeholder="Enter Author Name">
						</div>
					</div>
					
					<div class="clearfix"></div>
					
					<div class="col-md-6 col-lg-6">
						<div class="form-group">
						  <label>Category:</label></br>
						   <select name="catg" class="form-control">
							  <option value="--Select Category--">--Select Category--</option>
							  <option value="Science">Science</option>
							  <option value="Mathematics">Mathematics</option>
							  <option value="History">History</option>
							  <option value="Geography">Geography</option>
							  <option value="English">English</option>
							  <option value="Hindi">Hindi</option>
							  <option value="Health">Health</option>
							  <option value="Travel">Travel</option>
							  <option value="Technology">Technology</option>
							  <option value="Dictionaries">Dictionaries</option>							  
							  <option value="Art">Art</option>							 
							  <option value="Autobiographies">Autobiographies</option>
							  <option value="Fantasy">Fantasy</option>
							  <option value="Comics">Comics</option>
							  <option value="Economics">Economics</option>
							  <option value="Children Activity">Children Activity</option>
							  <option value="Others">Others</option>
						  </select>
						</div>
					</div>
					
					<div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Description:</label>
							<textarea  rows="5" name="descr" class="form-control" placeholder="Enter Description"></textarea>
						</div>
					</div>
					
					<div class="clearfix"></div>
					
					<div class="col-md-12 col-lg-12">
						<div class="form-group">
						  <label>Price:</label>
						   <input type="number" class="form-control" name="price" placeholder="Enter Price">
						</div>
					</div>
			
					<div class="clearfix"></div>
					
					<div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Upload Image:</label>
							<input type="file" name="fileToUpload">			 	
							<label id="validation_upload" style="color:red; font-size:14px; display:none;"></label>
						</div>
					</div>
					
					<div class="clearfix"></div>
					
		       </div>
			  </div>
            <div class="modal-footer">
                <button class="btn btn-default" data-dismiss="modal" aria-hidden="true">Close</button> <input type="submit" name="btn_submit" class="btn btn-primary" value="Submit"/>
            </div>
			</form>
      
    </div>
	</div>
</div>


<div class="modal small fade" id="myModal_Update" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" style="max-width: 600px;">
        <div class="modal-content">
            <div class="modal-header">              
                 <h3 class="modal-title">Update Books</h3>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
			
			<form id="myform1" method="post">
            <div class="modal-body">
			
			   <div class="row">
			   
			   <div class="col-md-12 col-lg-12 text-center">
						<div class="form-group">
							<img id="bookimage" alt="bookimages" style="width: 100px; height: 100px;"/>
						</div>
				</div>
					
				<div class="clearfix"></div>
				
				   <div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Book Name:</label>
							<input type="text" class="form-control" id="bkname" name="book_name" placeholder="Enter Book Name">
						</div>
					</div>
					
					<div class="clearfix"></div>
					
					<div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Author Name:</label>
							<input type="text" class="form-control" id="authrname" name="author_name" placeholder="Enter Author Name">
						</div>
					</div>
					
					<div class="clearfix"></div>
					
					<div class="col-md-6 col-lg-6">
						<div class="form-group">
						  <label>Select Category:</label></br>
						   <select name="catg" id="category" class="form-control">						  
							  <option value="Science">Science</option>
							  <option value="Drama">Drama</option>
							  <option value="Action and Adventure">Action and Adventure</option>
							  <option value="Romance">Romance</option>
							  <option value="Mystery">Mystery</option>
							  <option value="Horror">Horror</option>
							  <option value="Health">Health</option>
							  <option value="Travel">Travel</option>
							  <option value="Childrens">Childrens</option>
							  <option value="Dictionaries">Dictionaries</option>
							  <option value="History">History</option>
							  <option value="Cookbooks">Cookbooks</option>
							  <option value="Math">Math</option>
							  <option value="Autobiographies">Autobiographies</option>
							  <option value="Fantasy">Fantasy</option>
							  <option value="Comics">Comics</option>
							  <option value="Others">Others</option>
						  </select>
						</div>
					</div>
					
					<div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Description:</label>
							<textarea  rows="5" name="descr" id="descrp" class="form-control" placeholder="Enter Description"></textarea>
						</div>
					</div>
					
					<div class="clearfix"></div>
					
					<div class="col-md-12 col-lg-12">
						<div class="form-group">
						  <label>Price:</label>
						   <input type="number" class="form-control" id="t_price" name="price" placeholder="Enter Price">
						</div>
					</div>
			
					<div class="clearfix"></div>
					
					<input type="hidden" id="bookid" value="" name="bookid_upd"/>
					
		       </div>
			  </div>
            <div class="modal-footer">
                <button class="btn btn-default" data-dismiss="modal" aria-hidden="true">Close</button> <input type="submit" name="btn_update" class="btn btn-primary" value="Submit"/>
            </div>
			</form>
      
    </div>
	</div>
</div>


<?php include('footer.php')?>

<script>

$('#btn_add').click(function(){
	$('#myModal_Add').modal('show');	
});

  
$('.btn_update').click(function(){
	
	var id = $(this).attr('id');
	
	$('#myModal_Add').modal('hide');
	
	$.ajax({
	  type: "POST",
	  url: "modal_updbooks.php",
	  dataType: "json",
	  data:{id:id},
	  success: function(data){
		  
		$('#myModal_Update').modal('show');

		$("#bkname").val(data.bookname);
		$("#category").val(data.catg);
		$("#authrname").val(data.authorname);
		$("#descrp").val(data.description);
		$("#t_price").val(data.price);	
		$("#bookimage").attr("src","images/"+data.image);
		
		
	  }
	});
	
	$("#bookid").val(id);
	
});
  
  	$(function()
    {
		$.validator.addMethod("value1", function(value, element, arg){
		  return arg !== value;
		 },);
		
		
         $("#myform").validate({
            
            rules:{
                book_name : "required",			
				author_name : "required",
				catg : { value1: "--Select Category--" },				
				descr: "required",
				price: {
                    required:true,
                    number:true
                },
				fileToUpload: "required",	
            },

            messages:{
                book_name:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Book Name</b></h5>",				
				author_name:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Author Name</b></h5>",
				catg:{ value1: "<h5 style='color:red; font-size:15px;'><b>Please Select Category</b></h5>" },
				descr:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Description</b></h5>",
				price:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Price</b></h5>",
				fileToUpload:"<h5 style='color:red;font-size: 15px;'><b>Please Upload Image</b></h5>",
            },
			
            submitHandler: function(form){
                form.submit();
            }
			

        });
		
	 });



	$(function()
    {
		
         $("#myform1").validate({
            
            rules:{
                book_name : "required",			
				author_name : "required",		
				descr: "required",
				price: {
                    required:true,
                    number:true
                },
				
            },

            messages:{
                book_name:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Book Name</b></h5>",				
				author_name:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Author Name</b></h5>",				
				descr:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Description</b></h5>",
				price:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Price</b></h5>",
				
            },
			
            submitHandler: function(form){
                form.submit();
            }
			

        });
		
	 });

</script>
