<?php include('TeacherHeader.php');

$val = !empty($_SESSION["tid_session"])?$_SESSION:" ";

if($val == " ")
{
	echo"<script>window.location.href='TeacherLogin.php'</script>";
}
$tid_session = $_SESSION["tid_session"];
?>


<div class="content">
<div class="" style="margin-left: 2%; margin-right: 2%;">

<?php
		
$search_name="";

if(isset($_POST['btn_search']))
{
   $search_name = $_POST['search_name'];
}
else
{
   $search_name = "";   
}
	

if($search_name == "")
{
	$sel = "select sid,name,idcard,gender,dateofbirth,emailid,contactno,schoolname,address,city,class,division from students";	  	
}
else
{
    $sel = "select sid,name,idcard,gender,dateofbirth,emailid,contactno,schoolname,address,city,class,division from students where name like '%$search_name%'";
}

?>


	<div id="searchbox">
	 <form method="post">
		<div class="input-group" style="width: 35%;">
			<input name="search_name" type="text" class="form-control" placeholder="Search Student Name">
			<div class="input-group-btn">
				<button class="btn btn-primary" name="btn_search" type="submit">
					<i class="fa fa-search" aria-hidden="true" style="font-size: 25px;"></i>
				</button>
			</div>
		</div>	
	  </form>	
	</div>		

</br>

	<table class="table table-bordered table-hover">
			
	<?php
						
	$rel=$con->query($sel);
	if(mysqli_num_rows($rel)==0)
	{			  
		echo "<center><h3>No records to display</h3></center>";
		echo "<script>document.getElementById('searchbox').style.display='none'</script>";
	}
	else
	{
		echo "<script>document.getElementById('searchbox').style.display='block'</script>";	
		echo'<thead style="background-color:grey;color:white">           
		<tr>                  						
		<th>Student ID</th>
		<th>Student Name</th>
		<th>Student ID Card No.</th>
		<th>Gender</th>
		<th>Date of Birth</th>
		<th>Email ID</th>
		<th>Contact No.</th>
		<th>School Name</th>
		<th>Class</th>
		<th>Division</th> 
		<th>Address</th>
		<th>City</th>
		</tr>
		</thead>

		<tbody>';
			  
		while($data=mysqli_fetch_array($rel))
		{		
			$sid=$data['sid'];
			$name=$data['name'];
			$idcard=$data['idcard'];
			$gender=$data['gender'];							
			$dateofbirth=$data['dateofbirth'];
			$emailid=$data['emailid'];
			$contactno=$data['contactno'];
			$schoolname=$data['schoolname'];
			$address=$data['address'];
			$city=$data['city'];
			$class=$data['class'];
			$division=$data['division'];
			
			echo'<tr>
			<td>'.$sid.'</td>
			<td>'.$name.'</td>
			<td>'.$idcard.'</td>
			<td>'.$gender.'</td>
			<td>'.$dateofbirth.'</td>
			<td>'.$emailid.'</td>
			<td>'.$contactno.'</td>
			<td>'.$schoolname.'</td>
			<td>'.$class.'</td>	
			<td>'.$division.'</td>	
			<td>'.$address.'</td>
			<td>'.$city.'</td>
			
			</tr>';
			
		}
		echo"</tbody>";
	}		
			
	?>
				 
  </table>
  
  
</div>
</div>



<?php include('footer.php')?>