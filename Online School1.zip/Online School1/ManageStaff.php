<?php include('AdminHeader.php');

$val = !empty($_SESSION["adminid_session"])?$_SESSION:" ";

if($val == " ")
{
	echo"<script>window.location.href='AdminLogin.php'</script>";
}
$adminid_session = $_SESSION["adminid_session"];
?>


<div class="content">
<div class="" style="margin-left: 2%; margin-right: 2%;">

<?php
	
	
$search_name="";

if(isset($_POST['btn_search']))
{
   $search_name = $_POST['search_name'];
}
else
{
   $search_name = "";   
}
	

if($search_name == "")
{
	$sel = "select staffid,name,gender,dateofbirth,emailid,contactno,schoolname,address,city,dept from staff";	  	
}
else
{
    $sel = "select staffid,name,gender,dateofbirth,emailid,contactno,schoolname,address,city,dept from staff where name like '%$search_name%'";
}

?>


<div class="row">
<div class="col-md-6 col-lg-6">
	<div id="searchbox">
	 <form method="post">
		<div class="input-group" style="width: 60%;">
			<input name="search_name" type="text" class="form-control" placeholder="Search Staff Name">
			<div class="input-group-btn">
				<button class="btn btn-primary" name="btn_search" type="submit">
					<i class="fa fa-search" aria-hidden="true" style="font-size: 25px;"></i>
				</button>
			</div>
		</div>	
	  </form>	
	</div>		
</div>


<div class="col-md-6 col-lg-6" align="right">
	<button class="btn btn-primary" style="width:10%;" id="btn_add">Add</button>
</div>
</div>



</br>

	<table class="table table-bordered table-hover">
			
	<?php
						
	$rel=$con->query($sel);
	if(mysqli_num_rows($rel)==0)
	{			  
		echo "<center><h3>No records to display</h3></center>";
		echo "<script>document.getElementById('searchbox').style.display='none'</script>";
	}
	else
	{
		echo "<script>document.getElementById('searchbox').style.display='block'</script>";	
		echo'<thead style="background-color:grey;color:white">           
		<tr>                  						
		<th>Staff ID</th>
		<th>Staff Name</th>
		<th>Gender</th>
		<th>Date of Birth</th>
		<th>Email ID</th>
		<th>Contact No.</th>
		<th>School Name</th>
		<th>Department</th> 
		<th>Address</th>
		<th>City</th>
		<th>Action</th>
		</tr>
		</thead>

		<tbody>';
			  
		while($data=mysqli_fetch_array($rel))
		{		
			$staffid=$data['staffid'];
			$name=$data['name'];
			$gender=$data['gender'];							
			$dateofbirth=$data['dateofbirth'];
			$emailid=$data['emailid'];
			$contactno=$data['contactno'];
			$schoolname=$data['schoolname'];
			$address=$data['address'];
			$city=$data['city'];
			$dept=$data['dept'];
			
			echo'<tr>
			<td>'.$staffid.'</td>
			<td>'.$name.'</td>
			<td>'.$gender.'</td>
			<td>'.$dateofbirth.'</td>
			<td>'.$emailid.'</td>
			<td>'.$contactno.'</td>
			<td>'.$schoolname.'</td>	
			<td>'.$dept.'</td>	
			<td>'.$address.'</td>
			<td>'.$city.'</td>
			<td><button class="btn btn-primary btn_update" id="'.$staffid.'">Update</button></td>	
			</tr>';
			
		}
		echo"</tbody>";
	}		
			
	?>
				 
  </table>
  
  
<?php 
  
if(isset($_POST['btn_submit']))
{	
    $staff_name = $_POST['staff_name'];
    $optradio_gen = $_POST['optradio_gen'];
	$dob = $_POST['dob'];
	$TextBox_cn = $_POST['TextBox_cn'];
	$TextBox_email = $_POST['TextBox_email'];
	$TextBox_psd = $_POST['TextBox_cn'];
	$TextBox_schoolname = $_POST['TextBox_schoolname'];
	$TextBox_dept = $_POST['TextBox_dept'];
	$address = $_POST['address'];
	$city = $_POST['city'];
		
	
	$sel = "select emailid from staff where emailid='$TextBox_email'";
	$rel=$con->query($sel);	
	$data=mysqli_fetch_assoc($rel);	
	$emailid_data = $data['emailid'];
	
						
	if($TextBox_email==$emailid_data)
	{
		echo "<script>alert('This User is already registered');</script>";
	}	
	else
	{	
		$ins = "Insert into staff(name,gender,dateofbirth,emailid,password,contactno,schoolname,address,city,dept) 
		values('$staff_name','$optradio_gen','$dob','$TextBox_email','$TextBox_psd','$TextBox_cn','$TextBox_schoolname','$address','$city','$TextBox_dept')";							
						
		if(mysqli_query($con, $ins))
		{
			echo "<script>alert('Staff Details Added Successfully');</script>";
			echo "<script>window.location.href='ManageStaff.php'</script>";									
		}	
		else
		{
			echo "<script>alert('Invalid');</script>";							
		}
	}
	
}

if(isset($_POST['btn_update']))
{
	$dob = $_POST['dob'];	
	$TextBox_cn = $_POST['TextBox_cn'];
	$TextBox_schoolname = $_POST['TextBox_schoolname'];
	$TextBox_dept = $_POST['TextBox_dept'];
	$address = $_POST['address'];
	$city = $_POST['city'];
	$stfid = $_POST['stfid'];
	
	$update = "Update staff set dateofbirth='$dob',contactno='$TextBox_cn',schoolname='$TextBox_schoolname',address='$address',city='$city',dept='$TextBox_dept' where staffid='$stfid'";				
	if(mysqli_query($con, $update))
	{
		echo "<script>alert('Staff Details Updated Succesfully');</script>";
		echo "<script>window.location.href='ManageStaff.php'</script>";			
	}	
	else
	{
		echo "<script>alert('Invalid');</script>";
	}
}
 
?>
  
</div>
</div>




<div class="modal small fade" id="myModal_Add" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" style="max-width: 600px;">
        <div class="modal-content">
            <div class="modal-header">              
                 <h3 class="modal-title">Add Staff</h3>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
			
			<form id="myform" method="post">
            <div class="modal-body">
			
			   <div class="row">
				   <div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Staff Name:</label>
							<input type="text" class="form-control txtOnly" name="staff_name" placeholder="Enter Staff Name">
						</div>
					</div>
					
					<div class="clearfix"></div>
								
					<div class="col-md-12 col-lg-12">
						<div class="form-group container1">
							<label>Gender:</label>
							<label class="radio-inline"><input type="radio" name="optradio_gen" value="Male"> Male</label>
							<label class="radio-inline"><input type="radio" name="optradio_gen" value="Female"> Female</label>
						</div>
					</div>
					
					<div class="clearfix"></div>
					
					 <div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Date of Birth:</label>
							<input type="text" class="form-control" id="bod" name="dob" placeholder="Select Date of Birth" autocomplete="off">
						</div>
					</div>
					
					<div class="clearfix"></div>
					
					<div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Contact Number:</label>
							<input type="number" name="TextBox_cn" class="form-control" placeholder="Enter Contact Number" />
						</div>
					</div>
					
					<div class="clearfix"></div>

					<div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Email Address:</label>
							<input type="email" name="TextBox_email" class="form-control" placeholder="Email Address" />
						</div>
					</div>
					
					<div class="clearfix"></div>
					
					<div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Password:</label>
							<input type="password" name="TextBox_psd" class="form-control" placeholder="Password" />
						</div>
					</div>
					
					<div class="clearfix"></div>
					
					<div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>School Name:</label>
							<input type="text" name="TextBox_schoolname" class="form-control" placeholder="Enter School Name" />
						</div>
					</div>
					
					<div class="clearfix"></div>		
					
					<div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Department:</label>
							<input type="text" name="TextBox_dept" class="form-control" placeholder="Enter Department"/>
						</div>
					</div>
					
					<div class="clearfix"></div>
					
					<div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Address:</label>
							<textarea  rows="5" name="address" class="form-control" placeholder="Enter Address"></textarea>
						</div>
					</div>
					
					<div class="clearfix"></div>
					
					<div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>City:</label>
							<input type="text" name="city" class="form-control" placeholder="Enter City"/>
							
						</div>
					</div>
					
					<div class="clearfix"></div>
					
		       </div>
			  </div>
            <div class="modal-footer">
                <button class="btn btn-default" data-dismiss="modal" aria-hidden="true">Close</button> <input type="submit" name="btn_submit" class="btn btn-primary" value="Submit"/>
            </div>
			</form>
      
    </div>
	</div>
</div>


<div class="modal small fade" id="myModal_Update" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" style="max-width: 600px;">
        <div class="modal-content">
            <div class="modal-header">              
                 <h3 class="modal-title">Update Staff</h3>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
			
			<form id="myform1" method="post">
            <div class="modal-body">
			
			   <div class="row">
				   <div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Staff Name:</label>
							<input type="text" class="form-control txtOnly" id="staff_name" readonly value="">
						</div>
					</div>
					
					<div class="clearfix"></div>
								
					<div class="col-md-12 col-lg-12">
						<div class="form-group container1">
							<label>Gender:</label>
							<label class="radio-inline"><input type="radio" id="opt_male" disabled name="optradio_gen" value="Male">Male</label>
							<label class="radio-inline"><input type="radio" id="opt_female" disabled name="optradio_gen" value="Female">Female</label>
						</div>
					</div>
					
					<div class="clearfix"></div>
					
					 <div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Date of Birth:</label>
							<input type="text" class="form-control" id="bod1" name="dob" placeholder="Select Date of Birth" autocomplete="off">
						</div>
					</div>
					
					<div class="clearfix"></div>
					
					<div class="clearfix"></div>
					
					<div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Contact Number:</label>
							<input type="number" name="TextBox_cn" id="contctno" value="" class="form-control" placeholder="Enter Contact Number" />
						</div>
					</div>
					
					<div class="clearfix"></div>

					<div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Email Address:</label>
							<input type="email" name="TextBox_email" id="email" readonly value="" class="form-control" placeholder="Email Address" />
						</div>
					</div>
					
					<div class="clearfix"></div>		
					
					<div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>School Name:</label>
							<input type="text" name="TextBox_schoolname" id="schlname" value="" class="form-control" placeholder="Enter School Name" />
						</div>
					</div>
					
					<div class="clearfix"></div>		
					
					<div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Department:</label>
							<input type="text" name="TextBox_dept" id="dept" value="" class="form-control" placeholder="Enter Department"/>
						</div>
					</div>
					
					<div class="clearfix"></div>
					
					<div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>Address:</label>
							<textarea  rows="5" name="address" id="addr" value="" class="form-control" placeholder="Enter Address"></textarea>
						</div>
					</div>
					
					<div class="clearfix"></div>
					
					<div class="col-md-12 col-lg-12">
						<div class="form-group">
							<label>City:</label>
							<input type="text" name="city" id="city" value="" class="form-control" placeholder="Enter City"/>
							
						</div>
					</div>
					
					<div class="clearfix"></div>
					
					<input type="hidden" id="staffid" value="" name="stfid"/>
					
		       </div>
			  </div>
            <div class="modal-footer">
                <button class="btn btn-default" data-dismiss="modal" aria-hidden="true">Close</button> <input type="submit" name="btn_update" class="btn btn-primary" value="Submit"/>
            </div>
			</form>
      
    </div>
	</div>
</div>


<?php include('footer.php')?>

<script>

$('#btn_add').click(function(){
	$('#myModal_Add').modal('show');	
});

  
  $( "#bod" ).datepicker({
		dateFormat: "yy-mm-dd",	
   });
   
   $( "#bod1" ).datepicker({
		dateFormat: "yy-mm-dd",	
   });
   
  
$('.btn_update').click(function(){
	
	var id = $(this).attr('id');
	
	$('#myModal_Add').modal('hide');
	
	$.ajax({
	  type: "POST",
	  url: "modal_updstaff.php",
	  dataType: "json",
	  data:{id:id},
	  success: function(data){
		  
		$('#myModal_Update').modal('show');

		$("#staff_name").val(data.name);
		$("#bod1").val(data.dateofbirth);
		$("#email").val(data.emailid);	
		$("#contctno").val(data.contactno);
		$("#schlname").val(data.schoolname);
		$("#addr").val(data.address);
		$("#city").val(data.city);
		$("#dept").val(data.dept);
		
		if(data.gender == "Male")
		{
			$("#opt_male").prop("checked",true);
			$("#opt_female").prop("checked",false);
		}
		else if(data.gender == "Female")
		{
			$("#opt_female").prop("checked",true);
			$("#opt_male").prop("checked",false);
		}
		
	  }
	});
	
	$("#staffid").val(id);
	
});
  
$( ".txtOnly" ).keypress(function(e) {
    var key = e.keyCode;
    if (key >= 48 && key <= 57) {
        e.preventDefault();
    }
 });  
  		
         $("#myform").validate({
            
            rules:{
                staff_name : { 
				required:true,
				},				
				optradio_gen : "required",
				dob: "required",
				TextBox_cn: {
                    required:true,
                    number:true
                },
				TextBox_email: {
                    required:true,
                    email:true

                },
				TextBox_psd: "required",
				TextBox_schoolname: "required",
				TextBox_dept: "required",
				address: "required",
				city: "required",
            },

            messages:{
                staff_name:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Name</b></h5>",				
				optradio_gen:"<h5 style='color:red;font-size: 15px;'><b>Please Select Valid Gender</b></h5>",
				dob:"<h5 style='color:red;font-size: 15px;'><b>Please Select Valid Date of Birth</b></h5>",
				TextBox_cn:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Contact Number</b></h5>",		
                TextBox_email:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Email</b></h5>",
				TextBox_psd:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Password</b></h5>",				
				TextBox_schoolname:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid School Name</b></h5>",								
				TextBox_dept:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Department</b></h5>",				
				address:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Address</b></h5>",
				city:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid City</b></h5>",				
            },
			errorPlacement: function(error, element) 
			{
            if ( element.is(":radio") ) 
            {
                error.appendTo( element.parents('.container1') );
            }
            else 
            { // This is the default behavior 
                error.insertAfter( element );
            }
         },

            submitHandler: function(form){
                form.submit();
            }
			

        });
		
		
		$("#myform1").validate({
            
            rules:{               
				dob: "required",
				TextBox_cn: {
                    required:true,
                    number:true

                },
				TextBox_schoolname: "required",
				TextBox_dept: "required",
				address: "required",
				city: "required",
            },

            messages:{              				
				dob:"<h5 style='color:red;font-size: 15px;'><b>Please Select Valid Date of Birth</b></h5>",
				TextBox_cn:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Contact Number</b></h5>",		                
				TextBox_psd:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Password</b></h5>",				
				TextBox_schoolname:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid School Name</b></h5>",								
				TextBox_dept:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Department</b></h5>",				
				address:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid Address</b></h5>",
				city:"<h5 style='color:red;font-size: 15px;'><b>Please Enter Valid City</b></h5>",				
            },
			
            submitHandler: function(form){
                form.submit();
            }
			

        });
		

</script>
