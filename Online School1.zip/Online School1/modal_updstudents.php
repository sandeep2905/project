<?php
include("connection.php");

$sid = $_POST['id'];
$sel = "select name,idcard,gender,dateofbirth,emailid,contactno,schoolname,address,city,class,division from students where sid='$sid'";
$rel=$con->query($sel);
while($data = mysqli_fetch_array($rel))
{
	$output['name'] = $data['name'];
	$output['idcard'] = $data['idcard'];
	$output['gender'] = $data['gender'];
	$output['dateofbirth'] = $data['dateofbirth'];
	$output['emailid'] = $data['emailid'];
	$output['contactno'] = $data['contactno'];
	$output['schoolname'] = $data['schoolname'];
	$output['address'] = $data['address'];
	$output['city'] = $data['city'];
	$output['class'] = $data['class'];
	$output['division'] = $data['division'];
} 
echo json_encode($output);       
?>