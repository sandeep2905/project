-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 05, 2019 at 12:11 PM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlineschool`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `adminid` varchar(80) NOT NULL,
  `password` varchar(80) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminid`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `administrator`
--

DROP TABLE IF EXISTS `administrator`;
CREATE TABLE IF NOT EXISTS `administrator` (
  `administratorid` varchar(80) NOT NULL,
  `password` varchar(80) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `administrator`
--

INSERT INTO `administrator` (`administratorid`, `password`) VALUES
('administrator', 'administrator');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
CREATE TABLE IF NOT EXISTS `books` (
  `bookid` int(11) NOT NULL AUTO_INCREMENT,
  `bookname` varchar(300) NOT NULL,
  `catg` varchar(200) NOT NULL,
  `authorname` varchar(300) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(1000) NOT NULL,
  `price` int(200) NOT NULL,
  PRIMARY KEY (`bookid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`bookid`, `bookname`, `catg`, `authorname`, `description`, `image`, `price`) VALUES
(1, 'Science', 'Science', 'Pawan Kumar', 'Science Study', 'science.jpg', 280),
(2, 'History Stories', 'History', 'J.L Mehta', 'History', 'history.jpeg', 230);

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

DROP TABLE IF EXISTS `complaints`;
CREATE TABLE IF NOT EXISTS `complaints` (
  `complaintid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(300) NOT NULL,
  `descr` text NOT NULL,
  `sid` varchar(200) NOT NULL,
  `date` varchar(100) NOT NULL,
  PRIMARY KEY (`complaintid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`complaintid`, `name`, `descr`, `sid`, `date`) VALUES
(1, 'Classroom', 'classroom not clean', '101', '2019-04-05');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
CREATE TABLE IF NOT EXISTS `course` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `coursename` varchar(800) NOT NULL,
  `subject` varchar(800) NOT NULL,
  `tid` varchar(800) NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`cid`, `coursename`, `subject`, `tid`) VALUES
(1, 'Integration', 'Maths', '1001');

-- --------------------------------------------------------

--
-- Table structure for table `materials`
--

DROP TABLE IF EXISTS `materials`;
CREATE TABLE IF NOT EXISTS `materials` (
  `materialid` int(11) NOT NULL AUTO_INCREMENT,
  `subj` varchar(200) NOT NULL,
  `name` varchar(300) NOT NULL,
  `description` text NOT NULL,
  `tid` varchar(200) NOT NULL,
  `file` varchar(1000) NOT NULL,
  PRIMARY KEY (`materialid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `materials`
--

INSERT INTO `materials` (`materialid`, `subj`, `name`, `description`, `tid`, `file`) VALUES
(1, 'Maths', 'Maths Text Book', 'Sums to solve', '1001', 'maths.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `notices`
--

DROP TABLE IF EXISTS `notices`;
CREATE TABLE IF NOT EXISTS `notices` (
  `noticeid` int(11) NOT NULL AUTO_INCREMENT,
  `noticename` varchar(900) NOT NULL,
  `file` varchar(5000) NOT NULL,
  `date` varchar(100) NOT NULL,
  PRIMARY KEY (`noticeid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notices`
--

INSERT INTO `notices` (`noticeid`, `noticename`, `file`, `date`) VALUES
(1, 'Notice for Leave', 'notice.png', '2019-04-05');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
CREATE TABLE IF NOT EXISTS `staff` (
  `staffid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(800) NOT NULL,
  `gender` varchar(80) NOT NULL,
  `dateofbirth` varchar(100) NOT NULL,
  `contactno` varchar(800) NOT NULL,
  `emailid` varchar(900) NOT NULL,
  `password` varchar(900) NOT NULL,
  `schoolname` varchar(800) NOT NULL,
  `dept` varchar(800) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(900) NOT NULL,
  PRIMARY KEY (`staffid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staffid`, `name`, `gender`, `dateofbirth`, `contactno`, `emailid`, `password`, `schoolname`, `dept`, `address`, `city`) VALUES
(1, 'Mohan Kumar', 'Male', '2018-08-07', '8677888778', 'mohan@gmail.com', '8677888778', 'RST School', 'Accountant', 'Malad East', 'Mumbai');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
CREATE TABLE IF NOT EXISTS `students` (
  `sid` int(11) NOT NULL,
  `name` varchar(700) NOT NULL,
  `idcard` varchar(600) NOT NULL,
  `gender` varchar(80) NOT NULL,
  `dateofbirth` varchar(100) NOT NULL,
  `contactno` varchar(200) NOT NULL,
  `emailid` varchar(200) NOT NULL,
  `password` varchar(300) NOT NULL,
  `schoolname` varchar(300) NOT NULL,
  `class` varchar(100) NOT NULL,
  `division` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(200) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`sid`, `name`, `idcard`, `gender`, `dateofbirth`, `contactno`, `emailid`, `password`, `schoolname`, `class`, `division`, `address`, `city`) VALUES
(101, 'Sam Dsouza', '123456789', 'Male', '2018-08-07', '78566768898', 'sam@gmail.com', '123', 'RST School', '8', 'A', 'Andheri West', 'Mumbai');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

DROP TABLE IF EXISTS `teacher`;
CREATE TABLE IF NOT EXISTS `teacher` (
  `tid` int(11) NOT NULL,
  `name` varchar(800) NOT NULL,
  `gender` varchar(80) NOT NULL,
  `dateofbirth` varchar(100) NOT NULL,
  `emailid` varchar(700) NOT NULL,
  `password` varchar(600) NOT NULL,
  `contactno` varchar(700) NOT NULL,
  `schoolname` varchar(700) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(700) NOT NULL,
  `qualification` varchar(800) NOT NULL,
  `dept` varchar(800) NOT NULL,
  PRIMARY KEY (`tid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`tid`, `name`, `gender`, `dateofbirth`, `emailid`, `password`, `contactno`, `schoolname`, `address`, `city`, `qualification`, `dept`) VALUES
(1001, 'Ram Mehta', 'Male', '2018-10-08', 'ram@gmail.com', '123', '97890678889', 'RST School', 'Goregaon West', 'Mumbai', 'Bcom', 'Mathematics Teacher'),
(1002, 'Jagan Kumar', 'Male', '2018-09-02', 'jagan@gmail.com', '123', '88787878789', 'ABC School', 'Borivali West', 'Mumbai', 'BSC', 'Science Teacher');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
