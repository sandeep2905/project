const staticCacheName = 'site-static-v2';
const dynamicCacheName = 'site-dynamic-v1';
const assets = [
  '/',
  '/index.html',
  '/js/app.js',
  '/js/jquery.min.js',
  '/js/popper.min.js',
  '/js/bootstrap.min.js',
  '/js/ui.js',
  '/css/bootstrap.min.css',
  '/css/owl.carousel.min.css',
  '/css/owl.theme.default.min.css',
  '/css/mstyle.css',
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css',
  '/img/icons/icon-96x96.png',
  '/img/top_bg.png',
  '/img/bottom_bg.png',
  '/img/button.png',
  '/img/icon.png',
  '/img/profile_user.png',
  '/img/about.svg',
  '/img/calender_icon.svg',
  '/img/download_white.svg',
  '/img/filter.svg',
  '/img/helpdesk.svg',
  '/img/menudot.svg',
  '/img/player_trans.svg',
  '/img/skilljeeto.svg',
  '/img/skilljeeto1.svg',
  '/img/terms_condition.svg',
  '/img/user.svg',
  '/img/wallet_icon.svg',
  '/img/wallet_icon1.svg',
  '/pages/fallback.html',
  '/pages/mcreate_player.html',
  '/pages/mdatewise_creport.html',
  '/pages/mindex.html',
  '/pages/mlivesale_report.html',
  '/pages/mlogin.html',
  '/pages/mlogin1.html',
  '/pages/mlogin2.html',
  '/pages/mmanage_pin.html',
  '/pages/mmy_balance.html',
  '/pages/mmy_info.html',
  '/pages/mnotification.html',
  '/pages/mplayer_recharge_receipt.html',
  '/pages/mplayer_transfer.html',
  '/pages/mplayer_transfer1.html',
  '/pages/mplayer_withdraw_receipt.html',
  '/pages/mplayertrans_report.html',
  '/pages/mplayerwise_creport.html',
  '/pages/mreport.html',
  '/pages/msalepwt_report.html',
  '/pages/mseller_withdraw_request.html',
  '/pages/mtransaction_report.html',
  '/pages/mtransaction_report1.html',
  '/pages/mview_player.html',
  '/pages/mwithdraw.html'
];

// cache size limit function
const limitCacheSize = (name, size) => {
  caches.open(name).then(cache => {
    cache.keys().then(keys => {
      if(keys.length > size){
        cache.delete(keys[0]).then(limitCacheSize(name, size));
      }
    });
  });
};

// install event
self.addEventListener('install', evt => {
  //console.log('service worker installed');
  evt.waitUntil(
    caches.open(staticCacheName).then((cache) => {
      // console.log('caching shell assets');
      cache.addAll(assets);
    })
  );
});

// activate event
self.addEventListener('activate', evt => {
  //console.log('service worker activated');
  evt.waitUntil(
    caches.keys().then(keys => {
      //console.log(keys);
      return Promise.all(keys
        .filter(key => key !== staticCacheName && key !== dynamicCacheName)
        .map(key => caches.delete(key))
      );
    })
  );
});

self.addEventListener('fetch', evt => {
  //console.log('fetch event', evt);
  evt.respondWith(
    caches.match(evt.request).then(cacheRes => {
      return cacheRes || fetch(evt.request).then(fetchRes => {
        return caches.open(dynamicCacheName).then(cache => {
          cache.put(evt.request.url, fetchRes.clone());
          // check cached items size
          limitCacheSize(dynamicCacheName, 75);
          return fetchRes;
        })
      });
    }).catch(() => {
      if(evt.request.url.indexOf('.html') > -1){
        return caches.match('/pages/fallback.html');
      } 
    })
  );
});
