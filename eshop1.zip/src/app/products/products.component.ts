import { Component, OnInit } from '@angular/core';
import { CrudService } from '../crud.service';
import { CookieService } from 'ngx-cookie-service';


@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
	public productData;
  constructor(private crud:CrudService,private cs:CookieService) { }

  ngOnInit() {
  		this.crud.selectData("products").subscribe((results)=>{
  			// console.log(results);
  			this.productData = results
  		});

      this.crud.subObj.subscribe((Response)=>{
        // console.log("========")
        // console.log(Response)
        var brandId = Response['id'];
        // console.log(typeof brandId)
        this.crud.selectData("products").subscribe((results)=>{
          // console.log(results)
          if(results.length > 0){
            this.productData_filter = []
            for(var recData=0; recData<results.length; recData++){
              // console.log(results[recData])
              if(Response['type'] == "brand"){
                if(results[recData].brandid == brandId){
                  this.productData_filter.push(results[recData
                    ])
                }
              }
              if(Response['type'] == "category"){
                if(results[recData].catid == brandId){
                  this.productData_filter.push(results[recData
                    ])
                }
              }
            }
          }
            // console.log(this.productData_filter)
            this.productData = this.productData_filter
        })
      })
  }

  addToCart(id,e){
    e.preventDefault();
    // console.log(typeof id)
    // console.log(e);
    var result = this.cs.get("product_id");
    if(result.length>0){
      // console.log(result);
      var arr = result.split(",")
      //[2,3,1]
      // console.log(arr)
      if(arr.indexOf(id.toString()) == -1){
        var newpro = result + "," + id
        // console.log(newpro)
        this.cs.set("product_id",newpro)
        alert("cart Updated");
      }
      else {
        alert("product Exist in Cart");
      }
    }
    else
    {
      this.cs.set("product_id",id)
      alert("cart Added");
    }
  }
}
