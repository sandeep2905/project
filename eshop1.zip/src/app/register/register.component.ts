import { Component, OnInit } from '@angular/core';
import { CrudService } from '../crud.service';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private crud:CrudService,private cs:CookieService) { }

  ngOnInit() {
  }

  onSubmit(record){
  	// console.log(record)
  	// console.log(typeof localStorage)
  	if(localStorage && typeof localStorage=="object"){
  		console.log(localStorage)
  		localStorage.setItem("username",record.username);
  		localStorage.setItem("usermobile",record.usermobile);
  		localStorage.setItem("useremail",record.useremail);
  		localStorage.setItem("userpass",record.userpass);
  		// SMS
  		var msg = "Welcome to Angular JS , pass: "+record.userpass;
  		var str = "http://api.textlocal.in/send/?username=sandeepshripati97@gmail.com&hash=aeb7a361cd2b07bf4ec1739b3d8797ceaee825dbf1fd7c4a80a991ad918ddd85&message="+msg+"&sender=TXTLCL&numbers=91"+record.username+"&test=0"
  		// console.log(str);
  		this.crud.selectData_msg(str).subscribe((results)=>{
  			// console.log(results);
  		})

  	}
  }

}
