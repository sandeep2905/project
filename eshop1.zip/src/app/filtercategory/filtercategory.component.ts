import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { CrudService } from '../crud.service';

@Component({
  selector: 'app-filtercategory',
  templateUrl: './filtercategory.component.html',
  styleUrls: ['./filtercategory.component.css']
})
export class FiltercategoryComponent implements OnInit {

  constructor(private actRoute:ActivatedRoute,private crud:CrudService) { }

  finaldata=[]
  ngOnInit() {
  		var catid = Number(this.actRoute.snapshot.params.xyz);
  		// console.log(catid);
  		this.crud.selectData("products").subscribe(
  			(results)=>{
  				// console.log(results);
  				for(var answer in results){
  					// console.log(results[answer])
  					if(catid == results[answer].catid){
  						this.finaldata.push(results[answer])
  					}
  				}
  				console.log(this.finaldata)
  			
  			})
  }

}
