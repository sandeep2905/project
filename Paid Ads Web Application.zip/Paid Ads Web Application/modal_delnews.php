<?php
include('connection.php');

$id = $_GET['id'];

$del = "Delete from news where id='".$id."'";
if(mysqli_query($con, $delete))
{
	echo "window.location.href='DeleteNews.php'</script>";	
}
else{	
	echo "<script>alert('Invalid');</script>";
}	

?>