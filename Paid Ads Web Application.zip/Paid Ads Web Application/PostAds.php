<?php session_start();
include('CompanyHeader.php');

$val = !empty($_SESSION["compid_session"])?$_SESSION:" ";

if($val == " ")
{
	echo"<script>window.location.href='Login.php?logintype=company'</script>";
}
$compid_session = $_SESSION["compid_session"];

?>


<div class="container" style="margin-top:7%;">

<div class="row">
<div class="col-md-9 col-lg-9 mx-auto shadow-lg bg-white rounded p-3 mb-4">

<form method="POST" id="myform" enctype="multipart/form-data">
	<div class="row">
		<div class="col-md-12 col-lg-12">
			<div class="form-group">
				<label>Title: </label>
				<input type="text" name="title" class="form-control" placeholder="Enter Title">						
			</div>
		</div>         
	</div>
	
	<div class="row">
		<div class="col-md-12 col-lg-12">
			<div class="form-group">
				<label>Description: </label>
				<textarea class="form-control" rows="3" name="descr" placeholder="Enter Description"></textarea>					
			</div>
		</div>         
	</div>					
	
	<div class="row">
		<div class="col-md-12 col-lg-12">
		<label>Ad Type: </label>
			<div class="new">		
				<div class="form-group">
					<input type="checkbox" name="chkbx_type" value="Landscape" id="Landscape">
					<label for="Landscape">Landscape</label>
				</div>
				<div class="form-group">
					<input type="checkbox" name="chkbx_type" value="Portrait" id="Portrait">
					<label for="Portrait">Portrait</label>
				</div>
				<div class="form-group">
					<input type="checkbox" name="chkbx_type" value="Square" id="Square">
					<label for="Square">Square</label>
				</div>
			</div>
		</div>
	</div>
	
<div id="div_ads" style="display:none;">

	<div class="row">
		<div class="col-md-12 col-lg-12">
			<h5><b>Ad Price:</b> <i class="fa fa-inr"></i> <label id="lbl_adprice" style="font-size:18px; font-weight:normal;"></label></h5>
		</div>
	</div>
	
	<div class="row mt-3">
		<div class="col-md-4 col-lg-4">
			<h5><b>Ad Size:</b> <label id="lbl_adsize" style="font-size:18px; font-weight:normal;"></label></h5>
			<input type="hidden" value="" name="hidd_adsize" id="input_adsize" />
		</div>
	</div>

	<div class="row mt-3">
		<div class="col-md-12 col-lg-12">
			<div class="form-group">
				<label for="file">Upload Ad Image: </label><br/>
				<input type="file" id="file" name="fileToUpload" accept=".png, .jpg, .jpeg">
				<label id="validation_upload" style="color:black; font-size:14px; display:none;"></label>				
			</div>
		</div>         
	</div>		
	
	<div class="row mt-3">
		<div class="col-md-12 col-lg-12">
			<label>Reference Link: </label>
			<input type="text" name="reflink" id="input_reflink" class="form-control" placeholder="Enter Reference Link">	
			<span id="reflink_valdn" style="color:red; font-size:15px;" style="display:none;"></span>
		</div>
	</div>
	
	<div class="row mt-4">
		<div class="col-md-12 col-lg-12">
			<div class="card">
				<div class="card-header"><h5>Make Payment</h5></div>
				
					<div class="card-body">
						<div class="row">
							<div class="col-md-9 col-lg-9">
								<div class="form-group">
									<label for="" style="font-size:15px;">Name on Card</label>
									<input type="text" id="namecard" placeholder="Enter Name on Card" name="name_card" class="form-control">
								</div>
							</div>
										
							<div class="clearfix"></div>
										
							<div class="col-md-10 col-lg-10">
								<div class="form-group">
									<label for="" style="font-size:15px;">Card No</label>
									<input type="number" id="crdno" placeholder="Enter Card No" name="cardno" class="form-control">
								</div>
							</div>
										
							<div class="clearfix"></div>
										
							<div class="col-md-5 col-lg-5">
								<div class="form-group">
									<label for="" style="font-size:15px;">CVV</label>
									<input type="number" id="cvvno" placeholder="Enter CVV" name="cvv" class="form-control">
								</div>
							</div>
										
							<div class="col-md-7 col-lg-7">
								<div class="form-group">
									<label for="" style="font-size:15px; margin-left: 5%;">Expiry Month & Year</label>
									<div class="row">
										<div class="col-md-5 col-lg-5">
											<input type="number" id="exp_mm1" placeholder="mm" name="exp_mm" class="form-control mmyy" style="margin-left: 15%;">
										</div>
										<div class="col-md-2 col-lg-2" style="padding-right: 0px !important; max-width: 2.666667%;">
											<span style="font-size: 20px;">/</span>
										</div>
										<div class="col-md-5 col-lg-5">
											<input type="number" id="exp_yy1" placeholder="yy" name="exp_yy" class="form-control mmyy">
										</div>
													
									</div>							
								</div>
							</div>
										
							<div class="clearfix"></div>
										
							<div class="col-md-5 col-lg-5">
								<div class="form-group">
									<label for="" style="font-size:15px;">Total Amount <i class="fa fa-inr"></i></label>
									<input value="" type="number" id="t_amt" name="total_amt" class="form-control" readonly /> 
								</div>
							</div>
										
							<div class="clearfix"></div>
										
					</div>
				</div>
		
			<div class="card-footer text-center"><button type="submit" name="btn_submit" class="btn btn-success">Submit</button></div>
		
			</div>
		
		</div>
	</div>
</div>	

</form>

</div>
</div>
	
</div>


<?php


if(isset($_POST['btn_submit'])){
	
$title = $_POST['title'];	
$descr = $_POST['descr'];
$chkbx_type = $_POST['chkbx_type'];
$reflink = $_POST['reflink'];
$total_amt = $_POST['total_amt'];
$hidd_adsize = $_POST['hidd_adsize'];


	$file=$_FILES['fileToUpload']['tmp_name'];
    $iname=$_FILES['fileToUpload']['name'];
	
	if(isset($iname))
    {    
        $location = 'images/';  

        $imageFileType = strtolower(pathinfo($location.$iname,PATHINFO_EXTENSION));


        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg")
        {
            echo "<script>document.getElementById('validation_upload').innerHTML='Sorry, only .jpg,.png,.jpeg above mentioned files are allowed.';</script>";
            echo "<script>document.getElementById('validation_upload').style.display = 'block';</script>";                  

        }
        else
        {
            if(move_uploaded_file($file, $location.$iname))
            {					
				$insert = "Insert into ads(CompId,Title,Descr,Image,ImgSize,ImgType,TotalAmount,RefLink,PaymentStatus,Status,Views) values('$compid_session','$title','$descr','$iname','$hidd_adsize','$chkbx_type','$total_amt','$reflink','Paid','','')";				
				
				if(mysqli_query($con, $insert))
				{
					echo "<script>alert('Ad Sent for Approval Successfully');</script>";
					echo "<script>window.location.href='PostAds.php'</script>";			
				}	
				else
				{
					echo "<script>alert('Invalid');</script>";
				}
																	
			}
			
		}
			
	}	
	
}
	
include('Footer.php')

?>


<script type="text/javascript">

$(document).ready(function() {

$('input[name="chkbx_type"]').on('change', function()  
{
	$('input[name="chkbx_type"]').not(this).prop('checked', false); 
	
	var chkbxValue = $("input[name='chkbx_type']:checked").val();
		
	if(chkbxValue != "" && chkbxValue != undefined){
		
		if(chkbxValue == "Landscape"){
			$("#lbl_adprice").text("10000");
			$("#t_amt").val("10000");
			$("#lbl_adsize").text("1200 * 1600");
			$("#input_adsize").val("1200 * 1600");
		}
		else if(chkbxValue == "Portrait"){
			$("#lbl_adprice").text("3000");
			$("#t_amt").val("3000");
			$("#lbl_adsize").text("250 * 550");
			$("#input_adsize").val("250 * 550");
		}
		else if(chkbxValue == "Square"){
			$("#lbl_adprice").text("4500");
			$("#t_amt").val("4500");
			$("#lbl_adsize").text("800 * 800");
			$("#input_adsize").val("800 * 800");
		}	
	
		$("#div_ads").slideDown();	
				
	}
	else{
		$("#div_ads").slideUp();		
	}	
	
});


$("#exp_mm1").focusout(function() {
   if(this.value > 12 || this.value <= 0)
	{ 
		this.value = '';
	}
 });
 
 
 $("#input_reflink").blur(function() {
	 
	 var val_reflink = $(this).val();
	 
	 if(val_reflink != ""){
		 
		if(val_reflink.includes("http") || val_reflink.includes("https")){
		  
		 
		}
		else{
			$(".error").html("Please Enter Valid Reference Link").show(); 
		}
		 
	 }
	 else{
		 $("#reflink_valdn").html("Please Enter Valid Reference Link").hide();
	 } 
	  
	  
 });

 
	
});


$(function()
    {
		$.validator.addMethod("value1", function(value, element, arg){
		  return arg !== value;
		 },);
		
		$('#myform').validate({
            
            rules:{
				title : "required",
				descr : "required",
				chkbx_type : "required",						
				selc_adsize : { value1: "Choose One..." },
				fileToUpload : "required",
				reflink : "required",	
                name_card : "required",
                cardno: {
				  required: true,
				  maxlength: 16,
				  minlength: 16,
				},
                cvv: {
				  required: true,
				  maxlength: 3,
				  minlength: 3,
				},
				exp_mm: {
				  required: true,
				  maxlength: 2,
				  minlength: 2,
				},
				exp_yy: {
				  required: true,
				  maxlength: 4,
				  minlength: 4,
				},	
            },

            messages:{
				title:"<h5 style='font-size: 15px;'>Please Enter Valid Title</h5>",
				descr:"<h5 style='font-size: 15px;'>Please Enter Valid Description</h5>",
				chkbx_type : "<h5 style='font-size: 15px;'>Please Select Any 1 Ad Type</h5>",
				selc_adsize:{ value1: "<h5 style='font-size:15px;'><b>Please Select Ad Size</b></h5>" },
				fileToUpload:"<h5 style='font-size: 15px;'>Please Upload Image</h5>",
				reflink : "<h5 style='font-size:15px;'>Please Enter Valid Reference Link</h5>",
				name_card:"<h5 style='font-size:15px;'>Please Enter Valid Name on Card</h5>",
				cardno:"<h5 style='font-size:15px;'>Please Enter 16 Digit Card No</h5>",             
                cvv:"<h5 style='font-size:15px;'>Please Enter 3 Digit CVV</h5>",
				exp_mm	:"<h5 style='font-size:15px;'>Please Enter Valid Expiry Month</h5>",
				exp_yy : "<h5 style='font-size:15px;'>Please Enter Valid Expiry Year</h5>"
            }
			
        });
		
	});
		
	
</script>


</body>
</html>