<?php
include('connection.php');
?>

<!DOCTYPE html>
<html>
<head>
<title>Paid Ads Web Application</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/style.css" />

<style>

a:hover{
text-decoration : none;	
color:black;	
}	

a{
text-decoration : none;			
color:black;	
}

.div_ad{
	background-color: #fff;
    font-size: 15px;
    font-weight: 700;
    font-family: 'Arimo',sans-serif;
    top: 10px;
    color: black;
    left: 86%;
    padding-left: 5px;
    padding-right: 5px;
    line-height: 15px;
    border-radius: 2px;
    position: absolute;
    box-shadow: 0 1px 2px rgba(0,0,0,.5);
}

</style>

</head>

<body style="background-color: #a09f9f1f;">

<div class="sticky">

<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #363636;">
  <a class="navbar-brand" href="#">Paid Ads Web Application</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="index.php">Home</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="Login.php?logintype=admin"><i class="fa fa-user-circle"></i> ADMIN</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="Login.php?logintype=company"><i class="fa fa-users"></i> COMPANY</a>
      </li>
	 
    </ul>
  </div>
</nav>

<div class="container mt-3 mb-3">
<div class="row">
	<div class="col-sm-12 col-md-9">
		
	<?php
	
	$counter = 1;
	
	$sel1= "select adid from ads where imgtype = 'Landscape' Order by adid ASC";
	$rel1=$con->query($sel1);
	while($data1 = mysqli_fetch_array($rel1)){
		$id_arr[] = $data1['adid'];		
	}	
	
	
	$sel= "select title,descr,image,datetime from news";
	$rel=$con->query($sel);
	$count_rows = mysqli_num_rows($rel);
	if(mysqli_num_rows($rel) == 0){
		echo '<h5 class="text-center">No News to display</h5>';
	}
	else{
		
		$j = 0;
		
		for($i=1; $i<=$count_rows; $i++){
			
			$data = mysqli_fetch_array($rel);
						
			if($i == $counter*3){

			if(isset($id_arr)){
				
			$sel2 = "select title,descr,image,reflink from ads where imgtype = 'Landscape' and status='Approved' and adid = '".$id_arr[$j]."' Limit 1";
			$rel2 = $con->query($sel2);
			if(mysqli_num_rows($rel2) == 0){
				
			}
			else{		
				while($data2=mysqli_fetch_array($rel2)){
					
				?>	
				
			<div class="card mt-2 mb-2">
				<div class="card-body">	
					<div class="row">
						<div class="col-md-6 col-lg-6">
						
						<a href="<?php echo $data2['reflink'] ?>">
							<h4><?php echo $data2['title'] ?></h4>
							
							<p><?php echo $data2['descr'] ?></p>
						</div>
								
						<div class="col-md-6 col-lg-6 text-right">		
							<div class="div_ad">
								Ad
							</div>
							<img src="images/<?php echo $data2['image'] ?>" alt="ad images" class="img-responsive img-thumbnail" style="width:250px; height:120px;"/>
							</a>														
						</div>
					</div>
				</div>
			</div>	

			<?php
			
				$counter++;
			
				}
				
				 $j++;	
			  }
								
			}
					 	  
		}
				
		?>
					
		<div class="card mt-2 mb-2">
			<div class="card-body">	
				<div class="row">
					<div class="col-md-6 col-lg-6">
						<h4><?php echo $data['title'] ?></h4><br/>
						
						<p><?php echo $data['descr'] ?></p>
					</div>
							
					<div class="col-md-6 col-lg-6 text-right">
						<label style="color: grey; font-size: 14px;"><?php echo $data['datetime'] ?></label><br/>
						<img src="images/<?php echo $data['image'] ?>" alt="news images" class="img-responsive img-thumbnail" style="width:250px; height:120px;"/>
								
					</div>
				</div>
			</div>
		</div>	
			
		<?php	
				
		}
	}

	
	?>
		
	</div>
	
	<div class="col-sm-12 col-md-3">
	
	<?php
	
	$chk_s = 0;
	
	$sel_id= "select adid from ads where imgtype = 'Square' Order by adid ASC";
	$rel_id=$con->query($sel_id);
	while($data_id = mysqli_fetch_array($rel_id)){
		$id_sqarr[] = $data_id['adid'];		
	}	
		
	$sel_p= "select adid,compid,title,descr,image,reflink,views from ads where imgtype = 'Portrait' and status = 'Approved'";
	$rel_p=$con->query($sel_p);
	$count_rows_p = mysqli_num_rows($rel_p);

	if(mysqli_num_rows($rel_p) == 0){
		
		if(isset($id_sqarr)){
			
			foreach($id_sqarr as $id_sqarr1){
			
			$sel_s= "select compid,title,descr,image,reflink from ads where imgtype = 'Square' and status = 'Approved' and adid = '".$id_sqarr1."' ";
			$rel_s = $con->query($sel_s);
			if(mysqli_num_rows($rel_s) == 0){
					
			}
			else{		
				while($data_s=mysqli_fetch_array($rel_s)){
						
			?>	
				
			<div class="card mt-2 mb-2">
				<div class="card-header text-center" style="background-color: #00000073;color: white; font-size: 12px;">
					ADVERTISEMENT
				</div>
				<div class="card-body text-center">	
						
				<a href="<?php echo $data_s['reflink'] ?>">
						
				<img src="images/<?php echo $data_s['image'] ?>" alt="ads" class="img-responsive img-thumbnail" style="width: 150px;" /><br/><br/>					
							
				<h4><?php echo $data_s['title'] ?></h4>
					
				<p><?php echo $data_s['descr'] ?></p>
														
				</a>
						
				</div>
			</div>	

				<?php
					
				}
					
				}

			}
			
		}
	}
	else{
		
		$l=0;
		
		for($k=1; $k<=$count_rows_p; $k++){
			
		$data_p = mysqli_fetch_array($rel_p);
		
		if($k == $chk_s){

			if(isset($id_sqarr)){
							
			$sel_s = "select adid,compid,title,descr,image,reflink from ads where imgtype = 'Square' and status = 'Approved' and adid = '".$id_sqarr[$l]."' Limit 1";		
			$rel_s = $con->query($sel_s);
			if(mysqli_num_rows($rel_s) == 0){
				
			}
			else{		
				while($data_s=mysqli_fetch_array($rel_s)){
					
				?>	
				
			<div class="card mt-2 mb-2">
				<div class="card-header text-center" style="background-color: #00000073;color: white; font-size: 12px;">
					ADVERTISEMENT
				</div>
				<div class="card-body text-center">	
					
					<a href="<?php echo $data_s['reflink'] ?>">
					
					<img src="images/<?php echo $data_s['image'] ?>" alt="ads" class="img-responsive img-thumbnail" style="width: 150px;" /><br/><br/>					
						
					<h4><?php echo $data_s['title'] ?></h4>
				
					<p><?php echo $data_s['descr'] ?></p>
													
					</a>
					
				</div>
			</div>	

			<?php
				$l++;
			
				}
				
			  }
				
			}
		 	  
		}
				
		?>

		<div class="card mt-2 mb-2">
			<div class="card-header text-center" style="background-color: #00000073;color: white; font-size: 12px;">
				ADVERTISEMENT
			</div>
			<div class="card-body text-center" id="div_portrait">				
				<a href="<?php echo $data_p['reflink'] ?>" target="_blank" id="<?php echo $data_p['adid'] ?>" class="<?php echo $data_p['views'] ?>" >
				
				<h4 style=""><?php echo $data_p['title'] ?></h4>
				
				<p style=""><?php echo $data_p['descr'] ?></p>
	
				<img src="images/<?php echo $data_p['image'] ?>" alt="ads" class="img-responsive" style="width: 100%;" />
				
				</a>				
			</div>			
		</div>		
	<?php

		$chk_s = $chk_s + 2;
		
		}
	}	
	
	?>
		
	</div>
	
</div>
</div>


<?php include('Footer.php') ?>

<script type="text/javascript">

$(document).ready(function() {
	
    $("#div_portrait a").click(function() {
		
		var id = $(this).attr('id');
		var views = $(this).attr('data-id');
		
		$.ajax({
		  type: "POST",
		  url: "views_upd.php",
		  data:{id:id,views:views},
		  success: function(data){
			console.log(data);
				
		  }
		  
		});
        
    });
	
});




</script>

</body>
</html>