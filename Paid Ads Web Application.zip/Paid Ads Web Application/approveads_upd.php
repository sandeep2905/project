<?php
include("connection.php");

$adid = $_POST['id'];

	$update = "Update ads set status = 'Approved' where adid='".$adid."'";

	if(mysqli_query($con,$update)){
				
		echo 'Ad Approved Successfully';		
	}
	else
	{
		echo 'Invalid';
	}	
  
?>