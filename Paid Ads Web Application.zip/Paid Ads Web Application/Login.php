<?php session_start();
include("connection.php");

if($_GET['logintype'] == "admin" || $_GET['logintype'] == "company"){

?>

<!DOCTYPE html>
<html>
<head>
<title>Paid Ads Web Application</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/style.css" />


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<script src="js/jquery.validate.min.js"></script>

</head>

<body style="background-image: url(images/register-backgroundimage.jpg); background-repeat: no-repeat; background-size: cover;">

<div class="container">
	<div class="row">
		<div class="col-md-5 col-lg-5 mt-4 mb-4 mx-auto bg-white shadow-lg p-3  rounded">
				<form id="myform" method="POST">
						<div class="row">
							<div class="col-sm-12">
								<?php
									
								if($_GET['logintype'] == "admin"){
									
								?>									
								<h1 class="h1-formbox">Admin Login</h1>
								<?php
										
								}
								else if($_GET['logintype'] == "company"){
								?>
								<h1 class="h1-formbox">Company Login</h1>
								
								<?php
								}
								?>
								
							</div>
						</div>

						<div class="row">
							<div class="col-sm-12">
								<div class="inputBox ">
								
									<?php
									
									if($_GET['logintype'] == "admin"){
									
									?>
									
									<div class="inputText">Admin Id</div>
									<input type="text" name="txtbx_adminid" class="input">
									
									<?php
										
									}
									else if($_GET['logintype'] == "company"){
									?>
									
									<div class="inputText">Email Id</div>
									<input type="text" name="txtbx_emailid" class="input">
									
									<?php
									}
									?>
									
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-sm-12">
								<div class="inputBox">
									<div class="inputText">Password</div>
									<input type="password" name="txtbx_pswd" class="input">
								</div>
							</div>
						</div>
						
						<div class="row mb-2">
							<div class="col-sm-12">
							
							<?php
									
							if($_GET['logintype'] == "admin"){
									
							?>
							<input type="submit" name="btn_adminlogin" class="button-adminlogin" value="Submit" />
							
							<?php										
							}
							else if($_GET['logintype'] == "company"){
							?>
							<input type="submit" name="btn_complogin" class="button-adminlogin" value="Submit" /><br/>
							
							<center><a href="CompanyRegister.php" style="font-size:15px; color:maroon;">CREATE AN ACCOUNT</a></center>
							
							<?php										
							}
							
							?>							
								
							</div>
						</div>
						
						<center style="color: blue; font-weight: bold;"><a href="index.php"> <i class="fa fa-arrow-left"></i> Back To Home</a></center>
												
				</form>
		</div>
	</div>
		
</div>

<?php

if(isset($_POST['btn_adminlogin'])){

	$txtbx_adminid = $_POST['txtbx_adminid'];
	$txtbx_pswd = $_POST['txtbx_pswd'];
	
	$sel = "select adminid from admin where adminid='$txtbx_adminid' and password='$txtbx_pswd'";
	$rel=$con->query($sel);	
		
	if($data=mysqli_fetch_array($rel))
	{
		$adminid = $data['adminid'];
			
		$_SESSION["adminid_session"] = $adminid;
		
		echo "<script>window.location.href='PostNews.php'</script>";							
	}
	else
	{
		echo "<script>alert('Invalid Login');</script>";
	}
	

}

if(isset($_POST['btn_complogin'])){

	$txtbx_emailid = $_POST['txtbx_emailid'];
	$txtbx_pswd = $_POST['txtbx_pswd'];
	
	$sel = "select compid from company where emailid='$txtbx_emailid' and password='$txtbx_pswd'";
	$rel=$con->query($sel);	
		
	if($data=mysqli_fetch_array($rel))
	{
		$compid = $data['compid'];
			
		$_SESSION["compid_session"] = $compid;
		
		echo "<script>window.location.href='PostAds.php'</script>";							
	}
	else
	{
		echo "<script>alert('Invalid Login');</script>";
	}
	
}

?>
 

<script type="text/javascript">

	$(".input").focus(function() {
		$(this).parent().addClass("focus");
	});
	
	
	$("#myform").validate({
            
            rules:{
				
				<?php
				if($_GET['logintype'] == "admin")
				{
				?>						
				txtbx_adminid: "required",
					
				<?php	 
				}
				else if($_GET['logintype'] == "company"){
				?>
               	txtbx_emailid: "required",
                
				<?php
				}
				?>
				
				txtbx_pswd : "required",				
				
           },

            messages:{
				<?php
				if($_GET['logintype'] == "admin")
				{
				?>					
				txtbx_adminid:"<h5 style='font-size: 15px;'>Please Enter Valid Admin Id</h5>",
				<?php
				}
				else if($_GET['logintype'] == "company"){					
				?>
				txtbx_emailid:"<h5 style='font-size: 15px;'>Please Enter Valid Email Id</h5>",
				<?php 
				}
				?>
                txtbx_pswd:"<h5 style='font-size: 15px;'>Please Enter Valid Password</h5>",
                							
            },

            submitHandler: function(form){
                form.submit();
            }

        });
	
</script>


</body>

</html>


<?php

}
else{
	echo "<script>window.location.href = 'index.php';</script>";
}	

?>