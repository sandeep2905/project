<?php session_start();
include('AdminHeader.php');

$val = !empty($_SESSION["adminid_session"])?$_SESSION:" ";

if($val == " ")
{
	echo"<script>window.location.href='Login.php?logintype=admin'</script>";
}
$adminid_session = $_SESSION["adminid_session"];

?>

<style>

tbody {
    display: block;
    height: 300px;
    overflow:auto;
}
thead, tbody tr {
    display:table;
    width:100%;
    table-layout:fixed;
}

tbody td{	
	word-break: break-word;	
}	

</style>

<div class="container-fluid" style="margin-top: 7%;">

    <div class="row" id="searchbox">
        <div class="col-md-6 col-lg-6"> 
			<form method="POST">
				<div class="input-group" style="width: 60%;">
					<input name="search_name" type="text" class="form-control" placeholder="Search Company Name/Ad Title">				
					<div class="input-group-btn">
						<button class="btn btn-primary" name="btn_search" type="submit">
							<i class="fa fa-search" aria-hidden="true" style="font-size: 17px;"></i>
						</button>
					</div>
				</div>
			</form>
		</div>          
    </div>
		
	<div class="row mt-3">
        <div class="col-md-12 col-lg-12 text-center">
		
		 <div class="table-responsive" id="AdsTableArea">
		   <table id="AdsTable" class="table table-striped table-bordered table-hover text-center" width="100%">				
				<?php

				if(isset($_POST['btn_search']))
				{
					$sel = "select c.compname,a.adid,a.title,a.descr,a.image,a.imgsize,a.imgtype,a.totalamount,a.reflink,a.paymentstatus,a.status from ads as a join company as c on a.compid = c.compid where (a.title like '%".$_POST['search_name']."%' or c.compname like '%".$_POST['search_name']."%') Order by a.adid desc";	
				}
				else
				{
				   $sel = "select c.compname, a.adid,a.title,a.descr,a.image,a.imgsize,a.imgtype,a.totalamount,a.reflink,a.paymentstatus,a.status from ads as a join company as c on a.compid = c.compid Order by a.adid desc";		   
				}

				$rel=$con->query($sel);
				if(mysqli_num_rows($rel)==0)
				{			  
					echo "<center><h4>No records to display</h4></center>
					document.getElementById('searchbox').style.display='none'</script>";
				}
				else
				{
					echo '<script>document.getElementById("searchbox").style.display="block"</script>        <thead>
					<tr>
					<th>Company Name</th>		
					<th>Ad Image</th>				
					<th>Title</th>
					<th>Description</th>
					<th>Size</th>
					<th>Type</th>
					<th>Reference Link</th>
					<th>Total Amount</th>
					<th>Status</th>
					<th>Action</th>
					</tr>
					</thead>

					<tbody>';
						  
					while($data=mysqli_fetch_array($rel))
					{
						$compname = $data['compname'];
						$image=$data['image'];							
						$title=$data['title'];
						$descr=$data['descr'];
						$imgsize = $data['imgsize'];
						$imgtype = $data['imgtype'];
						$totalamount = $data['totalamount'];
						$reflink = $data['reflink'];
						$status = $data['status'];
											
						echo'<tr>
						<td>'.$compname.'</td>
						<td><img src="images/'.$image.'" alt="" style="width:100px; height:100px;" /></td>
						<td>'.$title.'</td>
						<td>'.$descr.'</td>				
						<td>'.$imgsize.'</td>
						<td>'.$imgtype.'</td>
						<td>'.$reflink.'</td>
						<td>'.$totalamount.'</td>
						<td>'.$status.'</td>';
						
						if($status == ""){
							
							echo '<td><button type="button" id="'.$data['adid'].'" class="btn btn-primary btn_approve">Approve</button></td>';
						}
						else{
							echo '<td></td>';
						}
																
						echo'</tr>';					
					}
					
					echo'</tbody>';
				}
									
				?>
				
				</table> 
				</div>
				
			</div>
		</div>			
						
</div>	

<?php include('footer.php') ?>

<script type="text/javascript">

$('.btn_approve').click(function(){
	
	var id = $(this).attr('id');
	
	$.ajax({
	  type: "POST",
	  url: "approveads_upd.php",
	  data:{id:id},
	  success: function(data){
		alert(data);
		window.location.href="ApproveAds.php";
			
	  }
	});

});



</script>
