<?php session_start();
include('AdminHeader.php');

$val = !empty($_SESSION["adminid_session"])?$_SESSION:" ";

if($val == " ")
{
	echo"<script>window.location.href='Login.php?logintype=admin'</script>";
}
$adminid_session = $_SESSION["adminid_session"];

?>

<style>

tbody {
    display: block;
    height: 300px;
    overflow:auto;
}
thead, tbody tr {
    display:table;
    width:100%;
    table-layout:fixed;
}

</style>

<div class="container-fluid" style="margin-top:7%;">
	<div class="table-responsive" id="NewsTableArea">
	   <table id="NewsTable" class="table table-striped table-bordered table-hover text-center" width="100%">
	   
		<?php
		
		$output = "";
		
		$sel = "select id,title,descr,image,datetime from news Order by datetime desc";
		$rel=$con->query($sel);
		
		if(mysqli_num_rows($rel) > 0){
			
			$output .= '<thead><tr>                  						
				<th>News Image</th>				
				<th>Title</th>
				<th>Description</th>
				<th>Date and Time</th>
				<th>Action</th>
				</tr>
				</thead>
				
				<tbody>';
				
				while($data=mysqli_fetch_array($rel))
				{						
					$output .= '<tr>
					<td><img src="images/'.$data['image'].'" alt="" style="width:100px; height:100px;" /></td>
					<td>'.$data['title'].'</td>
					<td>'.$data['descr'].'</td>				
					<td>'.$data['datetime'].'</td>
					<td><a href="#myModalDel" class="btn btn-danger" data-id="'.$data['id'].'" role="button" data-toggle="modal" style="color:#fff;"><em class="fa fa-trash"></em></a></td>
					</tr>';
					
				}
				
				$output .= '</tbody>';	
				echo $output;
		}
		else{
			
			echo '<h5 class="text-center">No records to display</h5>';		
		}	
		
		?>
	   
	   
       </table> 
    </div>
</div>


<div class="modal small fade" id="myModalDel" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">              
                 <h3 id="myModalLabel">Delete Confirmation</h3>
            </div>
            <div class="modal-body">
                <p class="error-text" style="font-size:17px;"><i class="fa fa-warning modal-icon"></i> 	Are you sure you want to delete?
                </p>
            </div>
            <div class="modal-footer">
               <button class="btn btn-default"data-dismiss="modal" aria-hidden="true">No</button> <a href="#" class="btn btn-danger" id="modalDelete">Yes</a>

            </div>
        </div>
    </div>
</div>


<?php 
include('footer.php')
?>

<script type="text/javascript">

	$('.trash').click(function(){
		var id = $(this).data('id');
		$('#modalDelete').attr('href','modal_delnews.php?id='+id);
	});		

</script>


</body>
</html>
