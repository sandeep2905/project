<?php
include("connection.php");

$adid = $_POST['id'];
$views = $_POST['views'];

$localIP = gethostbyname(trim(exec("hostname")));

$sel = "select ip from visitors where ip='".$localIP."' and adid='".$adid."'";
$rel=$con->query($sel);
if(mysqli_num_rows($rel) == 0){
	
	$insert = "Insert into visitors(adid,ip) values('$adid','$localIP')";
	if(mysqli_query($con,$insert)){	

		if(isset($views)){
			$views ++;
		}
		else{
			$views = 1;
		}
		
		$update = "Update ads set Views = '".$views."' where adid='".$adid."'";
		if(mysqli_query($con,$update)){
				
		}
		else
		{
			
		}
	}
	else
	{		
	}
	
}
else{


}	






			


	

	
  
?>