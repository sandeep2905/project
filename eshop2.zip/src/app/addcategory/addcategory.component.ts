import { Component, OnInit } from '@angular/core';
import { CrudService } from '../crud.service';

@Component({
  selector: 'app-addcategory',
  templateUrl: './addcategory.component.html',
  styleUrls: ['./addcategory.component.css']
})
export class AddcategoryComponent implements OnInit {
	public errMsg;
	public catData;
  constructor(private crud:CrudService) { }

  ngOnInit() {
  	// this.crud.selectData("category").subscribe(
  	// 	(results)=>{
  	// 		// console.log(results);
  	// 		this.catData = results;
  	// 	})
    this.showcatdata()
  }

  showcatdata(){
    this.crud.selectData("category").subscribe(
      (results)=>{
        // console.log(results);
        this.catData = results;
      }
      )
  }

  add_category(catdata){

  			if(catdata.length == 0){
  				this.errMsg = "please Enter Category";
   			}
   			else {
   				this.crud.insertData("category",{name:catdata}).subscribe((
   					results)=>{

   					// console.log(results);
   					this.errMsg = "Record Added";
   				})
   			}
  }

  deletecat1(id){

    // alert(id)
    this.crud.deleteData("category",id).subscribe((results)=>{
      // console.log(results)
      // this.errMsg = "Record Added";
      this.showcatdata()
    })
  }

}
