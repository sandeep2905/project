import { Component, OnInit } from '@angular/core'; 
import {FormBuilder,FormGroup,FormControl,Validators,NgForm} from '@angular/forms';

@Component({
  selector: 'app-reactiveform',
  templateUrl: './reactiveform.component.html',
  styleUrls: ['./reactiveform.component.css']
})
export class ReactiveformComponent implements OnInit {

	signupForm:FormGroup;  
	username:string="";  
	usermobile:string="";  
	useremail:string="";  
	userpass:string="";

  constructor(private frmbuilder:FormBuilder) {

  	this.signupForm=this.frmbuilder.group({  
    username:new FormControl(),  
    usermobile:new FormControl(),  
    useremail:new FormControl(),  
    userpass:new FormControl()  
    });

   }

  ngOnInit() {

  	this.signupForm= this.frmbuilder.group({  
  username:['',Validators.compose([Validators.required])],  
  usermobile:['',[Validators.required]],  
  useremail:['',[Validators.required]],  
  userpass:['',Validators.required]  
	})  
  }

  PostData(val)  
  {  
    console.log(val);  
  } 


}
