import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { HttpModule } from '@angular/http';
import { CrudService } from './crud.service';
import { CookieService } from 'ngx-cookie-service';
import {ReactiveFormsModule} from '@angular/forms'

import { AppComponent } from './app.component';
import { BrandComponent } from './brand/brand.component';
import { CategoryComponent } from './category/category.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { SliderComponent } from './slider/slider.component';
import { ProductsComponent } from './products/products.component';
import { AddcategoryComponent } from './addcategory/addcategory.component';
import { AddbrandComponent } from './addbrand/addbrand.component';
import { DeletecategoryComponent } from './deletecategory/deletecategory.component';
import { EditcategoryComponent } from './editcategory/editcategory.component';
import { FiltercategoryComponent } from './filtercategory/filtercategory.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { CartComponent } from './cart/cart.component';
import { ReactiveformComponent } from './reactiveform/reactiveform.component';

const appRoutes: Routes = [
  { path: '', component: ProductsComponent  },
  { path: 'category',      component: AddcategoryComponent },
  { path: 'brand',      component: AddbrandComponent },
  { path: 'deleteCat/:xyz',  component: DeletecategoryComponent },
  { path: 'editCat/:xyz',  component: EditcategoryComponent },
  { path: 'filter_cat/:xyz',  component: FiltercategoryComponent },
  { path: 'cart',  component: CartComponent },
  { path: 'register',  component: RegisterComponent },
  { path: 'login',  component: LoginComponent },
  { path: 'reactiveform',  component: ReactiveformComponent },
  

];



@NgModule({
  declarations: [
    AppComponent,
    BrandComponent,
    CategoryComponent,
    HeaderComponent,
    FooterComponent,
    SliderComponent,
    ProductsComponent,
    AddcategoryComponent,
    AddbrandComponent,
    DeletecategoryComponent,
    EditcategoryComponent,
    FiltercategoryComponent,
    LoginComponent,
    RegisterComponent,
    CartComponent,
    ReactiveformComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(
      appRoutes,
    ),
    HttpModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [CrudService,CookieService],
  bootstrap: [AppComponent]
})
export class AppModule { }
