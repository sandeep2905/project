import { Component, OnInit } from '@angular/core';
import { CrudService } from '../crud.service';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private crud:CrudService,private cs:CookieService) { }

  ngOnInit() {
  }
  err:string = "";
  onSubmit(val){
  if (localStorage && typeof localStorage=="object"){

  	var email = localStorage.getItem("useremail");
  	var pass = localStorage.getItem("userpass");
  	if(email == val.useremail && pass == val.userpass){
  		// console.log("success");
  		this.err="OK";
  	}
  	else{
  		this.arr = "Invalid Credential";
  	}
  }
}

}
