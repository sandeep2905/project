import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { map } from 'rxjs/Operators';


@Injectable({
	providedIn : 'root'
})
export class CrudService {

	private url = "http://localhost:3000/";

  constructor(private http:Http) { }

  insertData = function(jsonTable,record){
    return this.http.post(this.url+jsonTable , record).pipe(
      map(
        (response)=>{
          return response.json();
        }
      )
    );
  }
  updateData = function(jsonTable,id,record){

    return this.http.put(this.url+jsonTable+"/"+id,record).pipe(
      map(
        (response)=>{
          return response.json();
        }
      )
    );
  }
  deleteData = function(jsonTable,record){
    return this.http.delete(this.url+jsonTable+"/"+record).pipe(
      map(
        (response)=>{
          return response.json();
        }
      )
    );
  }

  selectData_filter = function(path,id){

    // return path;
    // console.log(this.url+path)
    return this.http.get(this.url+path+"/"+id).pipe(
      map(
          (response)=>{
            return response.json();
          }
        )
      );
  }

  selectData = function(path){

  	// return path;
  	// console.log(this.url+path)
  	return this.http.get(this.url+path).pipe(
  		map(
  				(response)=>{
  					return response.json();
  				}
  			)
  		);
  }

  selectData_msg = function(path){

    // return path;
    // console.log(this.url+path)
    return this.http.get(path).pipe(
      map(
          (response)=>{
            return response.json();
          }
        )
      );
  }


}
