import { Component, OnInit } from '@angular/core';
import { CrudService } from '../crud.service';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
	cartRecord:string
	public productData=[];
  constructor(private crud:CrudService,private cs:CookieService) { }

  ngOnInit() {
  		// console.log(this.cs);
  		if(this.cs.get("product_id")){
  			var res = this.cs.get("product_id").split(",")
  			// console.log(res);

  			this.crud.selectData("products").subscribe((results)=>{
  				// console.log(results);
  				for(var ans in results){
  					// console.log(typeOf results[ans].id);
  					if(res.indexOf(results[ans].id.toString()) >=0 ){
  						this.productData.push(results[ans])
  					}
  				}
  				// console.log(this.productData)
  			})
  		}
  		else{
  			this.cartRecord = "No Data Found";
  		}
  }

  deleteToCart(id,e){
  	e.preventDefault();
  	// console.log(e)
  	// console.log(id)
  	var cookiedata = this.cs.get("product_id").split(",")
  	// console.log(cookiedata);
  	var pos = cookiedata.indexOf(id.toString());
  	// console.log(pos);
  	cookiedata.splice(pos,1)
  	// console.log(cookiedata);
  	var newval = cookiedata.join(",");
  	this.cs.set("product_id",newval)
  	e.target.parentNode.parentNode.parentNode.parentNode.style.display="none";
  }

}
