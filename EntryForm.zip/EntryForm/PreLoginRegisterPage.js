const PreLoginRegisterPage = ({ checkLoginStatus }) => {

    return (
        <>
            <div className="box_div">
                <div className="stepsreg_div">
                    <div className="head_div">
                        <h2>Steps to Register</h2>
                        <button className="btn gotoform_btn first_btn" onClick={() => checkLoginStatus()}>Go to the form</button>
                    </div>
                    <h4>Dear Aspirants,
                        <br /><br />
                        Please read the process carefully before filling out the form:
                    </h4>
                    <ul>
                        <li><span>Step 1:</span> <span>Keep 4 pictures ready: close-up, mid-length, full length & no make-up</span> </li>
                        <li><span>Step 2:</span> <span>Keep the scanned copies of the documents mentioned below for Eligibility Proof:</span>
                            <ul className="inner_ul">
                                <li>Nationality Proof: Passport (preferred option) or Aadhar Card or Voters ID or Driving License. In the case of OCI applicant, will require an OCI card</li>
                                <li>State Eligibility Proof: the below-mentioned eligibility proof is required to apply from:
                                    <ul>
                                        <li>Birth State: Birth Certificate or Passport</li>
                                        <li>Current State: Employment Certificate / Employment ID Card or House Rental Document or College ID or Gas / Electricity Bill</li>
                                        <li>Native State: Parents’ Residential Proof documents eg. House / Rent Agreement or Gas Bill or Electricity Bill or Phone Bill or Employment Certificate / Employment ID Card or Birth Certificate or Passport - on either of your parents’ name</li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li><span>Step 3:</span> <span>Sign In with your email ID or Mobile Number</span></li>
                        <li><span>Step 4:</span> <span>Fill in all your credentials, your Instagram handle link & your physical attributes along with your contact details. All fields are mandatory</span></li>
                        <li><span>Step 5:</span> <span>Upload your pictures & necessary documents as mentioned in the first three steps.</span></li>
                        <li><span>Step 6:</span> <span>Once all the fields are completed, click on accept T&Cs</span></li>
                        <li><span>Step 7:</span> <span>Click on Proceed to Payment to subscribe to the Ace Your Pageant course of the Times Grooming school from the House of Miss India. Make a payment of Rs 2999 + taxes.</span></li>
                        <li><span>Step 8:</span> <span>You will receive an automated email upon successful submission of the form</span></li>
                    </ul>
                    <br />
                    <p>Hope you have understood the steps to register.</p>
                    <br />
                    <p>For further clarity, kindly call the helpline numbers between 11 am to 7 pm.<br />
                        Contact: +91 9619937295 / +91 9930771844 or kindly write to us on missindiaorg@timesgroup.com</p>
                    <br /><br />
                    <p>Thank You!</p>
                    <button className="btn gotoform_btn" onClick={() => checkLoginStatus()}>Go to the form</button>
                </div>
            </div>
        </>
    )
}

export default PreLoginRegisterPage