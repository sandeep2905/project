'use client';

import styles from '@/styles/english/HomeBeauty.css';
import styles2 from '@/styles/english/ApplyForm.css';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { eventFormConfig } from '../eventFormConfig';
import LoaderComponent from '@/utilities/LoaderComponent';
import { sendEntryFormEvent } from '../MainForm/FormFunctions';

const EntryFormPaymentSuccess = ({ eventName }) => {
    const router = useRouter();
    const [showPage, setShowPage] = useState(false)

    useEffect(() => {
        let paymentSuccessLocalStorage = localStorage.getItem('payment-success') || '';
        if (paymentSuccessLocalStorage == '1') {
            localStorage.removeItem('payment-success');
            setShowPage(true)
            sendEntryFormEvent('Payment Page', "Payment Success", 0, eventName);
        } else {
            const eventUrl = process.env.NEXT_PUBLIC_BP_SITE_PATH + eventFormConfig[eventName]['url']
            router.replace(eventUrl);
        }
    }, []);

    if (!showPage) {
        return <LoaderComponent />;
    }

    const shareURL = encodeURIComponent(process.env.NEXT_PUBLIC_BP_SITE_PATH + eventFormConfig[eventName]['url']);
    const shareTitle = encodeURIComponent(eventFormConfig[eventName]['title']);

    const twitterURL = "https://twitter.com/intent/tweet?url=" + shareURL + "&text=" + shareTitle + "&related=FeminaIndia&via=FeminaIndia";
    const facebookURL = "https://www.facebook.com/sharer/sharer.php?u=" + shareURL;
    const whatsappURL = `https://api.whatsapp.com/send?text=${shareTitle}%20${shareURL}`;

    return (
        <div className="box_div">
            <div className="success_div">
                <div className="logo_div">
                    <img src={process.env.NEXT_PUBLIC_SITE_PATH + eventFormConfig[eventName]['headerImage']} alt="logo" />
                </div>
                {/* <h4>Congratulations!</h4> */}
                <p>Congratulations on your successful registration for Femina Miss India 2024.</p>
                <p>Kindly keep a close eye on your email inbox and our official social media handles for more updates and information.</p>
                {/* <p>A heartfelt thank you for choosing to be a part of the upcoming Femina Miss India!</p>
                <p>Your registration marks the beginning of a remarkable journey, and we&apos;re here to support you every step of the way. Your beauty, grace, and charisma are sure to make a lasting impression, and we can&apos;t wait to see you light up the stage.</p>
                <p className="wetruly_txt">We truly value the information that you have provided</p> */}
                <p className="share_txt">Share this event</p>
                <ul className="share_ul">
                    <li>
                        <a
                            rel="noopener noreferrer"
                            target="_blank"
                            href={facebookURL}
                            className="facebook"
                            title="Facebook"
                        >
                            <svg className="icon icon-facebook"><use xlinkHref="#icon-facebook"></use></svg>
                        </a>
                    </li>
                    <li>
                        <a
                            rel="noopener noreferrer"
                            target="_blank"
                            href={twitterURL}
                            className="twitter"
                            title="Twitter"
                        >
                            <svg className="icon icon-twitter"><use xlinkHref="#icon-twitter"></use></svg>
                        </a>
                    </li>
                    <li>
                        <a
                            rel="noopener noreferrer"
                            target="_blank"
                            href={whatsappURL}
                            className="whatsapp"
                            title="Whatsapp"
                        >
                            <svg className="icon icon-whatsapp"><use xlinkHref="#icon-whatsapp"></use></svg>
                        </a>
                    </li>
                </ul>
            </div>
            <div className="helpline_div">
                <p>For further clarity, kindly call the helpline numbers between 11 am to 7 pm.<br /> Contact: +91 9619937295 / +91 9930771844 or kindly write to us on missindiaorg@timesgroup.com</p>
            </div>
            <input type="hidden" id="eventName" value={eventName} />
        </div>
    )
}

export default EntryFormPaymentSuccess