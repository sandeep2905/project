import { z } from "zod";
import { calculateAge, checkFileUpload, checkStatePreference, extractParamters, zodRefineDOB, zodRefineFile } from "./FormFunctions";

export type TFormValues = {
    firstName: string;
    middleName: string;
    lastName: string;

    dobDate: string;
    dobMonth: string;
    dobYear: string;
    age: number;

    heightFeet: string;
    heightInch: string;

    mobile: string;
    mobileAlternative: number;
    
    email: string;
    passportOCI: string;
    instagramProfile: string;

    birthState: string;
    currentState: string;
    nativeState: string;

    birthStatePreference: string;
    currentStatePreference: string;
    nativeStatePreference: string;

    // birthStateProofType: string,
    // currentStateProofType: string,
    // nativeStateProofType: string,

    // introductionVideoLink: string;
    // rampWalkVideoLink: string;

    tncCheck: string;

    rToken: string;

    birthStateProof: string,
    currentStateProof: string,
    nativeStateProof: string,
    
    closeUpImg: string,
    fullLengthImg: string,
    midLengthImg: string,
    naturalBeautyImg: string,
};

export const schema = z.object({
    firstName: z.string().trim().min(2, "First name is required").max(30, "First name cannot be more than 30 characters").refine((value) => /^[a-zA-Z0-9]+$/.test(value), 'Please enter proper name'),
    middleName: z.string().trim().max(30, "Middle name cannot be more than 30 characters").refine((value) => /^$|^[a-zA-Z0-9]+$/.test(value), 'Please enter proper name'),
    lastName: z.string().trim().min(1, "Last name is required").max(30, "Last name cannot be more than 30 characters").refine((value) => /^[a-zA-Z0-9]+$/.test(value), 'Please enter proper name'),

    dobDate: z.coerce.number().min(1, "Date is required").gte(1, "Please select correct date").lte(31, "Please select correct date"),
    dobMonth: z.coerce.number().min(1, "Month is required").gte(1, "Please select correct month").lte(12, "Please select correct month"),
    dobYear: z.coerce.number().min(1, "Year is required").superRefine((data, context)=>{calculateAge(z, data, context)}),
    age: z.coerce.number(),

    heightFeet: z.coerce.number().min(1, "Please select height in feet"),
    heightInch: z.coerce.number().min(0, "Please select height in inches"),

    mobile: z.coerce.number({invalid_type_error: "Please enter correct mobile number"}).min(1, 'Please enter mobile number').gte(6000000000, "Invalid mobile number").lte(9999999999, "Invalid mobile number"),
    mobileAlternative: z.number({invalid_type_error: "Please enter correct alternate mobile number"}).gte(6000000000, "Invalid mobile number").lte(9999999999, "Invalid mobile number").optional(),

    email: z.string().trim().min(1, "Email is required").email("Email format is not valid"),

    passportOCI: z.union([z.enum(["1", "0"]), z.null()]).nullable(),

    // instagramProfile: z.string().min(1, "Instagram profile is required").url().refine((value) => /^https:\/\/(www.instagram.com|instagram.com)\/[a-zA-z0-9-_.\/?=&]+$/.test(value), 'Please enter proper Instagram link'),
    instagramProfile: z.string().trim().min(1, "Instagram profile is required"),

    birthState: z.string().min(1, "Please select birth state"),
    currentState: z.string().min(1, "Please select current state"),
    nativeState: z.string().min(1, "Please select native state"),

    birthStatePreference: z.coerce.number().min(1, "Please select preference").superRefine((data, context)=>{checkStatePreference(z, data, context)}),
    currentStatePreference: z.coerce.number().min(1, "Please select preference").superRefine((data, context)=>{checkStatePreference(z, data, context)}),
    nativeStatePreference: z.coerce.number().min(1, "Please select preference").superRefine((data, context)=>{checkStatePreference(z, data, context)}),

    // birthStateProofType: z.string().min(1, "Please select document type"),
    // currentStateProofType: z.string().min(1, "Please select document type"),
    // nativeStateProofType: z.string().min(1, "Please select document type"),

    // introductionVideoLink: z.string().trim().min(1, "Introduction video is required").url(),
    // rampWalkVideoLink: z.string().trim().min(1, "Rampwalk video is required").url(),

    tncCheck: z.boolean().transform(value => value === true).refine((value) => value, "Please accept terms and conditions"),

    rToken: z.string(),

    birthStateProof: zodRefineFile(z, 'file'),
    currentStateProof: zodRefineFile(z, 'file'),
    nativeStateProof: zodRefineFile(z, 'file'),

    closeUpImg: zodRefineFile(z, 'image'),
    fullLengthImg: zodRefineFile(z, 'image'),
    midLengthImg: zodRefineFile(z, 'image'),
    naturalBeautyImg: zodRefineFile(z, 'image'),

}).transform((data)=>{
    data.age = parseInt(extractParamters('age'));
    data.heightInch = parseInt(extractParamters('heightInch'));
    return {
        ...data
    }
// }).refine((data) => data.age >= 18 && data.age <= 25, {
//     message: "Age should be between 18 to 25 years",
//     path: ["age"],
}).refine((data) => data.mobile != data.mobileAlternative, {
    message: "Please enter different mobile number",
    path: ["mobileAlternative"],
}).refine((data) => zodRefineDOB(data), {
    message: "Please enter correct date of birth",
    path: ["dobDate"],
}).superRefine((data, context)=>{
    checkStatePreference(z, data, context);
}).superRefine((data, context)=>{
    checkFileUpload(z, data, context);
// }).superRefine((data, context)=>{
//     calculateAge(z, data, context);
})
;