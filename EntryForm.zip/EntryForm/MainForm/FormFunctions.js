import apiCall from "@/utilities/apiCall";
import { trackEvent } from "@/utilities";
import { eventFormConfig } from "../eventFormConfig";

// Start - Function used in FormZodSchema.ts
export const zodRefineFile = (z, type = 'image') => {
    const MAX_SIZE = 5000000;       // 5 MB
    let ALLOWED_TYPE = []
    if (type == 'file') {
        ALLOWED_TYPE = ['image/jpeg', 'image.jpg', 'application/pdf'];
    } else {
        ALLOWED_TYPE = ['image/png', 'image/jpeg', 'image.jpg'];
    }

    return z.any()
        .refine((files) => files?.length == 1, "Please upload file")
        .refine((files) => files?.[0]?.size <= MAX_SIZE, `File size cannot be above ${MAX_SIZE / 1000 / 1000} MB`)
        .refine((files) => ALLOWED_TYPE.includes(files?.[0]?.type), "Invalid file type")
}

export const zodRefineDOB = (date) => {
    const dobDate = date.dobDate || '';
    const dobMonth = date.dobMonth || '';
    const dobYear = date.dobYear || '';

    if (dobDate === '' || dobMonth === '' || dobYear === '') {  // This is returned inorder to avoid showing zod error when any dates are not selected
        return true;
    } else {
        const custDate = new Date(`${dobYear}/${dobMonth}/${dobDate}`)
        if (custDate.getFullYear() == dobYear && custDate.getMonth() == dobMonth - 1 && custDate.getDate() == dobDate) {
            calculateAge();
            return true;
        }
        return false;
    }
    return false;
}

// This is used in FormZodSchema, some of the parameters changes via javascript 
// like age, inches dropdown is unable to detect by zod, so it needs to be updated 
// by using z.transform function
export const extractParamters = (id) => {
    if (document.getElementById(`${id}`)) {
        return document.getElementById(`${id}`).value;
    }
    return;
}

// End - Function used in FormZodSchema.ts


export const createOptionTag = (start, end) => {
    const results = []
    for (let i = start; i <= end; i++) {
        results.push(<option key={start + end + i} value={i}>{i}</option>);
    }
    return results;
}

export const createStateOptionTag = () => {
    const stateListArray = [
        'Andhra Pradesh',
        'Arunachal Pradesh',
        'Assam',
        'Bihar',
        'Chhattisgarh',
        'Goa',
        'Gujarat',
        'Haryana',
        'Himachal Pradesh',
        'Jharkhand',
        'Karnataka',
        'Kerala',
        'Madhya Pradesh',
        'Maharashtra',
        'Manipur',
        'Meghalaya',
        'Mizoram',
        'Nagaland',
        'Odisha',
        'Punjab',
        'Rajasthan',
        'Sikkim',
        'Tamil Nadu',
        'Telangana',
        'Tripura',
        'Uttar Pradesh',
        'Uttarakhand',
        'West Bengal',
        'Andaman And Nicobar Islands (UT)',
        'Chandigarh (UT)',
        'Dadra Nagar And Haveli & Daman And Diu (UT)',
        'Delhi (UT)',
        'Jammu And Kashmir (UT)',
        'Ladakh (UT)',
        'Lakshwadeep (UT)',
        'Puducherry (UT)'
    ]

    const results = []
    stateListArray.map((value) => {
        results.push(<option key={value} value={value}>{value}</option>);
    })
    return results;

}

export const createOptionYearTag = (eventName) => {
    const ageCriteria = eventFormConfig[eventName]['ageCriteria']
    const ageCriteriaYear = ageCriteria.getFullYear();
    const currentYear = new Date().getFullYear();
    const diff = ageCriteriaYear - currentYear;
    const diffYear = (diff < 0) ? 0 : diff;
    const minYear = ageCriteriaYear - 25 - (0);
    const maxYear = ageCriteriaYear - 18 - (0);
    // const minYear = currentYear - 25;
    // const maxYear = currentYear - 18;

    const results = [];
    for (let i = minYear; i <= maxYear; i++) {
        results.push(<option key={minYear + maxYear + i} value={i}>{i}</option>);
    }
    return results;
}

export const calculateAge = (z, data, context) => {
    const eventName = document.getElementById('eventName').value || "MissIndia";
    const date = document.getElementById('dobDate').value
    const month = document.getElementById('dobMonth').value
    const year = document.getElementById('dobYear').value

    if (date === '' || month === '' || year === '') {  // This is returned inorder to avoid showing zod error when any dates are not selected
        return true;
    } else {
        const birthDate = new Date(`${year}/${month}/${date}`)
        // const currentDate = new Date();
        const currentDate = eventFormConfig[eventName]['ageCriteria']
        const timeDifference = currentDate - birthDate;
        const ageInMilliseconds = new Date(timeDifference);
        const age = ageInMilliseconds.getUTCFullYear() - 1970;
        document.getElementById('age').value = age;

        if (age < 18 || age > 25) {
            if (context == null) {
                return age;
            } else {
                return context.addIssue({
                    code: z.ZodIssueCode.custom,
                    message: "Age should be between 18 to 25 years",
                    // path: ["age"]
                });
            }
        } else {
            return age;
        }
    }
}

export const checkHeightValue = () => {
    const heightFeet = Number(document.getElementById('heightFeet').value)

    if (heightFeet === 5) {
        // document.getElementById("heightInch").querySelectorAll("option").forEach(function (option) {
        //     option.removeAttribute("selected");
        // });

        // document.getElementById("heightInch").querySelector("option[value='0']").style.display = "none";
        // document.getElementById("heightInch").querySelector("option[value='1']").style.display = "none";
        // document.getElementById("heightInch").querySelector("option[value='2']").style.display = "none";

        // document.getElementById("heightInch").querySelector("option[value='0']").disabled = true;
        // document.getElementById("heightInch").querySelector("option[value='1']").disabled = true;
        // document.getElementById("heightInch").querySelector("option[value='2']").disabled = true;

        document.getElementById("heightInch").innerHTML = "";
        for (var inch = 3; inch <= 11; inch++) {
            document.getElementById("heightInch").add(new Option(inch, inch));
        }

        document.getElementById("heightInch").querySelector("option[value='3']").setAttribute('selected', 'selected');
        document.getElementById("heightInch").value = 3
    } else {
        // document.getElementById("heightInch").querySelectorAll("option").forEach(function (option) {
        //     option.removeAttribute("selected");
        // });

        // document.getElementById("heightInch").querySelector("option[value='0']").style.display = "block";
        // document.getElementById("heightInch").querySelector("option[value='1']").style.display = "block";
        // document.getElementById("heightInch").querySelector("option[value='2']").style.display = "block";

        // document.getElementById("heightInch").querySelector("option[value='0']").disabled = false;
        // document.getElementById("heightInch").querySelector("option[value='1']").disabled = false;
        // document.getElementById("heightInch").querySelector("option[value='2']").disabled = false;

        document.getElementById("heightInch").innerHTML = "";
        for (var inch = 0; inch <= 11; inch++) {
            document.getElementById("heightInch").add(new Option(inch, inch));
        }

        document.getElementById("heightInch").querySelector("option[value='0']").setAttribute('selected', 'selected');
        document.getElementById("heightInch").value = 0
    }
}

export const generateReCaptchaToken = () => {
    grecaptcha.enterprise.ready(async () => {
        const token = await grecaptcha.enterprise.execute(process.env.NEXT_PUBLIC_RECAPTCHA_SITEKEY, { action: 'FORM_SUBMIT' });
        document.getElementById("rToken").value = token;
        return token;
    });
}


export const checkFileInput = (data, type = 'image') => {
    const MAX_SIZE = 5000000;       // 5 MB
    let ALLOWED_TYPE = []
    if (type == 'file') {
        ALLOWED_TYPE = ['image/jpeg', 'image/jpg', 'application/pdf'];
    } else {
        ALLOWED_TYPE = ['image/png', 'image/jpeg', 'image/jpg'];
    }
    if (data.target.files.length) {
        const fileInput = data.target.files[0];
        const inputId = data.target.id;
        const fileSize = fileInput.size;
        const fileType = fileInput.type;
        document.getElementById(inputId + 'Div').style.display = 'none';
        if (fileSize > MAX_SIZE) {
            // alert(`File size cannot be above ${MAX_SIZE / 1000 / 1000} MB`);
            // document.getElementById(inputId).value = "";
        } else if (!ALLOWED_TYPE.includes(fileType)) {
            // alert(`Invalid file type`);
            // document.getElementById(inputId).value = "";
        } else {
            document.getElementById(inputId + 'FileName').innerText = fileInput.name;
            document.getElementById(inputId + 'Div').style.display = 'block';
            document.getElementById(inputId + 'ReferenceText').style.display = 'none';
            if (type == 'image') document.getElementById(inputId + 'Preview').src = URL.createObjectURL(fileInput);
            sendFileToServer(data, type);
        }
    } else {
        clearImage(data.target.id, type)
    }
}

const sendFileToServer = async (data, type = 'image') => {
    document.getElementById("loader_div").style.display = 'flex';
    const inputId = data.target.id;
    const fileInput = data.target.files[0];

    const formData = new FormData();
    formData.append('file', fileInput);
    formData.append('fileType', inputId);

    const tempImagesUrl = process.env.NEXT_PUBLIC_ROOT_API + 'beauty_pageants/v1/submit_temp_images'
    const options = {
        method: "POST",
        body: formData,
        body_type: 'form_data'
    };

    const jsonResponse = await apiCall(tempImagesUrl, options);

    document.getElementById("loader_div").style.display = 'none';
    if (typeof jsonResponse.response != 'undefined' && jsonResponse.response.response_code == "200") {
        document.getElementById(inputId + 'Error').innerText = "";
        document.getElementById(inputId + 'HiddenPath').value = jsonResponse.response_content.image_name;
        sendEntryFormEvent('success_file_upload_api_response', 'Success');
    } else {
        clearImage(inputId, type);
        const message = jsonResponse.response?.response_message.file || "Please try again later";
        document.getElementById(inputId + 'Error').innerText = message;
        sendEntryFormEvent('failure_file_upload_api_response', message);
    }
}

export const clearImage = (inputId, type = 'image') => {
    // const inputId = data.target.id;
    document.getElementById(inputId).value = "";
    document.getElementById(inputId + 'FileName').innerText = "";
    document.getElementById(inputId + 'Div').style.display = "none";
    document.getElementById(inputId + 'ReferenceText').style.display = 'block';
    document.getElementById(inputId + 'HiddenPath').value = "";
    if (type == 'image') {
        document.getElementById(inputId + 'Preview').src = document.getElementById(inputId + 'Preview').getAttribute('data-default-src')
    }
}


export const checkStatePreference = (z, data, context) => {
    if (typeof data === 'object') {
        if (data.birthStatePreference == data.currentStatePreference || data.birthStatePreference == data.nativeStatePreference) {
            return context.addIssue({
                code: z.ZodIssueCode.custom,
                message: "Preferred state cannot be same",
                path: ["birthStatePreference"]
            });
        } else if (data.currentStatePreference == data.nativeStatePreference) {
            return context.addIssue({
                code: z.ZodIssueCode.custom,
                message: "Preferred state cannot be same",
                path: ["currentStatePreference"]
            });
        }
    } else {
        const selectElements = document.querySelectorAll('.unique-select');
        let isDuplicate = '';
        selectElements.forEach(() => {
            const selectedValues = Array.from(selectElements, (el) => el.value);
            isDuplicate = selectedValues.some((value, i) => {
                if (value != '') {
                    return selectedValues.indexOf(value) !== i
                }
            });
        });
        if (isDuplicate) {
            return context.addIssue({
                code: z.ZodIssueCode.custom,
                message: "Preferred state cannot be same",
            });
        }
    }
}

export const checkFileUpload = (z, data, context) => {
    const fileId = ['birthStateProof', 'currentStateProof', 'nativeStateProof', 'closeUpImg', 'fullLengthImg', 'midLengthImg', 'naturalBeautyImg']
    fileId.map((divId) => {
        const hiddenPath = document.getElementById(divId + 'HiddenPath').value;
        if (hiddenPath == '') {
            return context.addIssue({
                code: z.ZodIssueCode.custom,
                message: "Please upload file",
                path: [divId]
            });
        }
    })
}

export const openTab = (id, type) => {
    if (type == 'toggle') {
        document.getElementById(`btn-${id}`).classList.toggle('active');
    } else {
        document.getElementById(`btn-${id}`).classList.add('active');
        // document.getElementById(`btn-${id}`).scrollIntoView();
    }
}

export const showActiveErrorTab = (errors) => {
    const tab1 = [];
    const tab2 = ['firstName', 'middleName', 'lastName', 'dobDate', 'dobMonth', 'dobYear', 'age', 'heightFeet', 'heightInch', 'mobile', 'mobileAlternative', 'email', 'passportOCI', 'instagramProfile'];
    const tab3 = ['birthState', 'currentState', 'nativeState', 'birthStatePreference', 'currentStatePreference', 'nativeStatePreference', 'birthStateProof', 'currentStateProof', 'nativeStateProof', 'birthStateProofType', 'currentStateProofType', 'nativeStateProofType'];
    const tab4 = ['introductionVideoLink', 'rampWalkVideoLink', 'tncCheck'];

    tab4.some((value) => {
        if (value in errors) {
            openTab(4);
            return true;
        }
        // return false;
    });
    tab3.some((value) => {
        if (value in errors) {
            openTab(3);
            return true;
        }
        // return false;
    });
    tab2.some((value) => {
        if (value in errors) {
            openTab(2);
            return true;
        }
        // return false;
    });
}

export const allowedUTMParams = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term'];

export const extractUTMParams = () => {
    const currentUrl = new URL(window.location.href);
    const urlParams = new URLSearchParams(currentUrl.search);

    allowedUTMParams.map((value) => {
        let urlValue = urlParams.get(`${value}`) || '';
        urlValue != '' ? localStorage.setItem(`${value}`, urlValue) : '';
    })
}

export const togglePopup = (id) => {
    document.getElementById(id).classList.toggle('show');
}


export const showPreviewImage = (divId) => {
    const divIdDom = document.getElementById(`${divId}Preview`);
    document.getElementById('imagepreview_img_tag').src = '';
    document.getElementById('imagepreview_h2').innerText = '';

    const divImgId = divIdDom.getAttribute('data-img-id');
    const imgPresent = document.getElementById(divImgId).value;
    if (imgPresent == '') {
        document.getElementById('imagepreview_img_tag').src = divIdDom.getAttribute('data-full-length-src');
        document.getElementById('imagepreview_h2').innerText = divIdDom.getAttribute('data-img-h2');
    } else {
        document.getElementById('imagepreview_img_tag').src = divIdDom.src;
        document.getElementById('imagepreview_h2').innerText = divIdDom.getAttribute('data-img-h2');
    }

    if (imgPresent == "" && divIdDom.getAttribute('data-full-length-src') == "") {
        // 10 Jan 2024 - This condition is required since preview image of Natural Beauty Shot (no make-up) was removed.
        // Only Preview of user uploaded image is allowed.
        return;
    }
    togglePopup('imagepreview_div')

}

export const checkPaymentGatewayUrl = (url) => {
    const eventName = document.getElementById('eventName').value || "MissIndia";
    if (url.includes(eventFormConfig[eventName]['paymentGatewayDomain'])) {
        return true;
    }
    return false;
}

export const sendEntryFormEvent = (action = 'click', label = 'label', value = 0, event = 'MissIndia') => {
    const eventName = event || document.getElementById('eventName').value;
    const trackGA4CategoryName = eventFormConfig[eventName]['trackGA4CategoryName']

    trackEvent('send', 'event', trackGA4CategoryName, action, label, value);
}