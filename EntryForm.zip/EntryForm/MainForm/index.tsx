'use client';

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { TFormValues, schema } from "./FormZodSchema";
import { checkFileInput, checkHeightValue, checkStatePreference, clearImage, createOptionTag, createOptionYearTag, createStateOptionTag, openTab, showActiveErrorTab, showPreviewImage, togglePopup } from "./FormFunctions";

import { DevTool } from "@hookform/devtools";
import { preSubmit } from "./FormZodFunctions";
import GoogleReCaptcha from '@/components/english/ThirdPartyScripts/GoogleReCaptcha';
import { useEffect } from "react";
import { eventFormConfig } from "../eventFormConfig";

const MainFormIndex = ({ eventName }) => {
    const ageCriteriaDateFormat = eventFormConfig[eventName]['ageCriteria'].toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });

    const { register, handleSubmit, formState: { errors }, control } = useForm<TFormValues>({
        mode: "all",
        resolver: zodResolver(schema),
    });

    useEffect(() => {
        if (/webOS|iPhone|iPad|iPod|Mac/i.test(navigator.userAgent)) {
            document.body.classList.toggle('body_ios');
        }
    }, []);

    useEffect(() => {
        const errorLength = Object.keys(errors).length;
        if (errorLength) {
            showActiveErrorTab(errors)
        }
    }, [errors])


    return (
        <>
            <form autoComplete="off" onSubmit={handleSubmit(preSubmit)}>
                <input type="hidden" id="eventName" value={eventName} />
                <div className="set">
                    <span className="tab_head" onClick={() => openTab(2, 'toggle')} id="btn-2" data-tab-id="2">
                        <span className="num_txt">2</span> <span className="head_txt">Personal Credentials</span>
                    </span>
                    <div className="content">
                        <h4>Your Name*</h4>
                        <div className="form_row">

                            <div className="form_div">
                                <input
                                    type="text"
                                    placeholder="First Name*"
                                    id="firstName"
                                    className={errors.firstName?.message ? 'error' : ''}
                                    {...register("firstName")}
                                />
                                <p className="error" id="firstNameError">{errors.firstName?.message}</p>
                            </div>

                            <div className="form_div">
                                <input
                                    type="text"
                                    placeholder="Middle Name"
                                    id="middleName"
                                    className={errors.middleName?.message ? 'error' : ''}
                                    {...register("middleName")}
                                />
                                <p className="error" id="middleNameError">{errors.middleName?.message}</p>
                            </div>

                            <div className="form_div">
                                <input
                                    type="text"
                                    placeholder="Last Name*"
                                    id="lastName"
                                    className={errors.lastName?.message ? 'error' : ''}
                                    {...register("lastName")}
                                />
                                <p className="error" id="lastNameError">{errors.lastName?.message}</p>
                            </div>

                        </div>

                        <div className="form_row">

                            <div className="form_div dob_div">
                                <label>Date of Birth*</label>

                                <select
                                    id="dobDate"
                                    defaultValue=""
                                    className={errors.dobDate?.message ? 'error' : ''}
                                    {...register("dobDate")}
                                >
                                    <option value="" disabled>Date</option>
                                    {createOptionTag(1, 31)}
                                </select>
                                <p className="error" id="dobDateError">{errors.dobDate?.message}</p>

                                <select
                                    id="dobMonth"
                                    defaultValue=""
                                    className={errors.dobMonth?.message ? 'error' : ''}
                                    {...register("dobMonth")}
                                >
                                    <option value="" disabled>Month</option>
                                    <option value="1">Jan</option>
                                    <option value="2">Feb</option>
                                    <option value="3">Mar</option>
                                    <option value="4">Apr</option>
                                    <option value="5">May</option>
                                    <option value="6">Jun</option>
                                    <option value="7">Jul</option>
                                    <option value="8">Aug</option>
                                    <option value="9">Sep</option>
                                    <option value="10">Oct</option>
                                    <option value="11">Nov</option>
                                    <option value="12">Dec</option>
                                </select>
                                <p className="error" id="dobMonthError">{errors.dobMonth?.message}</p>

                                <select
                                    id="dobYear"
                                    defaultValue=""
                                    className={errors.dobYear?.message ? 'error' : ''}
                                    {...register("dobYear")}
                                >
                                    <option value="" disabled>Year</option>
                                    {createOptionYearTag(eventName)}
                                </select>
                                <p
                                    className={"error " + (errors.dobYear?.type == 'custom' ? 'error-custom' : '')}
                                    id="dobYearError"
                                >{errors.dobYear?.message}</p>

                            </div>

                            <div className="form_div">
                                <label>Age* (on {ageCriteriaDateFormat})</label>
                                <input
                                    type="number"
                                    placeholder="Age*"
                                    id="age"
                                    className={errors.age?.message ? 'error' : ''}
                                    readOnly={true}
                                    {...register("age")}
                                />
                                <p className="error" id="ageError">{errors.age?.message}</p>
                            </div>

                            <div className="form_div height_div">
                                <label>Height*</label>
                                <select
                                    id="heightFeet"
                                    defaultValue=""
                                    className={errors.heightFeet?.message ? 'error' : ''}
                                    {...register("heightFeet", {
                                        onChange: () => { checkHeightValue() }
                                    })}
                                >
                                    <option value="" disabled>Feet</option>
                                    {createOptionTag(5, 6)}
                                </select>
                                <p
                                    id="heightFeetError"
                                    className={"error error-custom"}
                                >
                                    {errors.heightFeet?.message}
                                </p>

                                <select
                                    id="heightInch"
                                    defaultValue=""
                                    className={errors.heightInch?.message ? 'error' : ''}
                                    {...register("heightInch")}
                                >
                                    <option value="" disabled>Inches</option>
                                    {createOptionTag(0, 11)}
                                </select>
                                <p className="error" id="heightInchError">{errors.heightInch?.message}</p>

                            </div>

                        </div>
                        {/* <h4 className='contdetails_txt'>Contact Details*</h4> */}
                        <div className="form_row contdetail_row">

                            <div className="form_div">
                                <label>Contact Details*</label>
                                <input
                                    type="tel"
                                    placeholder="Mobile No.*"
                                    id="mobile"
                                    className={errors.mobile?.message ? 'error' : ''}
                                    {...register("mobile")}
                                />
                                <p className="error" id="mobileError">{errors.mobile?.message}</p>
                            </div>

                            <div className="form_div">
                                <label>&nbsp;</label>
                                <input
                                    type="tel"
                                    placeholder="Mobile No. (Alternate)"
                                    id="mobileAlternative"
                                    className={errors.mobileAlternative?.message ? 'error' : ''}
                                    {...register("mobileAlternative", {
                                        setValueAs: (v) => v === "" ? undefined : parseInt(v, 10),
                                    })}
                                />
                                <p className="error" id="mobileAlternativeError">{errors.mobileAlternative?.message}</p>
                            </div>

                            <div className="form_div">
                                <label>Email*<span className="info">i <span className="info_txt">You will receive the Grooming School credentials on the same email id, please type your email id properly.</span></span></label>
                                <input
                                    type="email"
                                    placeholder="Email*"
                                    id="email"
                                    className={errors.email?.message ? 'error' : ''}
                                    {...register("email")}
                                />
                                <p className="error" id="emailError">{errors.email?.message}</p>
                            </div>

                        </div>
                        <div className="form_row radbtn_row">

                            <div className="form_div">
                                <label>Passport Details*<span className="info">i <span className="info_txt">Citizenship details</span></span></label>
                                <div>
                                    <input
                                        type="radio"
                                        id="ip"
                                        value="0"
                                        defaultChecked={true}
                                        {...register("passportOCI")}
                                    />
                                    <label htmlFor="ip">Indian Passport</label>&nbsp;&nbsp;&nbsp;
                                    <input
                                        type="radio"
                                        id="oci"
                                        value="1"
                                        {...register("passportOCI")}
                                    />
                                    <label htmlFor="oci">OCI</label>
                                </div>
                            </div>
                        </div>

                        <div className="form_row radbtn_row">
                            <div className="form_div">
                                <label>Instagram Profile*</label>
                                <input
                                    type="text"
                                    placeholder="Instagram Profile*"
                                    id="instagramProfile"
                                    className={errors.instagramProfile?.message ? 'error' : ''}
                                    {...register("instagramProfile")}
                                />
                                <p className="error" id="instagramProfileError">{errors.instagramProfile?.message}</p>
                            </div>
                        </div>

                        <div className="cont_btndiv">
                            <span className="cont_btn" onClick={() => openTab(3)} data-id="btn-3">Continue</span>
                        </div>

                    </div>
                </div>
                <div className="set">
                    <span className="tab_head" onClick={() => openTab(3, 'toggle')} id="btn-3" data-tab-id="3">
                        <span className="num_txt">3</span> <span className="head_txt">Other Details </span>
                    </span>
                    <div className="content">
                        <div className="form_row form_row2">
                            <p>Please note (There will be only one representative from the UTs marked as (UT) in the drop down)</p>

                            <div className="form_div">
                                <div className="fw_div">
                                    <label>Birth State / UT*<span className="info">i <span className="info_txt">where a participant is born</span></span></label>
                                    <select
                                        id="birthState"
                                        className={errors.birthState?.message ? 'fw error' : 'fw'}
                                        defaultValue=""
                                        {...register("birthState")}
                                    >
                                        <option value="" disabled>Birth State / UT</option>
                                        {createStateOptionTag()}
                                    </select>
                                    <p className="error" id="birthStateError">{errors.birthState?.message}</p>
                                </div>

                                <div className="audstate_div">
                                    <select
                                        id="birthStatePreference"
                                        className={errors.birthStatePreference?.message ? 'unique-select error' : 'unique-select'}
                                        defaultValue=""
                                        {...register("birthStatePreference", {
                                            // onChange: (e) => { checkStatePreference(e) }
                                            deps: ['currentStatePreference', 'nativeStatePreference']
                                        })}
                                    >
                                        <option value="" disabled>Select</option>
                                        {createOptionTag(1, 3)}
                                    </select>
                                    <p className="error" id="birthStatePreferenceError">{errors.birthStatePreference?.message}</p>
                                    <span>In order of preference of your audition state / UT*</span>
                                </div>
                            </div>

                            <div className="form_div">
                                <div className="fw_div">
                                    <label>Current State / UT*<span className="info">i <span className="info_txt">where a participant is currently residing/studying/employed</span></span></label>
                                    <select
                                        id="currentState"
                                        className={errors.currentState?.message ? 'fw error' : 'fw'}
                                        defaultValue=""
                                        {...register("currentState")}
                                    >
                                        <option value="">Current State / UT</option>
                                        {createStateOptionTag()}
                                    </select>
                                    <p className="error" id="currentStateError">{errors.currentState?.message}</p>
                                </div>
                                <div className="audstate_div">
                                    <select
                                        id="currentStatePreference"
                                        className={errors.currentStatePreference?.message ? 'unique-select error' : 'unique-select'}
                                        defaultValue=""
                                        {...register("currentStatePreference", {
                                            // onChange: (e) => { checkStatePreference(e) }
                                            deps: ['birthStatePreference', 'nativeStatePreference']
                                        })}
                                    >
                                        <option value="" disabled>Select</option>
                                        {createOptionTag(1, 3)}
                                    </select>
                                    <p className="error" id="currentStatePreferenceError">{errors.currentStatePreference?.message}</p>
                                    <span>In order of preference of your audition state / UT*</span>
                                </div>
                            </div>

                            <div className="form_div">
                                <div className="fw_div nativstate_div">
                                    <label>Native State(Parents Birth State) / UT*<span className="info">i <span className="info_txt">either of the participant’s parent’s birthplace</span></span></label>
                                    <select
                                        id="nativeState"
                                        className={errors.nativeState?.message ? 'fw error' : 'fw'}
                                        defaultValue=""
                                        {...register("nativeState")}
                                    >
                                        <option value="" disabled>Native State / UT</option>
                                        {createStateOptionTag()}
                                    </select>
                                    <p className="error" id="nativeStateError">{errors.nativeState?.message}</p>
                                </div>
                                <div className="audstate_div">
                                    <select
                                        id="nativeStatePreference"
                                        className={errors.nativeStatePreference?.message ? 'unique-select error' : 'unique-select'}
                                        defaultValue=""
                                        {...register("nativeStatePreference", {
                                            // onChange: (e) => { checkStatePreference(e) }
                                            deps: ['birthStatePreference', 'currentStatePreference']
                                        })}
                                    >
                                        <option value="" disabled>Select</option>
                                        {createOptionTag(1, 3)}
                                    </select>
                                    <p className="error" id="nativeStatePreferenceError">{errors.nativeStatePreference?.message}</p>
                                    <span>In order of preference of your audition state / UT*</span>
                                </div>
                            </div>

                        </div>
                        <div className="form_row upldoc_row">

                            <div className="form_div">
                                <label>Upload Your Documents</label>
                                <p>Format: JPG, JPEG & PDF of front & back of all the scanned documents | Max Size: 5 MB</p>
                                <div className='upldoc_div'>
                                    <span className='filetype_txt'>Birth State proof*</span>
                                    <div className="upload-btn-wrapper">
                                        <button className="btn">Upload File</button>
                                        <input
                                            type="file"
                                            id="birthStateProof"
                                            className={errors.birthStateProof?.message ? 'error' : ''}
                                            accept="image/jpeg, image.jpg, application/pdf"
                                            data-allowed-size="5000000"
                                            {...register("birthStateProof", {
                                                onChange: (e) => checkFileInput(e, 'file')
                                            })}
                                        />
                                        <input type="hidden" id="birthStateProofHiddenPath" />
                                        <p id="birthStateProofReferenceText"></p>
                                    </div>

                                    <div className="filename_div" id="birthStateProofDiv" style={{ display: "none" }}>
                                        <span className='filename_txt' id="birthStateProofFileName"></span>
                                        <span className='cancel_icon' onClick={() => clearImage('birthStateProof', 'file')}>x</span>
                                    </div>
                                    <p className="error" id="birthStateProofError">{errors.birthStateProof?.message}</p>

                                    {/* <div className="drpdwn_div">
                                        <select
                                            id="birthStateProofType"
                                            className={errors.birthStateProofType?.message ? 'error' : ''}
                                            defaultValue=""
                                            {...register("birthStateProofType")}
                                        >
                                            <option value="" disabled>Birth State Proof Type</option>
                                            <option value="passport">Passport</option>
                                            <option value="birth_certificate">Birth Certificate</option>
                                        </select>
                                        <p className="error" id="birthStateProofTypeError">{errors.birthStateProofType?.message}</p>
                                    </div> */}

                                </div>
                                <div className='upldoc_div'>
                                    <span className='filetype_txt'>Current State proof*</span>
                                    <div className="upload-btn-wrapper">
                                        <button className="btn">Upload File</button>
                                        <input
                                            type="file"
                                            id="currentStateProof"
                                            className={errors.currentStateProof?.message ? 'error' : ''}
                                            accept="image/jpeg, image.jpg, application/pdf"
                                            data-allowed-size="5000000"
                                            {...register("currentStateProof", {
                                                onChange: (e) => checkFileInput(e, 'file')
                                            })}
                                        />
                                        <input type="hidden" id="currentStateProofHiddenPath" />
                                        <p id="currentStateProofReferenceText"></p>
                                    </div>

                                    <div className="filename_div" id="currentStateProofDiv" style={{ display: "none" }}>
                                        <span className='filename_txt' id="currentStateProofFileName"></span>
                                        <span className='cancel_icon' onClick={() => clearImage('currentStateProof', 'file')}>x</span>
                                    </div>
                                    <p className="error" id="currentStateProofError">{errors.currentStateProof?.message}</p>

                                    {/* <div className="drpdwn_div">
                                        <select
                                            id="currentStateProofType"
                                            className={errors.currentStateProofType?.message ? 'error' : ''}
                                            defaultValue=""
                                            {...register("currentStateProofType")}
                                        >
                                            <option value="" disabled>Current State Proof Type</option>
                                            <option value="aadhar">Aadhar Card</option>
                                            <option value="rental_agreement">Rental Agreement</option>
                                            <option value="electricity_bill">Electricity Bill</option>
                                            <option value="gas_bill">Gas Bill</option>
                                            <option value="student_id">Student ID</option>
                                            <option value="employment_id">Employment ID</option>
                                        </select>
                                        <p className="error" id="currentStateProofTypeError">{errors.currentStateProofType?.message}</p>
                                    </div> */}

                                </div>
                                <div className='upldoc_div'>
                                    <span className='filetype_txt'>Native State proof* (Birth State of parents)</span>
                                    <div className="upload-btn-wrapper">
                                        <button className="btn">Upload File</button>
                                        <input
                                            type="file"
                                            id="nativeStateProof"
                                            className={errors.nativeStateProof?.message ? 'error' : ''}
                                            accept="image/jpeg, image.jpg, application/pdf"
                                            data-allowed-size="5000000"
                                            {...register("nativeStateProof", {
                                                onChange: (e) => checkFileInput(e, 'file')
                                            })}
                                        />
                                        <input type="hidden" id="nativeStateProofHiddenPath" />
                                        <p id="nativeStateProofReferenceText"></p>
                                    </div>

                                    <div className="filename_div" id="nativeStateProofDiv" style={{ display: "none" }}>
                                        <span className='filename_txt' id="nativeStateProofFileName"></span>
                                        <span className='cancel_icon' onClick={() => clearImage('nativeStateProof', 'file')}>x</span>
                                    </div>
                                    <p className="error" id="nativeStateProofError">{errors.nativeStateProof?.message}</p>

                                    {/* <div className="drpdwn_div">
                                        <select
                                            id="nativeStateProofType"
                                            className={errors.nativeStateProofType?.message ? 'error' : ''}
                                            defaultValue=""
                                            {...register("nativeStateProofType")}
                                        >
                                            <option value="" disabled>Native State Proof Type</option>
                                            <option value="parents_birth_certificate">Parents Birth Certificate</option>
                                            <option value="parents_aadhar">Parents Aadhar Card</option>
                                            <option value="parents_passport">Parents Passport</option>
                                            <option value="parents_rent_agreement">Parents Rent Agreement</option>
                                            <option value="parents_employment_id">Parents Employment ID</option>
                                        </select>
                                        <p className="error" id="nativeStateProofTypeError">{errors.nativeStateProofType?.message}</p>
                                    </div> */}

                                </div>
                            </div>

                        </div>
                        <div className="cont_btndiv">
                            <span className="cont_btn" onClick={() => openTab(4)} data-id="btn-4">Continue</span>
                        </div>
                    </div>
                </div>
                <div className="set">
                    <span className="tab_head" onClick={() => openTab(4, 'toggle')} id="btn-4" data-tab-id="4">
                        <span className="num_txt">4</span> <span className="head_txt">Upload Photos </span>
                    </span>
                    <div className="content">
                        <div className="form_row upldoc_row profile_row">
                            <div className="form_div fw">
                                <label>Upload Your Photos*<span className="info">i <span className="info_txt">With the reference picture of the specific picture on each tab.</span></span></label>
                                {/* <p>Format: PNG, JPG and JPEG | Dimension: 450px X 600px | Max Size: 5 MB</p> */}
                                <p>Format: PNG, JPG and JPEG | Max Size: 5 MB</p>
                            </div>
                            <div className="form_div">
                                <div className='upldoc_div'>
                                    <span className='filetype_txt'>Close Up*</span>
                                    <div className="upload-btn-wrapper">
                                        <button className="btn">Add photo</button>
                                        <input
                                            type="file"
                                            id="closeUpImg"
                                            className={errors.closeUpImg?.message ? 'error' : ''}
                                            accept="image/png, image/jpeg, image.jpg"
                                            data-allowed-size="5000000"
                                            {...register("closeUpImg", {
                                                onChange: (e) => checkFileInput(e, 'image')
                                            })}
                                        />
                                        <input type="hidden" id="closeUpImgHiddenPath" />
                                        <div className="filename_div" id="closeUpImgDiv" style={{ display: "none" }}>
                                            <span className='filename_txt' id="closeUpImgFileName"></span>
                                            <span className='cancel_icon' onClick={() => clearImage('closeUpImg')}>x</span>
                                        </div>
                                    </div>
                                    <p className="error" id="closeUpImgError">{errors.closeUpImg?.message}</p>
                                    <div className="img_div" onClick={() => showPreviewImage('closeUpImg')}>
                                        <img
                                            src={"/assets/img/closeup.jpg" + eventFormConfig[eventName]["imgVersion"]}
                                            data-img-id="closeUpImg"
                                            data-img-h2="Close Up"
                                            data-default-src={"/assets/img/closeup.jpg" + eventFormConfig[eventName]["imgVersion"]}
                                            data-full-length-src={"/assets/img/closeup-big.jpg" + eventFormConfig[eventName]["imgVersion"]}
                                            alt="photo"
                                            id="closeUpImgPreview"
                                        />
                                        <p id="closeUpImgReferenceText">Reference Image</p>
                                        <img
                                            src={"/assets/img/fullscreen.png"}
                                            className="icon_img"
                                            alt="icon"
                                        />
                                    </div>
                                </div>
                            </div>
                            <div className="form_div">
                                <div className='upldoc_div upldoc_diveven'>
                                    <span className='filetype_txt'>Full Length*</span>
                                    <div className="upload-btn-wrapper">
                                        <button className="btn">Add photo</button>
                                        <input
                                            type="file"
                                            id="fullLengthImg"
                                            className={errors.fullLengthImg?.message ? 'error' : ''}
                                            accept="image/png, image/jpeg, image.jpg"
                                            data-allowed-size="5000000"
                                            {...register("fullLengthImg", {
                                                onChange: (e) => checkFileInput(e, 'image')
                                            })}
                                        />
                                        <input type="hidden" id="fullLengthImgHiddenPath" />
                                        <div className="filename_div" id="fullLengthImgDiv" style={{ display: "none" }}>
                                            <span className='filename_txt' id="fullLengthImgFileName"></span>
                                            <span className='cancel_icon' onClick={() => clearImage('fullLengthImg')}>x</span>
                                        </div>
                                    </div>
                                    <p className="error" id="fullLengthImgError">{errors.fullLengthImg?.message}</p>
                                    <div className="img_div" onClick={() => showPreviewImage('fullLengthImg')}>
                                        <img
                                            src={"/assets/img/full-length.jpg" + eventFormConfig[eventName]["imgVersion"]}
                                            data-img-id="fullLengthImg"
                                            data-img-h2="Full Length"
                                            data-default-src={"/assets/img/full-length.jpg" + eventFormConfig[eventName]["imgVersion"]}
                                            data-full-length-src={"/assets/img/full-length-big.jpg" + eventFormConfig[eventName]["imgVersion"]}
                                            alt="photo"
                                            id="fullLengthImgPreview"
                                        />
                                        <p id="fullLengthImgReferenceText">Reference Image</p>
                                        <img
                                            src={"/assets/img/fullscreen.png"}
                                            className="icon_img"
                                            alt="icon"
                                        />
                                    </div>
                                </div>
                            </div>
                            <div className="form_div">
                                <div className='upldoc_div'>
                                    <span className='filetype_txt'>Mid Length*</span>
                                    <div className="upload-btn-wrapper">
                                        <button className="btn">Add photo</button>
                                        <input
                                            type="file"
                                            id="midLengthImg"
                                            className={errors.midLengthImg?.message ? 'error' : ''}
                                            accept="image/png, image/jpeg, image.jpg"
                                            data-allowed-size="5000000"
                                            {...register("midLengthImg", {
                                                onChange: (e) => checkFileInput(e, 'image')
                                            })}
                                        />
                                        <input type="hidden" id="midLengthImgHiddenPath" />
                                        <div className="filename_div" id="midLengthImgDiv" style={{ display: "none" }}>
                                            <span className='filename_txt' id="midLengthImgFileName"></span>
                                            <span className='cancel_icon' onClick={() => clearImage('midLengthImg')}>x</span>
                                        </div>
                                    </div>
                                    <p className="error" id="midLengthImgError">{errors.midLengthImg?.message}</p>
                                    <div className="img_div" onClick={() => showPreviewImage('midLengthImg')}>
                                        <img
                                            src={"/assets/img/mid-length.jpg" + eventFormConfig[eventName]["imgVersion"]}
                                            data-img-id="midLengthImg"
                                            data-img-h2="Mid Length"
                                            data-default-src={"/assets/img/mid-length.jpg" + eventFormConfig[eventName]["imgVersion"]}
                                            data-full-length-src={"/assets/img/mid-length-big.jpg" + eventFormConfig[eventName]["imgVersion"]}
                                            alt="photo"
                                            id="midLengthImgPreview"
                                        />
                                        <p id="midLengthImgReferenceText">Reference Image</p>
                                        <img
                                            src={"/assets/img/fullscreen.png"}
                                            className="icon_img"
                                            alt="icon"
                                        />
                                    </div>
                                </div>
                            </div>
                            <div className="form_div">
                                <div className='upldoc_div upldoc_diveven'>
                                    <span className='filetype_txt'>Natural Beauty Shot* (no make-up)</span>
                                    <div className="upload-btn-wrapper">
                                        <button className="btn">Add photo</button>
                                        <input
                                            type="file"
                                            id="naturalBeautyImg"
                                            className={errors.naturalBeautyImg?.message ? 'error' : ''}
                                            accept="image/png, image/jpeg, image.jpg"
                                            data-allowed-size="5000000"
                                            {...register("naturalBeautyImg", {
                                                onChange: (e) => checkFileInput(e, 'image')
                                            })}
                                        />
                                        <input type="hidden" id="naturalBeautyImgHiddenPath" />
                                        <div className="filename_div" id="naturalBeautyImgDiv" style={{ display: "none" }}>
                                            <span className='filename_txt' id="naturalBeautyImgFileName"></span>
                                            <span className='cancel_icon' onClick={() => clearImage('naturalBeautyImg')}>x</span>
                                        </div>
                                    </div>
                                    <p className="error" id="naturalBeautyImgError">{errors.naturalBeautyImg?.message}</p>
                                    <div className="img_div" onClick={() => showPreviewImage('naturalBeautyImg')}>
                                        <img
                                            src={"/assets/img/natural-beauty.jpg" + eventFormConfig[eventName]["imgVersion"]}
                                            data-img-id="naturalBeautyImg"
                                            data-img-h2="Natural Beauty Shot"
                                            data-default-src={"/assets/img/natural-beauty.jpg" + eventFormConfig[eventName]["imgVersion"]}
                                            data-full-length-src={""}
                                            alt=""
                                            id="naturalBeautyImgPreview"
                                        />
                                        <p id="naturalBeautyImgReferenceText">
                                            {/* Reference Image */}
                                        </p>
                                        <img
                                            src={"/assets/img/fullscreen.png"}
                                            className="icon_img"
                                            alt="icon"
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* <div className="form_row upldurl_row">
                            <div className="form_div">
                                <label>Upload the URLs of your Audition Task Videos</label>
                                <p>Insert your 2 Audition Task videos on Google drive link.</p>
                            </div>



                            <div className="form_div inpt_div intro_div1">
                                <label>Video 1 - Introduction Video Link*</label>
                                <input
                                    type="url"
                                    placeholder="Video Link*"
                                    id="introductionVideoLink"
                                    className={errors.introductionVideoLink?.message ? 'error' : ''}
                                    {...register("introductionVideoLink")}
                                />
                                <p className="error" id="introductionVideoLinkError">{errors.introductionVideoLink?.message}</p>
                            </div>

                            <div className="form_div inpt_div intro_div2">
                                <label>Video 2 - Rampwalk Video Link*</label>
                                <input
                                    type="url"
                                    placeholder="Video Link*"
                                    id="rampWalkVideoLink"
                                    className={errors.rampWalkVideoLink?.message ? 'error' : ''}
                                    {...register("rampWalkVideoLink")}
                                />
                                <p className="error" id="rampWalkVideoLinkError">{errors.rampWalkVideoLink?.message}</p>
                            </div>

                        </div> */}

                        <div className="form_row procdpay_row">
                            <input
                                type="checkbox"
                                id="tncCheck"
                                className={errors.tncCheck?.message ? 'error' : ''}
                                {...register("tncCheck")}
                                defaultChecked={true}
                            />
                            <label htmlFor="tncCheck"> I agree to </label>
                            <span onClick={() => togglePopup('termsconditionoverlay')}>terms and conditions</span>
                            <span className="info">i <span className="info_txt">
                                Accepting all conditions and filling all fields in the form is mandatory in order to submit the form
                            </span>
                            </span>
                            <p className="error" id="tncCheckError">{errors.tncCheck?.message}</p>
                        </div>

                        <div className="form_row procdpaybtn_row">
                            <input
                                type="hidden"
                                id="rToken"
                                {...register("rToken")}
                            />

                            <button
                                className="btn procdpay_btn"
                                type="submit">
                                Proceed to Payment
                            </button>
                            <p className="error" id="common_error"></p>
                        </div>
                    </div>
                </div>
            </form>
            <GoogleReCaptcha />
            {/* {console.log(errors)} */}
            {/* <DevTool control={control} /> */}
        </>
    )
}

export default MainFormIndex