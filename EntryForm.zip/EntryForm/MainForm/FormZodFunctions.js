import apiCall from "@/utilities/apiCall";
import { allowedUTMParams, generateReCaptchaToken, checkPaymentGatewayUrl, showActiveErrorTab, sendEntryFormEvent } from "./FormFunctions";

export const preSubmit = (data) => {
    document.getElementById('common_error').innerText = '';
    // Showing loader for 30 Sec.
    document.getElementById("loader_div").style.display = 'flex';
    setTimeout(() => {
        document.getElementById("loader_div").style.display = 'none';
    }, 30000);

    document.getElementById("rToken").value = '';
    generateReCaptchaToken();
    let trial = 0;
    let setInt = setInterval(() => {
        trial++;
        const tempToken = document.getElementById("rToken").value;
        if (trial == 10) {
            document.getElementById('common_error').innerText = 'Please try again later!'
            clearInterval(setInt);
        }
        if (tempToken != '') {
            let finalData = {
                ...data,
                rToken: tempToken
            }
            collectHiddenPathPreSubmit(finalData)
            clearInterval(setInt);
        }
    }, 500);
};

const collectHiddenPathPreSubmit = (data) => {
    let hiddenPathFields = ['birthStateProof', 'currentStateProof', 'nativeStateProof', 'closeUpImg', 'fullLengthImg', 'midLengthImg', 'naturalBeautyImg']
    let hiddenObj = {}
    hiddenPathFields.map((value) => {
        hiddenObj[value] = document.getElementById(`${value}HiddenPath`).value;
    })

    let finalData = {
        ...data,
        ...hiddenObj
    }
    collectLoginSSOId(finalData);
}

const collectLoginSSOId = (data) => {
    let ssoId = '';
    window.JSSObj.getUserDetails((response) => {
        if (response.code == 200) {
            ssoId = response.data.ssoid
        }
        let finalData = {
            ...data,
            ssoId: ssoId
        }
        collectUTMParameter(finalData)
    });
}

const collectUTMParameter = (data) => {
    let UTMObj = {}
    allowedUTMParams.map((value) => {
        let localValue = localStorage.getItem(`${value}`) || '';
        if (localValue != '') {
            UTMObj[value] = localValue
        }
    })

    let finalData = {
        ...data,
        ...UTMObj
    }
    onSubmit(finalData)

}

const onSubmit = async (data) => {
    let formData = new FormData();
    for (let key in data) {
        formData.append(key, data[key]);
    }

    const formSubmitUrl = process.env.NEXT_PUBLIC_ROOT_API + 'beauty_pageants/v1/submit_contestant_details'
    const options = {
        method: "POST",
        body: formData,
        body_type: 'form_data'
    };

    const jsonResponse = await apiCall(formSubmitUrl, options);
    sendEntryFormEvent('form_submit_init', 'Sent user data to backend api');

    if (jsonResponse.response.response_code != "200") {
        handleFailureResponse(jsonResponse);
    } else {
        const paymentUrl = jsonResponse.response_content.payment_url;
        const isValidPaymentGateway = checkPaymentGatewayUrl(paymentUrl);
        if (isValidPaymentGateway) {
            sendEntryFormEvent('success_api_response', 'Sent to payment page');
            window.location = paymentUrl;
        } else {
            sendEntryFormEvent('failure_api_response', 'Invalid payment gateway domain');
            document.getElementById('common_error').innerText = "Invalid payment gateway domain";
        }
    }
}

const handleFailureResponse = (apiResponse) => {
    document.getElementById("loader_div").style.display = 'none';
    const respData = apiResponse.response.response_message;

    const responseKeys = Object.keys(respData)[0] || '';
    const responseMessage = Object.values(respData)[0] || '';
    if (responseKeys != "" || responseMessage != '') {
        sendEntryFormEvent('failure_api_response', responseMessage);
        if (document.getElementById(`${responseKeys}Error`) != null) {
            document.getElementById(`${responseKeys}Error`).innerText = responseMessage;
            showActiveErrorTab(respData)
            document.getElementById(`${responseKeys}`).focus();
        } else {
            document.getElementById('common_error').innerText = responseMessage;
        }
    } else {
        sendEntryFormEvent('failure_api_response', "Please try again later");
        document.getElementById('common_error').innerText = "Please try again later";
    }
}