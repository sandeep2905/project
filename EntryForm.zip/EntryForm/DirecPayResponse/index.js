'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation'
import LoaderComponent from '@/utilities/LoaderComponent';

const EntryFormDirecPayResponse = ({ data }) => {
	const router = useRouter();
	const responseCode = data.response.response_code;

	useEffect(() => {
		if (responseCode == 200) {
			localStorage.setItem('payment-success', 1)
			router.replace('/beauty-pageants/missindiaentryform/payment-success');
		} else {
			const authCode = data.response_content.authCode;
			localStorage.setItem('payment-auth-code', authCode)
			router.replace('/beauty-pageants/missindiaentryform/payment-failure');
		}
	}, []);

	return <LoaderComponent className="overlay" />;
}

export default EntryFormDirecPayResponse