'use client'

import { useEffect, useState } from 'react';
import styles from '@/styles/english/HomeBeauty.css';
import styles2 from '@/styles/english/ApplyForm.css';
import CheckLogin from '@/utilities/login/CheckLogin';
import { initSSO } from '@/utilities/login/functions';
import { eventFormConfig } from './eventFormConfig';
import RegisterPage from './RegisterPage';
import PreLoginRegisterPage from './PreLoginRegisterPage';
import LoaderComponent from '@/utilities/LoaderComponent';
import { extractUTMParams } from './MainForm/FormFunctions';


export default function EntryFormIndex({ eventName }) {
    const [currentState, updateCurrentState] = useState(0);     // 0: First Instruction Page,     1: Register Page
    const [isLogin, userDetail] = CheckLogin();
    const loginRequired = eventFormConfig[eventName]['loginRequired'];

    useEffect(() => {
        extractUTMParams();
        if (loginRequired) {
            if (isLogin == null) {
                document.getElementById("loader_div").style.display = 'flex';
            } else {
                if (isLogin) updateCurrentState(1);
                document.getElementById("loader_div").style.display = 'none';
            }
        } else {
            document.getElementById("loader_div").style.display = 'none';
        }
    }, [isLogin]);


    const checkLoginStatus = () => {
        if (loginRequired) {
            if (isLogin == true) {
                updateCurrentState(1);
            } else if (isLogin == false) {
                initSSO();
            }
        } else {
            updateCurrentState(1);
        }
    }

    let currentHTML;
    if (currentState == 1) {
        currentHTML = <RegisterPage eventName={eventName} />
    } else {
        currentHTML = <PreLoginRegisterPage checkLoginStatus={checkLoginStatus} />;
    }

    return (
        <main className="home_page_bp beauty-p-wrap">
            <section>
                {currentHTML}
                {/* <div className="loader_div" id="loader_div" style={{ display: 'flex' }}>
                    <img src={"/assets/img/ajax-spinner.gif"} alt="loader" width="256" height="256" />
                </div> */}
                <LoaderComponent />
                <div className='clear'></div>
            </section>
        </main>
    )
}
