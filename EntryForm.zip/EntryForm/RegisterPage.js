import MainFormIndex from './MainForm';
import { eventFormConfig } from './eventFormConfig';
import { openTab, togglePopup } from './MainForm/FormFunctions';


const RegisterPage = ({ eventName }) => {
    const ageCriteriaDateFormat = eventFormConfig[eventName]['ageCriteria'].toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });

    return (
        <>
            <div className="box_div">
                <div className="logo_div">
                    <img src={process.env.NEXT_PUBLIC_SITE_PATH + eventFormConfig[eventName]['headerImage']} alt="logo" />
                </div>
                <div className="accordion-container">
                    <div className="set">
                        <span className="tab_head active" onClick={() => openTab(1, 'toggle')} id="btn-1" data-tab-id="1">
                            <span className="num_txt">1</span> <span className="head_txt">Eligibility Criteria</span>
                        </span>
                        <div className="content">
                            <div className="details_div">
                                <ul>
                                    <li>Age: 18 to 25 years (25 as of {ageCriteriaDateFormat}).</li>
                                    <li>Height: 5&apos;3&apos;&apos; & above (without heels).</li>
                                    <li>Relationship Status: Single, Not- Engaged, Unmarried, &amp; Never been Married.</li>
                                    <li>Nationality: Indian passport holder.</li>
                                    <li>OCI cardholder can apply only for 2<sup>nd</sup> runner-up title.</li>
                                </ul>
                            </div>
                            {/* <div className="details_div steps_div">
                                <p>Please read the process carefully before filling out the form</p>
                                <ul>
                                    <li><span>Step 1:</span>Sign In with your email ID or Mobile Number.</li>
                                    <li><span>Step 2:</span>Fill in all your credentials, your Instagram handle & your physical attributes along with your contact details. All fields are mandatory.</li>
                                    <li><span>Step 3:</span>Upload your pictures as mentioned.</li>
                                    <li><span>Step 4:</span>Once all the fields are completed, click on accept T&Cs & submit the form.</li>
                                    <li><span>Step 5:</span>You will receive an automated email upon successful submission of the form.</li>
                                </ul>
                            </div> */}
                            <div className="cont_btndiv">
                                <span className="cont_btn" onClick={() => openTab(2)} data-id="btn-2">Continue</span>
                            </div>
                        </div>
                    </div>

                    <MainFormIndex eventName={eventName} />

                    {/* <div className="set">
                            <span className="tab_head" onClick={()=>openTab(5)} id="btn-5" data-tab-id="5">
                            <span className="num_txt">5</span> <span className="head_txt">Subscription for Ace your Pageant Course of Times Grooming School</span>
                            </span>
                            <div className="content">
                            </div>
                        </div> */}
                </div>

                <div className="helpline_div">
                    <p>For further clarity, kindly call the helpline numbers between 11 am to 7 pm.<br /> Contact: +91 9619937295 / +91 9930771844 or kindly write to us on missindiaorg@timesgroup.com</p>
                </div>

                <div data-plugin="exmaplethumbview" className="termsconditionoverlay exampleview" id="imagepreview_div">
                    <div className="termsconditionoverlaymid">
                        <span
                            className="termsconditionoverlayclose"
                            onClick={() => togglePopup('imagepreview_div')}
                        ></span>
                        <h2 id="imagepreview_h2">Close Up</h2>
                        <div className="termsconditionoverlaymidIn">
                            <img
                                className="exmpleimgset"
                                src="https://static.toiimg.com/photo/102599393.cms"
                                id="imagepreview_img_tag"
                            />
                        </div>
                    </div>
                </div>

                {/* TnC Popup Data */}
                <div className="termsconditionoverlay" id="termsconditionoverlay">
                    <div className="termsconditionoverlaymid">
                        <span
                            className="termsconditionoverlayclose"
                            onClick={() => togglePopup('termsconditionoverlay')}
                        ></span>
                        <h2 className="spleft40">Terms &amp; Conditions</h2>
                        <div className="termsconditionoverlaymidIn">
                            <ol>
                                <li>The applicant must agree to abide by all rules, as amended from time to time by the Organizer in its sole discretion.</li>
                                <li>The applicant should be between (18 - 25 years as of 31st December 2023) &amp; 5'3'' and above in height (Without heels).</li>
                                <li>
                                    The applicant must produce the following: Nationality Proof: Passport (preferred option) or Aadhar Card or Voters ID or Driving License. In the case of OCI applicant, will require an OCI card. State Eligibility Proof: the below-mentioned eligibility proof is required to apply from:
                                    <ol className="subpoints">
                                        <li>Birth State: Birth Certificate or Passport</li>
                                        <li>Current State: Employment Certificate / Employment ID Card or House Rental Document or College ID or Gas / Electricity Bill</li>
                                        <li>Native State: Parents' Residential Proof documents e.g. House / Rent Agreement or Gas Bill or Electricity Bill or Phone Bill or Employment Certificate / Employment ID Card or Birth Certificate or Passport - on either of your parents&rsquo; name</li>
                                    </ol>
                                </li>
                                <li>The applicant uses the prefix 'Miss'(or equivalent) before her name. The applicant should not / have not been married and never been through any ceremony directly or indirectly, either valid or invalid, whether civil, religious, or tribal which is recognized as a marriage ceremony in any part of the world and should never have had a marriage annulled or never given birth to a child; have never been pregnant nor been a parent.</li>
                                <li>The applicant should be a natural-born female i.e. individual assigned female at birth.</li>
                                <li>The applicant should be a bonafide Indian citizen, holding a valid Indian passport, and should be a resident of India as per the applicable laws of India.</li>
                                <li>The applicant or the applicant's immediate family should not be related to any person employed in WWM, or any of its group companies, contest sponsors, and their subcontractors, or any of the judges as informed to the applicant at any stage. In case of such a relation, the applicant must disclose the same immediately.</li>
                                <li>If the applicant is under any commercial contract with any modelling agency at the time of appearing for the auditions, she should declare it on email before she auditions virtually for the pageant.</li>
                                <li>The applicant once shortlisted cannot be a part of any other commercial contract or pageant. If already under any contract, then she should declare the same to the Organization before auditions.</li>
                                <li>The Organizers are not responsible for any delays or non-receipt of applications on any account and any reason whatsoever.</li>
                                <li>The applicant should not have been qualified for or taken part in any contest as a representative of any country other than India and If so, they need to declare it to Miss India Organization before auditions.</li>
                                <li>The applicant will have to participate in a disciplined and diligent manner throughout as per schedule for auditions and screening.</li>
                                <li>Any profile or material asked by the Organization stating the applicant's information should be shared with the Organization on an immediate basis.</li>
                                <li>The Organizer shall not be responsible if the sponsors do not make good the prizes promised by them.</li>
                                <li>The applicant acknowledges and agrees that participation in the event is voluntary and at their own risk. WWM and its affiliates shall not be held liable for any loss, injury, damage, or other claims arising from the participation in the event. The applicant is encouraged to have their own insurance coverage for any such occurrences. By participating, the applicant waives any claim against WWM and its affiliates in this regard.</li>
                                <li>The applicant acknowledges that any incorrect information shall result in disqualification, whether discovered before, during, or after participation.</li>
                                <li>The decision of the judges shall be final in all cases and the applicant does not in any capacity question the same on any platform and no correspondence shall be entertained in this regard.</li>
                                <li>The applicant agrees not to disclose any information related to the judging process, including comments or critiques provided by the judges, to any third party.</li>
                                <li>The applicant cannot get in touch with any judge during the judging process.</li>
                                <li>If an applicant has a personal connection with any judge the applicant must declare it during the auditions to the contestant managers.</li>
                                <li>Sharing audition footage, internal results, or confidential information provided by the Organization through any social media platform or with any other individuals related to such platforms is strictly prohibited. Breach of this clause may result in immediate disqualification and legal action.</li>
                                <li>The applicant shall be in good health, sound mind, and have a good moral character to be eligible to participate in the contest.</li>
                                <li>The applicant should not have any cases (criminal or civil) registered against her.</li>
                                <li>The schedule of the events and qualification rounds are subject to change at the discretion of the Organizer.</li>
                                <li>The applicant is selected as one of the 30 State Winners will have to sign the legal contract with the Organization. The contract must be submitted 24-48 hours from the time it is handed over to the applicant.</li>
                                <li>The OCI cardholder will only be eligible to win the 2nd Runner-up title.</li>
                                <li>In the event that the winner is unable to fulfill her duties, for any reason, the 1st runner-up may be considered to represent India at Miss World.</li>
                                <li>The Organizers are not responsible for the non-completion / non-occurrence of the event.</li>
                                <li>In the event of any dispute, the Organizers&rsquo; decisions are final and binding on the applicant.</li>
                                <li>The applicant hereby agrees to indemnify WWM against all third-party claims, penalties, losses, damages, liabilities, costs, or expenses (including attorneys&rsquo; fees and other dispute resolution costs) or direct and indirect losses that may be incurred by WWM arising from and out of any breach, by the applicant of any terms and conditions of this Terms and Conditions.</li>
                                <li>The courts of Mumbai have jurisdiction over all disputes.</li>
                                <li>For further information/clarifications, kindly call the helpline numbers between 11 am to 7 pm. Contact: +91 9619937295 / +91 9930771844 or kindly write to us on missindiaorg@timesgroup.com. </li>
                            </ol>
                        </div>
                    </div>
                </div>

            </div>
        </>
    )
}

export default RegisterPage