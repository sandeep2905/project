export const eventFormConfig = {
    MissIndia: {
        "imgVersion": "?v=0.2",
        "loginRequired": 1,
        "url": "missindiaentryform",
        "title": "Femina Miss India 2024: Beauty Pageant Entry Form | Apply Online for Femina Miss India 2024 Beauty Contest",
        "metadescription": "Femina Miss India 2024 Beauty Pageant Entry Form: Why do you want to participate in Femina Miss India 2024 Beauty Pageant? Upload your photos and you never know your life might change.",
        "metakeywords": "form, beauty pageant entry form, Femina Miss India 2024, beauty contest entry form, Femina Miss India 2024 beauty contest, Femina Miss India 2024",
        "headerImage": "assets/img/feminamiss_logo.jpg",
        "ogImage": "assets/img/Femina-Miss-India-Entry-Form-OG.jpg",
        "ageCriteria": new Date("2023-12-31"),     // new Date(year-month-day)
        "paymentGatewayDomain": "direcpay.com",
        "trackGA4CategoryName": "MissIndiaEntryForm"
    }
}