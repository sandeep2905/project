'use client';

import styles from '@/styles/english/HomeBeauty.css';
import styles2 from '@/styles/english/ApplyForm.css';
import { useEffect, useState } from "react"
import LoaderComponent from "@/utilities/LoaderComponent"
import apiCall from "@/utilities/apiCall";
import { eventFormConfig } from '../eventFormConfig';
import { checkPaymentGatewayUrl, sendEntryFormEvent } from '../MainForm/FormFunctions';

const EntryFormPaymentFailure = ({ eventName }) => {
	const [paymentAuthCode, setPaymentAuthCode] = useState(null)

	useEffect(() => {
		sendEntryFormEvent('Payment Page', "Payment Failure");
		setPaymentAuthCode(localStorage.getItem('payment-auth-code'));
	}, []);

	const callApi = async () => {
		document.getElementById("loader_div").style.display = 'flex';
		document.getElementById('common_error').innerText = '';

		if (paymentAuthCode == null) {
			window.location = process.env.NEXT_PUBLIC_BP_SITE_PATH + eventFormConfig[eventName]['url'];
		} else {
			const regenerateApi = process.env.NEXT_PUBLIC_ROOT_API + 'beauty_pageants/v1/regenerate_authcode';

			const formData = new FormData();
			formData.append('authCode', paymentAuthCode);
			const options = {
				method: "POST",
				body: formData,
				body_type: 'form_data'
			};

			const jsonResponse = await apiCall(regenerateApi, options);
			if (jsonResponse.response.response_code != "200") {
				const responseMessage = jsonResponse.response.response_message.msg;
				document.getElementById('common_error').innerText = responseMessage;
				document.getElementById("loader_div").style.display = 'none';
				sendEntryFormEvent('success_api_retry_payment_response', responseMessage);
			} else {
				localStorage.removeItem('payment-auth-code');
				const paymentUrl = jsonResponse.response_content.payment_url;
				const isValidPaymentGateway = checkPaymentGatewayUrl(paymentUrl)
				if (isValidPaymentGateway) {
					sendEntryFormEvent('success_api_retry_payment_response', 'Sent to payment page');
					window.location = paymentUrl;
				} else {
					sendEntryFormEvent('success_api_retry_payment_response', 'Invalid payment gateway domain');
					document.getElementById('common_error').innerText = "Invalid payment gateway domain";
					document.getElementById("loader_div").style.display = 'none';
				}
			}
		}
	}

	return (
		<>
			<div className="box_div">
				<div className="review_div">
					<h4>Review Payment Information</h4>
					<p>We regret to inform you that there was an issue processing your payment.</p>
					<button className="btn retry_btn" onClick={() => callApi()}>
						Please Retry
					</button>
					<input type="hidden" id="eventName" value={eventName} />
					<p className="error" id="common_error"></p>
				</div>
			</div>
			<LoaderComponent className="overlay" style={{ display: 'none' }} />
		</>
	)
}

export default EntryFormPaymentFailure