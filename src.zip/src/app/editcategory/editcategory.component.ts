import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { CrudService } from '../crud.service';

@Component({
  selector: 'app-editcategory',
  templateUrl: './editcategory.component.html',
  styleUrls: ['./editcategory.component.css']
})
export class EditcategoryComponent implements OnInit {

  constructor(private actRoute:ActivatedRoute,private crud:CrudService) { }

  cat:string;
  ngOnInit() {
  			var catid = Number(this.actRoute.snapshot.params.xyz);
  			this.crud.selectData_filter("category" , catid).subscribe(
  			(results)=>{
  				// console.log(results);
  				this.cat = results.name;

  			})
  }

  update_category(record)
  {
  	// alert(record)
  	var catid = Number(this.actRoute.snapshot.params.xyz);
  	// alert(catid)
  	this.crud.updateData("category" , catid , {name:record}).subscribe(
  		(results)=>{
  			console.log(results);
  		})
  }

}
