import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { CrudService } from '../crud.service';

@Component({
  selector: 'app-deletecategory',
  templateUrl: './deletecategory.component.html',
  styleUrls: ['./deletecategory.component.css']
})
export class DeletecategoryComponent implements OnInit {

  constructor(private actRoute:ActivatedRoute,private crud:CrudService,
  	private routerObj:Router) {
  		// consolr.log(actRoute.params._value.xyz);

  	 }

  ngOnInit() {

  		var catid = Number(this.actRoute.snapshot.params.xyz);
  		// var catid = ParseInt(this.actRoute.params._value.xyz);
  		// var catid = +this.actRoute.params._value.xyz+;
  		// console.log(catid);
  		this.crud.deleteData("category", catid).subscribe(
  			(results)=>{
  				// console.log(results);
  				this.routerObj.navigate(["/category"]);
  			}
  			)

  }

}
