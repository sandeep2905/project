import { Component, OnInit } from '@angular/core';
import { CrudService } from '../crud.service';


@Component({
  selector: 'app-brand',
  templateUrl: './brand.component.html',
  styleUrls: ['./brand.component.css']
})
export class BrandComponent implements OnInit {
	public results;
  constructor(private crud:CrudService) { 
  		// console.log(this.crud)
  }

  
  ngOnInit() {

  		this.crud.selectData("brand").subscribe((results)=>{

  			// console.log(results);
  			this.brandData = results;

  		})
  }

}
